"use strict";
(() => {
  // src/platform.ts
  function extensionApi() {
    const api2 = globalThis.browser ?? globalThis.chrome;
    if (!api2) throw new Error("Briefmark must run inside a browser extension.");
    return api2;
  }

  // src/privacy.ts
  var PRIVACY_NOTICE = "All data stays local to this device. Nothing sent remotely, ever.";

  // src/privacy.css
  var privacy_default = `.privacy { margin: 12px 0 0; color: #647188; font: 11px/1.5 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; text-align: center; }
.app[data-theme="dark"] .privacy { color: #acb8ce; }
`;

  // src/popup.ts
  var style = document.createElement("style");
  style.textContent = privacy_default;
  document.head.append(style);
  var privacy = document.createElement("p");
  privacy.className = "privacy";
  privacy.textContent = PRIVACY_NOTICE;
  document.querySelector("#status").after(privacy);
  var api = extensionApi();
  var button = document.querySelector("#open");
  var status = document.querySelector("#status");
  button.addEventListener("click", async () => {
    button.disabled = true;
    status.textContent = "";
    try {
      const [tab] = await api.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id || !tab.url || !/^https?:/.test(tab.url)) {
        throw new Error("Open a regular http or https website to start annotating.");
      }
      const result = await api.runtime.sendMessage({ type: "OPEN_PAGEBRIEF", tabId: tab.id });
      if (!result?.ok) throw new Error("Injection was blocked.");
      window.close();
    } catch (error) {
      status.textContent = error instanceof Error && error.message.startsWith("Open a regular") ? error.message : "This browser cannot annotate this page. Try a regular website; browser settings and extension stores are restricted.";
      button.disabled = false;
    }
  });
})();
