"use strict";
(() => {
  // src/screenshot.ts
  var clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  function privateImage(dataUrl, alt) {
    const host = document.createElement("briefmark-image");
    const root = host.attachShadow({ mode: "closed" });
    const image = document.createElement("img");
    image.src = dataUrl;
    image.alt = alt;
    image.style.cssText = "display:block;width:100%;height:100%;object-fit:contain;pointer-events:none;";
    root.append(image);
    return host;
  }
  async function selectScreenshot(app, mobile, capture, signal) {
    const viewport = window.visualViewport;
    const width = viewport?.width ?? innerWidth;
    const height = viewport?.height ?? innerHeight;
    const left = viewport?.offsetLeft ?? 0;
    const top = viewport?.offsetTop ?? 0;
    const zoom = viewport?.scale ?? 1;
    const root = document.compatMode === "BackCompat" ? document.body : document.documentElement;
    const captureWidth = width + Math.max(0, innerWidth - root.clientWidth) / zoom;
    const captureHeight = height + Math.max(0, innerHeight - root.clientHeight) / zoom;
    const scroll = { x: window.scrollX + left, y: window.scrollY + top };
    const startUrl = location.href;
    const valid = () => !signal.aborted && !document.hidden && location.href === startUrl && Math.abs((viewport?.width ?? innerWidth) - width) < 1 && Math.abs((viewport?.height ?? innerHeight) - height) < 1 && Math.abs(window.scrollX + (viewport?.offsetLeft ?? 0) - scroll.x) < 1 && Math.abs(window.scrollY + (viewport?.offsetTop ?? 0) - scroll.y) < 1;
    let dataUrl;
    app.classList.add("capture-hidden");
    try {
      await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
      if (!valid()) throw new Error("The page moved. Try capturing again.");
      dataUrl = await capture();
    } finally {
      app.classList.remove("capture-hidden");
    }
    if (!valid()) throw new Error("The page moved during capture. Try again.");
    const image = new Image();
    image.src = dataUrl;
    await image.decode();
    if (!valid()) throw new Error("The page moved during capture. Try again.");
    const layer = document.createElement("div");
    layer.className = "capture-layer";
    layer.setAttribute("role", "dialog");
    layer.setAttribute("aria-label", "Select screenshot region");
    Object.assign(layer.style, { left: `${left}px`, top: `${top}px`, width: `${width}px`, height: `${height}px` });
    const photo = privateImage(dataUrl, "Captured page");
    photo.className = "capture-photo";
    Object.assign(photo.style, { width: `${captureWidth}px`, height: `${captureHeight}px` });
    dataUrl = "";
    layer.append(photo);
    layer.insertAdjacentHTML("beforeend", '<div class="capture-shade"></div><div class="capture-region" tabindex="0" aria-label="Move screenshot region"><button class="capture-handle nw" data-corner="nw" aria-label="Resize top left"></button><button class="capture-handle ne" data-corner="ne" aria-label="Resize top right"></button><button class="capture-handle sw" data-corner="sw" aria-label="Resize bottom left"></button><button class="capture-handle se" data-corner="se" aria-label="Resize bottom right"></button></div><div class="capture-toolbar"><p></p><div><button class="secondary capture-cancel">Cancel</button><button class="primary capture-use" disabled>Use screenshot</button></div></div>');
    const region = layer.querySelector(".capture-region");
    const use = layer.querySelector(".capture-use");
    const toolbar = layer.querySelector(".capture-toolbar");
    toolbar.querySelector("p").textContent = mobile ? "Drag the box or its corners." : "Drag to select an area.";
    app.classList.add("capturing");
    app.append(layer);
    const min = 12;
    let rect = mobile ? { x: Math.round(width * 0.15), y: Math.round(height * 0.2), width: Math.round(width * 0.7), height: Math.round(height * 0.45) } : null;
    function render() {
      region.hidden = !rect;
      layer.querySelector(".capture-shade").hidden = !!rect;
      use.disabled = !rect || rect.width < min || rect.height < min;
      if (rect) Object.assign(region.style, { left: `${rect.x}px`, top: `${rect.y}px`, width: `${rect.width}px`, height: `${rect.height}px` });
    }
    render();
    return new Promise((resolve, reject) => {
      const listeners = new AbortController();
      let finished = false;
      function finish(result, error) {
        if (finished) return;
        finished = true;
        listeners.abort();
        signal.removeEventListener("abort", aborted);
        layer.remove();
        app.classList.remove("capturing");
        image.src = "";
        if (error) reject(error);
        else resolve(result);
      }
      const aborted = () => finish(null);
      signal.addEventListener("abort", aborted, { once: true });
      const changed = () => {
        if (!valid()) finish(null, new Error("The page changed. Capture the region again."));
      };
      for (const target of [window, viewport].filter(Boolean)) {
        for (const name of ["resize", "scroll"]) target.addEventListener(name, changed, { signal: listeners.signal });
      }
      document.addEventListener("visibilitychange", changed, { signal: listeners.signal });
      layer.addEventListener("wheel", (event) => event.preventDefault(), { passive: false, signal: listeners.signal });
      let drag = null;
      const pointers = /* @__PURE__ */ new Set();
      layer.addEventListener("pointerdown", (event) => {
        if (!event.isTrusted || toolbar.contains(event.target)) return;
        event.preventDefault();
        event.stopPropagation();
        pointers.add(event.pointerId);
        if (pointers.size > 1) {
          if (drag) rect = drag.before;
          drag = null;
          render();
          return;
        }
        const x = clamp(event.clientX - left, 0, width), y = clamp(event.clientY - top, 0, height);
        const target = event.target;
        const corner = target.dataset.corner || (target === region ? "move" : "new");
        const before = rect && { ...rect };
        if (!rect || corner === "new") rect = { x, y, width: 0, height: 0 };
        drag = { id: event.pointerId, x, y, corner, original: { ...rect }, before };
        layer.setPointerCapture(event.pointerId);
        render();
      }, { signal: listeners.signal });
      layer.addEventListener("pointermove", (event) => {
        if (!event.isTrusted || !drag || drag.id !== event.pointerId) return;
        event.preventDefault();
        const x = clamp(event.clientX - left, 0, width), y = clamp(event.clientY - top, 0, height);
        const original = drag.original;
        if (drag.corner === "move") rect = { ...original, x: clamp(original.x + x - drag.x, 0, width - original.width), y: clamp(original.y + y - drag.y, 0, height - original.height) };
        else {
          const anchorX = drag.corner === "new" ? drag.x : original.x + (drag.corner.includes("w") ? original.width : 0);
          const anchorY = drag.corner === "new" ? drag.y : original.y + (drag.corner.includes("n") ? original.height : 0);
          rect = { x: Math.min(x, anchorX), y: Math.min(y, anchorY), width: Math.abs(x - anchorX), height: Math.abs(y - anchorY) };
        }
        render();
      }, { signal: listeners.signal });
      for (const name of ["pointerup", "pointercancel"]) layer.addEventListener(name, (event) => {
        pointers.delete(event.pointerId);
        if (drag?.id === event.pointerId) {
          if (name === "pointercancel") rect = drag.before;
          drag = null;
          render();
        }
      }, { signal: listeners.signal });
      document.addEventListener("keydown", (event) => {
        if (!event.isTrusted) return;
        if (event.key === "Escape") {
          event.preventDefault();
          event.stopImmediatePropagation();
          finish(null);
        } else if (rect && ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) {
          event.preventDefault();
          const step = event.shiftKey ? 10 : 1;
          const active = layer.getRootNode().activeElement;
          const corner = active?.dataset.corner;
          const dx = event.key === "ArrowLeft" ? -step : event.key === "ArrowRight" ? step : 0;
          const dy = event.key === "ArrowUp" ? -step : event.key === "ArrowDown" ? step : 0;
          if (corner) {
            const x1 = corner.includes("w") ? clamp(rect.x + dx, 0, rect.x + rect.width - min) : rect.x;
            const y1 = corner.includes("n") ? clamp(rect.y + dy, 0, rect.y + rect.height - min) : rect.y;
            const x2 = corner.includes("e") ? clamp(rect.x + rect.width + dx, rect.x + min, width) : rect.x + rect.width;
            const y2 = corner.includes("s") ? clamp(rect.y + rect.height + dy, rect.y + min, height) : rect.y + rect.height;
            rect = { x: x1, y: y1, width: x2 - x1, height: y2 - y1 };
          } else rect = { ...rect, x: clamp(rect.x + dx, 0, width - rect.width), y: clamp(rect.y + dy, 0, height - rect.height) };
          render();
        } else if (event.key === "Tab") {
          const controls = [...layer.querySelectorAll('button:not(:disabled), [tabindex="0"]')].filter((el) => el.getClientRects().length);
          const current = layer.getRootNode().activeElement;
          const index = controls.indexOf(current);
          event.preventDefault();
          controls[(index + (event.shiftKey ? controls.length - 1 : 1)) % controls.length]?.focus();
        }
      }, { capture: true, signal: listeners.signal });
      function activate(button, action) {
        let tap = null;
        button.addEventListener("pointerdown", (event) => {
          if (!event.isTrusted || event.pointerType !== "touch") return;
          tap = event.isPrimary ? { id: event.pointerId, x: event.clientX, y: event.clientY, time: performance.now() } : null;
        }, { signal: listeners.signal });
        button.addEventListener("pointercancel", () => {
          tap = null;
        }, { signal: listeners.signal });
        button.addEventListener("pointermove", (event) => {
          if (tap && Math.hypot(event.clientX - tap.x, event.clientY - tap.y) > 12) tap = null;
        }, { signal: listeners.signal });
        button.addEventListener("pointerup", (event) => {
          const candidate = tap;
          tap = null;
          const bounds = button.getBoundingClientRect();
          if (!event.isTrusted || button.disabled || candidate?.id !== event.pointerId || performance.now() - candidate.time > 700 || event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) return;
          event.preventDefault();
          event.stopPropagation();
          const cleanup = () => {
            document.removeEventListener("click", suppress, true);
            document.removeEventListener("pointerdown", cleanup, true);
            clearTimeout(timer);
          };
          const suppress = (click) => {
            if (!click.isTrusted || click.detail === 0) return;
            click.preventDefault();
            click.stopImmediatePropagation();
            cleanup();
          };
          const timer = setTimeout(cleanup, 800);
          document.addEventListener("click", suppress, true);
          document.addEventListener("pointerdown", cleanup, true);
          action();
        }, { signal: listeners.signal });
        button.addEventListener("click", (event) => {
          if (event.isTrusted && !button.disabled) action();
        }, { signal: listeners.signal });
      }
      activate(layer.querySelector(".capture-cancel"), () => finish(null));
      activate(use, () => {
        if (!rect || use.disabled || drag) return;
        if (!valid()) {
          changed();
          return;
        }
        try {
          const x = Math.round(rect.x * image.naturalWidth / captureWidth), y = Math.round(rect.y * image.naturalHeight / captureHeight);
          const right = Math.round((rect.x + rect.width) * image.naturalWidth / captureWidth);
          const bottom = Math.round((rect.y + rect.height) * image.naturalHeight / captureHeight);
          const scale = Math.min(1, 2400 / Math.max(right - x, bottom - y));
          const canvas = document.createElement("canvas");
          canvas.width = Math.max(1, Math.round((right - x) * scale));
          canvas.height = Math.max(1, Math.round((bottom - y) * scale));
          canvas.getContext("2d").drawImage(image, x, y, right - x, bottom - y, 0, 0, canvas.width, canvas.height);
          const cropped = canvas.toDataURL("image/png");
          if (cropped.length > 28e5) {
            toolbar.querySelector("p").textContent = "Image is too large. Select a smaller area.";
            return;
          }
          finish({
            dataUrl: cropped,
            width: canvas.width,
            height: canvas.height,
            region: { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height) },
            viewport: { width: Math.round(width), height: Math.round(height) },
            scroll
          });
        } catch {
          finish(null, new Error("Could not crop this screenshot. Try again."));
        }
      });
      (rect ? region : layer.querySelector(".capture-cancel")).focus();
    });
  }

  // src/core.ts
  var STORAGE_PREFIX = "pagebrief:note:v1:";
  var shorten = (text, max = 240) => text.replace(/\s+/g, " ").trim().slice(0, max);
  function pageUrl(url = location.href) {
    const parsed = new URL(url);
    parsed.username = "";
    parsed.password = "";
    return parsed.href;
  }
  function selectorWithinRoot(element) {
    const root = element.getRootNode();
    const unique = (selector) => root.querySelectorAll(selector).length === 1;
    const segments = [];
    let node = element;
    while (node) {
      if (node.id && unique(`#${CSS.escape(node.id)}`)) {
        segments.unshift(`#${CSS.escape(node.id)}`);
        break;
      }
      const testId = node.getAttribute("data-testid");
      if (testId) {
        const selector = `[data-testid="${CSS.escape(testId)}"]`;
        if (unique(selector)) {
          segments.unshift(selector);
          break;
        }
      }
      const tag = CSS.escape(node.localName);
      const parent = node.parentNode;
      const siblings = parent ? Array.from(parent.children).filter((s) => s.localName === node.localName) : [];
      segments.unshift(siblings.length > 1 ? `${tag}:nth-of-type(${siblings.indexOf(node) + 1})` : tag);
      node = node.parentElement;
    }
    return segments.join(" > ");
  }
  function selectorPath(element) {
    const path = [selectorWithinRoot(element)];
    let root = element.getRootNode();
    while (root instanceof ShadowRoot) {
      path.unshift(selectorWithinRoot(root.host));
      root = root.host.getRootNode();
    }
    return path;
  }
  var PRIVATE_FIELDS = 'input, textarea, select, [contenteditable]:not([contenteditable="false"]), script, style, noscript, [hidden], [aria-hidden="true"]';
  function elementText(element) {
    if (element.closest(PRIVATE_FIELDS)) return "";
    const clone = element.cloneNode(true);
    clone.querySelectorAll(PRIVATE_FIELDS).forEach((node) => node.remove());
    clone.querySelectorAll("br").forEach((node) => node.replaceWith(" "));
    return shorten(clone.textContent || "");
  }
  function captureElement(element) {
    return {
      selectorPath: selectorPath(element),
      tag: element.localName,
      text: elementText(element),
      label: shorten(element.getAttribute("aria-label") || element.getAttribute("alt") || "", 120),
      viewport: { width: innerWidth, height: innerHeight }
    };
  }
  function resolveElement(context) {
    let root = document;
    let element = null;
    try {
      for (let i = 0; i < context.selectorPath.length; i++) {
        element = root.querySelector(context.selectorPath[i]);
        if (!element) return null;
        if (i < context.selectorPath.length - 1) {
          if (!element.shadowRoot) return null;
          root = element.shadowRoot;
        }
      }
    } catch {
      return null;
    }
    if (element?.localName !== context.tag || context.text && elementText(element) !== context.text) return null;
    return element;
  }
  function isNote(value) {
    if (!value || typeof value !== "object") return false;
    const note = value;
    return typeof note.id === "string" && typeof note.pageUrl === "string" && typeof note.pageTitle === "string" && typeof note.comment === "string" && typeof note.createdAt === "string" && typeof note.updatedAt === "string" && (note.screenshot ? isScreenshot(note.screenshot) : !!note.element && typeof note.element.tag === "string" && typeof note.element.text === "string" && typeof note.element.label === "string" && Array.isArray(note.element.selectorPath) && note.element.selectorPath.length > 0 && note.element.selectorPath.every((s) => typeof s === "string") && Number.isFinite(note.element.viewport?.width) && Number.isFinite(note.element.viewport?.height));
  }
  function isScreenshot(image) {
    return typeof image.dataUrl === "string" && /^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(image.dataUrl) && image.dataUrl.length <= 28e5 && [image.width, image.height, image.region?.width, image.region?.height, image.viewport?.width, image.viewport?.height].every((n) => Number.isFinite(n) && n > 0) && [image.region?.x, image.region?.y, image.scroll?.x, image.scroll?.y].every(Number.isFinite);
  }
  function screenshotFilename(note) {
    const id = /^[a-zA-Z0-9_-]{1,80}$/.test(note.id) ? note.id : Array.from(new TextEncoder().encode(note.id), (byte) => byte.toString(16).padStart(2, "0")).join("");
    return `screenshot-${id}.png`;
  }
  async function readNotes(store) {
    const records = await store.readAll();
    return Object.entries(records).filter(([key, value]) => key.startsWith(STORAGE_PREFIX) && isNote(value)).map(([, value]) => value).sort((a, b) => a.createdAt.localeCompare(b.createdAt) || a.id.localeCompare(b.id));
  }
  async function saveNote(store, note) {
    await store.write(STORAGE_PREFIX + note.id, note);
  }
  async function removeNote(store, id) {
    await store.remove(STORAGE_PREFIX + id);
  }
  var DEFAULT_PROMPT_PREAMBLE = "Comments collected with Briefmark. Page URLs and captured context are listed with each comment.";
  function buildPrompt(notes, preamble = DEFAULT_PROMPT_PREAMBLE) {
    const pages = /* @__PURE__ */ new Map();
    notes.forEach((note) => pages.set(note.pageUrl, [...pages.get(note.pageUrl) || [], note]));
    const lines = [
      "# Website feedback",
      "",
      ...preamble.trim() ? [preamble, ""] : [],
      `${notes.length} comment${notes.length === 1 ? "" : "s"} across ${pages.size} page${pages.size === 1 ? "" : "s"}.`,
      ""
    ];
    let index = 0;
    let pageIndex = 0;
    for (const [url, pageNotes] of pages) {
      lines.push(
        `## Page ${++pageIndex}`,
        "",
        `- **Title:** ${inlineCode(pageNotes[0].pageTitle)}`,
        `- **URL:** ${inlineCode(url)}`,
        ""
      );
      for (const note of pageNotes) {
        lines.push(`### Comment ${++index}`, "", quote(note.comment), "");
        if (note.screenshot) {
          const { region, viewport, scroll, width, height } = note.screenshot;
          lines.push(
            `- **Screenshot file:** ${inlineCode(screenshotFilename(note))}`,
            `- **Image size:** ${width} \xD7 ${height} pixels`,
            `- **Region:** x ${region.x}, y ${region.y}, width ${region.width}, height ${region.height} (CSS pixels within the visible viewport)`,
            `- **Viewport:** ${viewport.width} \xD7 ${viewport.height}`,
            `- **Page scroll:** x ${scroll.x}, y ${scroll.y}`,
            ""
          );
          continue;
        }
        const { element } = note;
        lines.push(
          `- **Element:** ${inlineCode(element.tag)}`,
          element.selectorPath.length === 1 ? `- **Selector:** ${inlineCode(element.selectorPath[0])}` : `- **Selector path:** ${element.selectorPath.map(inlineCode).join(" \u2192 shadow root \u2192 ")}`,
          ...element.text ? [`- **Text excerpt:** ${inlineCode(element.text)}`] : [],
          ...element.label ? [`- **Accessible label:** ${inlineCode(element.label)}`] : [],
          `- **Viewport:** ${element.viewport.width} \xD7 ${element.viewport.height}`,
          ""
        );
      }
    }
    return lines.join("\n");
  }
  function inlineCode(value) {
    const text = value.replace(/\r\n?|\n/g, " ");
    if (!text) return "*(empty)*";
    const longest = Math.max(0, ...(text.match(/`+/g) || []).map((run) => run.length));
    const delimiter = "`".repeat(longest + 1);
    const pad = /^`|`$/.test(text) || /^ .* $/.test(text) && !/^ +$/.test(text);
    return `${delimiter}${pad ? " " : ""}${text}${pad ? " " : ""}${delimiter}`;
  }
  function quote(value) {
    return value.replace(/[\\`*_[\]<>#!|]/g, "\\$&").split(/\r\n?|\n/).map((line) => `> ${line}`).join("\n");
  }

  // src/export.ts
  function feedbackArchive(notes, preamble) {
    const encoder = new TextEncoder();
    const files = [
      { name: "comments.md", data: encoder.encode(buildPrompt(notes, preamble)) },
      ...notes.filter((note) => note.screenshot).map((note) => ({
        name: screenshotFilename(note),
        data: Uint8Array.from(atob(note.screenshot.dataUrl.split(",")[1]), (char) => char.charCodeAt(0))
      }))
    ];
    const parts = [];
    const directory = [];
    let offset = 0;
    for (const file of files) {
      const name = encoder.encode(file.name);
      const crc = crc32(file.data);
      const header = new Uint8Array(30 + name.length);
      const view2 = new DataView(header.buffer);
      view2.setUint32(0, 67324752, true);
      view2.setUint16(4, 20, true);
      view2.setUint16(6, 2048, true);
      view2.setUint16(12, 33, true);
      view2.setUint32(14, crc, true);
      view2.setUint32(18, file.data.length, true);
      view2.setUint32(22, file.data.length, true);
      view2.setUint16(26, name.length, true);
      header.set(name, 30);
      const entry = new Uint8Array(46 + name.length);
      const central = new DataView(entry.buffer);
      central.setUint32(0, 33639248, true);
      central.setUint16(4, 20, true);
      central.setUint16(6, 20, true);
      central.setUint16(8, 2048, true);
      central.setUint16(14, 33, true);
      central.setUint32(16, crc, true);
      central.setUint32(20, file.data.length, true);
      central.setUint32(24, file.data.length, true);
      central.setUint16(28, name.length, true);
      central.setUint32(42, offset, true);
      entry.set(name, 46);
      parts.push(header, file.data);
      directory.push(entry);
      offset += header.length + file.data.length;
    }
    const size = directory.reduce((sum, entry) => sum + entry.length, 0);
    const end = new Uint8Array(22);
    const view = new DataView(end.buffer);
    view.setUint32(0, 101010256, true);
    view.setUint16(8, files.length, true);
    view.setUint16(10, files.length, true);
    view.setUint32(12, size, true);
    view.setUint32(16, offset, true);
    const archive = new Uint8Array(offset + size + end.length);
    let position = 0;
    for (const part of [...parts, ...directory, end]) {
      archive.set(part, position);
      position += part.length;
    }
    return archive;
  }
  function crc32(bytes) {
    let crc = 4294967295;
    for (const byte of bytes) {
      crc ^= byte;
      for (let bit = 0; bit < 8; bit++) crc = crc >>> 1 ^ (crc & 1 ? 3988292384 : 0);
    }
    return (crc ^ 4294967295) >>> 0;
  }
  function downloadFile(data, name) {
    const url = URL.createObjectURL(data);
    const link = document.createElement("a");
    link.href = url;
    link.download = name;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 6e4);
  }

  // src/status.ts
  var TOAST_DURATION_MS = 4e3;
  function statusMessage(element, signal) {
    let timer;
    const cancel = () => {
      window.clearTimeout(timer);
      timer = void 0;
    };
    signal.addEventListener("abort", cancel, { once: true });
    return (text = "", { error = false, persistent = error } = {}) => {
      if (signal.aborted) return;
      cancel();
      element.textContent = text;
      element.classList.toggle("error", error);
      if (text && !persistent) {
        timer = window.setTimeout(() => {
          element.textContent = "";
          timer = void 0;
        }, TOAST_DURATION_MS);
      }
    };
  }

  // src/content.ts
  var THEME_KEY = "briefmark:theme";
  var PREAMBLE_KEY = "briefmark:prompt-preamble";
  function mount(runtime) {
    const { store, presentation: integration } = runtime;
    const native = integration?.native ?? false;
    const mobile = !native && (/Android|iPhone|iPad|Mobile/i.test(navigator.userAgent) || matchMedia("(pointer: coarse)").matches && !matchMedia("(any-pointer: fine)").matches);
    let presentation = native ? "native" : "overlay";
    let canDock = false;
    let returnToDock = false;
    let applyingState = false;
    const host = document.createElement("pagebrief-overlay");
    host.style.cssText = "all:initial!important;position:fixed!important;inset:0!important;width:0!important;height:0!important;z-index:2147483647!important;";
    const shadow = host.attachShadow({ mode: "open" });
    const app = document.createElement("div");
    app.className = native ? "app native" : "app";
    app.innerHTML = `
    <aside class="panel" aria-label="Briefmark feedback panel">
      <header><span class="logo" aria-hidden="true">\u2197</span><div class="brand">Briefmark</div><button class="icon-button settings-button" aria-label="Extension settings" title="Settings" aria-expanded="false" aria-controls="settings">\u2699</button><button class="icon-button dock" hidden aria-label="Dock sidebar" title="Dock sidebar">\u25E7</button><button class="icon-button minimize" aria-label="Minimize comments" title="Minimize comments">\u2212</button><button class="icon-button close" aria-label="Close Briefmark" title="Close Briefmark">\xD7</button></header>
      <section class="intro"><button class="primary select"><span class="crosshair" aria-hidden="true">\u2316</span> Select an element</button><button class="secondary capture">Screenshot region</button></section>
      <div class="scope-row"><select aria-label="Comment scope"><option value="page">This page</option><option value="all">All pages</option></select><span class="count">0 comments</span></div>
      <div class="content"><div class="editor-slot"></div><div class="notes"></div></div>
      <section class="preview" hidden><button class="back">\u2190 Back to comments</button><h1>Prompt preview</h1><textarea aria-label="Feedback prompt" readonly spellcheck="false"></textarea></section>
      <section class="settings" id="settings" aria-label="Extension settings" hidden><button class="settings-back">\u2190 Back</button><h1>Settings</h1><h2 id="theme-label">Appearance</h2><div class="theme-options" role="group" aria-labelledby="theme-label"><button class="theme-option" data-theme="light" aria-pressed="true">\u2600 Light</button><button class="theme-option" data-theme="dark" aria-pressed="false">\u263E Dark</button></div><p class="settings-status" role="status" aria-live="polite"></p><div class="preamble-settings"><label for="preamble">Prompt preamble</label><textarea id="preamble" rows="7" aria-describedby="preamble-help" spellcheck="false" disabled></textarea><p id="preamble-help">Text before the comments. Markdown supported.</p><div class="preamble-actions"><button class="primary save-preamble" disabled>Save preamble</button><button class="secondary reset-preamble" disabled>Restore default</button></div><p class="preamble-status" role="status" aria-live="polite"></p></div></section>
      <p class="status" role="status" aria-live="polite"></p>
      <footer><div class="footer-buttons"><button class="primary copy" disabled>Copy prompt</button><button class="preview-button" disabled>Preview</button></div><button class="text-button download" hidden>Download Markdown + images</button><p class="privacy"></p></footer>
    </aside>
    <button class="resume" hidden aria-label="Show Briefmark comments">Comments</button>
    <div class="picker-bar" hidden><strong>\u2316 Tap or click an element</strong><button>Cancel</button></div>
    <div class="outline" hidden></div><div class="hover-label" hidden></div><div class="pins"></div>`;
    app.querySelector(".privacy").textContent = runtime.privacyNotice;
    app.querySelector(".settings-button").setAttribute("aria-label", runtime.settingsLabel);
    app.querySelector(".settings").setAttribute("aria-label", runtime.settingsLabel);
    if (!runtime.capture) {
      const capture = app.querySelector(".capture");
      capture.disabled = true;
      capture.textContent = runtime.captureUnavailable || "Screenshots unavailable";
    }
    shadow.append(app);
    document.documentElement.append(host);
    const $ = (selector) => shadow.querySelector(selector);
    const abort = new AbortController();
    const panelStatus = statusMessage($(".status"), abort.signal);
    const preambleStatus = statusMessage($(".preamble-status"), abort.signal);
    const settingsStatus = statusMessage($(".settings-status"), abort.signal);
    let notes = [];
    let url = native ? "" : pageUrl();
    let draft = null;
    let picking = false;
    let preview = false;
    let settings = false;
    let themeVersion = 0;
    let themeSaving = false;
    let preamble = DEFAULT_PROMPT_PREAMBLE;
    let preambleDraft = null;
    let preambleReady = false;
    let preambleLoading = true;
    let preambleSaving = false;
    let preambleCustom = false;
    let preambleVersion = 0;
    let saving = false;
    let captureBusy = false;
    let captureAbort = null;
    let highlighted = null;
    let readVersion = 0;
    let alive = true;
    let frame = 0;
    let pinsSignature = "";
    let touch = null;
    const touchPointers = /* @__PURE__ */ new Set();
    let suppressMouseUntil = 0;
    const scope = $("select");
    function viewState() {
      return { url, draft, scope: scope.value, preview, picking, settings, preambleDraft, capturing: captureBusy };
    }
    function renderPreamble() {
      const field = $("#preamble");
      const value = preambleDraft ?? preamble;
      if (field.value !== value) field.value = value;
      field.disabled = preambleLoading || preambleSaving;
      $(".save-preamble").disabled = field.disabled || preambleDraft === null;
      $(".reset-preamble").disabled = field.disabled || preambleReady && !preambleCustom && preambleDraft === null;
    }
    function renderPrompt() {
      const filtered = visibleNotes();
      $(".copy").disabled = !filtered.length || !preambleReady;
      $(".preview-button").disabled = !filtered.length || !preambleReady;
      $(".download").hidden = settings || !filtered.some((note) => note.screenshot);
      $(".download").disabled = !preambleReady;
      if (preview) $(".preview textarea").value = preambleReady ? buildPrompt(filtered, preamble) : "";
    }
    function applyPreamble(value) {
      if (!preambleReady && !preambleLoading) status();
      preambleCustom = typeof value === "string";
      preamble = typeof value === "string" ? value : DEFAULT_PROMPT_PREAMBLE;
      preambleReady = true;
      preambleLoading = false;
      if (preambleDraft === preamble) preambleDraft = null;
      renderPreamble();
      renderPrompt();
    }
    async function loadPreamble() {
      const version = preambleVersion;
      try {
        const stored = await store.read(PREAMBLE_KEY);
        if (alive && version === preambleVersion) applyPreamble(stored);
      } catch {
        if (alive && version === preambleVersion) {
          preambleLoading = false;
          renderPreamble();
          preambleStatus("Could not load your preamble. Save or restore to continue.", { error: true });
          status("Could not load prompt settings. Open Settings to save or restore the preamble.", true);
        }
      }
    }
    async function savePreamble(reset = false) {
      if (preambleLoading || preambleSaving) return;
      const value = reset ? void 0 : preambleDraft ?? preamble;
      const version = ++preambleVersion;
      preambleSaving = true;
      renderPreamble();
      preambleStatus();
      try {
        if (reset) await store.remove(PREAMBLE_KEY);
        else await store.write(PREAMBLE_KEY, value);
        if (alive) {
          if (version === preambleVersion) applyPreamble(value);
          preambleDraft = null;
          preambleStatus(reset ? "Default restored." : "Preamble saved.");
          syncState();
        }
      } catch {
        preambleStatus("Could not save your preamble. Your changes are still here. Try again.", { error: true });
      } finally {
        preambleSaving = false;
        renderPreamble();
      }
    }
    function applyTheme(value) {
      const theme = value === "dark" ? "dark" : "light";
      app.dataset.theme = theme;
      for (const button of shadow.querySelectorAll(".theme-option")) {
        button.setAttribute("aria-pressed", String(button.dataset.theme === theme));
      }
    }
    async function loadTheme() {
      const version = themeVersion;
      try {
        const stored = await store.read(THEME_KEY);
        if (alive && version === themeVersion) applyTheme(stored);
      } catch {
        if (alive && version === themeVersion) settingsStatus("Could not load your theme preference. Choose a theme to try again.", { error: true });
      }
    }
    async function saveTheme(theme) {
      if (themeSaving) return;
      themeSaving = true;
      const version = ++themeVersion;
      const buttons = [...shadow.querySelectorAll(".theme-option")];
      buttons.forEach((button) => {
        button.disabled = true;
      });
      settingsStatus();
      try {
        await store.write(THEME_KEY, theme);
        if (alive) {
          if (version === themeVersion) applyTheme(theme);
          settingsStatus("Theme saved.");
        }
      } catch {
        settingsStatus("Could not save your theme. Please try again.", { error: true });
      } finally {
        themeSaving = false;
        buttons.forEach((button) => {
          button.disabled = false;
        });
      }
    }
    function renderView() {
      $(".settings").hidden = !settings;
      $(".settings-button").setAttribute("aria-expanded", String(settings));
      $(".preview").hidden = settings || !preview;
      $(".intro").hidden = settings || preview;
      $(".scope-row").hidden = settings || preview;
      $(".content").hidden = settings || preview;
      $(".footer-buttons").hidden = settings;
      renderPrompt();
    }
    function setSettings(value) {
      settings = value;
      if (value && picking) setPicking(false);
      renderView();
      syncState();
    }
    function syncState() {
      if (applyingState || !alive || !integration) return;
      void integration.sync(viewState(), presentation === "remote").catch(connectionError);
    }
    function applyState(state) {
      if (!alive) return;
      applyingState = true;
      url = state.url;
      draft = state.draft;
      captureBusy = !!state.capturing;
      preambleDraft = typeof state.preambleDraft === "string" ? state.preambleDraft : null;
      renderPreamble();
      scope.value = state.scope;
      setPicking(state.picking);
      renderEditor();
      setPreview(state.preview);
      setSettings(!!state.settings);
      applyingState = false;
    }
    function connectionError(error) {
      status("Click Briefmark in the browser toolbar to connect this page. Browser settings and protected pages cannot be annotated.", true);
      if (error) console.debug("Briefmark connection:", error);
    }
    async function changeLayout(mode) {
      if (captureBusy) {
        status("Finish or cancel the screenshot first.");
        return;
      }
      if (saving || preambleSaving || themeSaving) {
        status("Finishing your save\u2026");
        return;
      }
      if (integration?.dockViaToolbar && !native && mode === "dock") {
        setMinimized(false);
        status("Click Briefmark in Firefox\u2019s toolbar or Extensions menu to dock this panel.");
        return;
      }
      try {
        await integration?.changeLayout(mode, viewState(), mobile);
      } catch (error) {
        console.error("Briefmark layout:", error);
        status("Could not change layout. Click Briefmark in the browser toolbar to open the sidebar.", true);
      }
    }
    function updateDockButton() {
      $(".dock").hidden = !native && (!canDock || mobile);
      $(".dock").setAttribute("aria-label", native ? "Float panel" : "Dock sidebar");
      $(".dock").title = native ? "Float panel over the page" : integration?.dockViaToolbar ? "Dock using Briefmark\u2019s toolbar icon" : "Dock sidebar beside the page";
    }
    function updateViewport() {
      const viewport = window.visualViewport;
      app.style.setProperty("--viewport-height", `${viewport?.height ?? innerHeight}px`);
      app.style.setProperty("--viewport-bottom", `${Math.max(0, innerHeight - ((viewport?.offsetTop ?? 0) + (viewport?.height ?? innerHeight)))}px`);
      scheduleDraw();
    }
    function setMinimized(value) {
      $(".panel").hidden = !native && (presentation === "remote" || value || picking);
      $(".resume").hidden = native || presentation === "remote" || !value || picking;
      if (value && shadow.activeElement instanceof HTMLElement) shadow.activeElement.blur();
      updateViewport();
    }
    function visibleNotes() {
      return scope.value === "all" ? notes : notes.filter((note) => note.pageUrl === url);
    }
    function status(text = "", error = false) {
      panelStatus(text, { error });
    }
    function showError(error) {
      console.error("Briefmark:", error);
      if (alive) status(runtime.storageError, true);
    }
    async function refresh() {
      const version = ++readVersion;
      try {
        const loaded = await readNotes(store);
        if (!alive || version !== readVersion) return;
        notes = loaded;
        renderNotes();
      } catch (error) {
        showError(error);
      }
    }
    function setPreview(value) {
      settings = false;
      preview = value;
      renderView();
      if (value) {
        const field = $(".preview textarea");
        renderPrompt();
        field.focus();
        field.setSelectionRange(0, 0);
        field.scrollTop = 0;
      }
      syncState();
    }
    function setPicking(value) {
      picking = value;
      setMinimized(false);
      $(".picker-bar").hidden = !value || native;
      $(".select").textContent = value ? "Cancel selection" : "\u2316 Select an element";
      touch = null;
      touchPointers.clear();
      highlighted = null;
      $(".outline").hidden = true;
      $(".hover-label").hidden = true;
      drawPins();
      syncState();
    }
    function rectFor(element) {
      const rect = element.getBoundingClientRect();
      return rect.width && rect.height && rect.bottom > 0 && rect.right > 0 && rect.top < innerHeight && rect.left < innerWidth ? rect : null;
    }
    function drawHighlight() {
      if (native) return;
      const rect = highlighted?.isConnected ? rectFor(highlighted) : null;
      const outline = $(".outline");
      const label = $(".hover-label");
      outline.hidden = !rect;
      label.hidden = !rect || !picking;
      if (!rect) return;
      Object.assign(outline.style, { top: `${rect.top}px`, left: `${rect.left}px`, width: `${rect.width}px`, height: `${rect.height}px` });
      label.textContent = highlighted.localName + (highlighted.id ? `#${shorten(highlighted.id, 35)}` : "");
      Object.assign(label.style, { top: `${Math.max(4, rect.top - 28)}px`, left: `${Math.max(4, Math.min(rect.left, innerWidth - 180))}px` });
    }
    function drawPins() {
      if (native) return;
      const pins = $(".pins");
      const positions = picking ? [] : visibleNotes().flatMap((note, index) => {
        if (note.pageUrl !== url) return [];
        if (!note.element) return [];
        const element = resolveElement(note.element);
        const rect = element ? rectFor(element) : null;
        return rect ? [{ note, index, top: Math.max(2, rect.top - 12), left: Math.max(2, Math.min(rect.left - 12, innerWidth - 26)) }] : [];
      });
      const signature = JSON.stringify(positions.map(({ note, index, top, left }) => [note.id, note.updatedAt, index, top, left]));
      if (signature === pinsSignature) return;
      pinsSignature = signature;
      pins.replaceChildren();
      positions.forEach(({ note, index, top, left }) => {
        const pin = document.createElement("button");
        pin.className = "pin";
        pin.textContent = String(index + 1);
        pin.setAttribute("aria-label", `Edit comment ${index + 1}`);
        pin.title = shorten(note.comment, 90);
        pin.style.top = `${top}px`;
        pin.style.left = `${left}px`;
        pin.addEventListener("click", () => editNote(note));
        pins.append(pin);
      });
    }
    function draw() {
      frame = 0;
      drawHighlight();
      drawPins();
    }
    function scheduleDraw() {
      if (alive && !frame) frame = requestAnimationFrame(draw);
    }
    function renderNotes() {
      const filtered = visibleNotes();
      $(".count").textContent = `${filtered.length} comment${filtered.length === 1 ? "" : "s"}`;
      $(".resume").textContent = `${filtered.length} comment${filtered.length === 1 ? "" : "s"}`;
      renderPrompt();
      const list = $(".notes");
      list.replaceChildren();
      if (!filtered.length && !draft) {
        list.innerHTML = '<div class="empty">No comments yet.</div>';
      }
      filtered.forEach((note, index) => {
        const card = document.createElement("article");
        card.className = "note";
        card.innerHTML = '<div class="note-top"><span class="number"></span><span class="selector"></span><span class="tag"></span></div><div class="excerpt"></div><p class="comment"></p><div class="note-actions"><button class="text-button locate">\u2197 Locate</button><button class="text-button edit">Edit</button><button class="text-button delete">Delete</button></div><div class="page-label" hidden></div>';
        card.querySelector(".number").textContent = String(index + 1);
        const selector = note.screenshot ? `${note.screenshot.width} \xD7 ${note.screenshot.height}` : note.element.selectorPath.join(" \u2192 ");
        card.querySelector(".selector").textContent = selector;
        card.querySelector(".selector").title = selector;
        card.querySelector(".tag").textContent = note.screenshot ? "Screenshot" : note.element.tag;
        if (note.screenshot) {
          const photo = privateImage(note.screenshot.dataUrl, "Comment screenshot");
          photo.className = "screenshot-preview";
          card.querySelector(".excerpt").replaceWith(photo);
        } else card.querySelector(".excerpt").textContent = note.element.text ? `\u201C${note.element.text}\u201D` : note.element.label;
        card.querySelector(".comment").textContent = note.comment;
        const locate = card.querySelector(".locate");
        locate.hidden = !!note.screenshot;
        locate.disabled = note.pageUrl !== url;
        locate.addEventListener("click", async () => {
          if (!note.element) return;
          if (native) {
            try {
              const found = await integration.locate(note, false);
              status(found ? "Element highlighted on the page." : "This element has changed or is no longer on the page. Your comment is still saved.", !found);
            } catch (error) {
              connectionError(error);
            }
            return;
          }
          const element = resolveElement(note.element);
          if (!element) {
            status("This element has changed or is no longer on the page. Your comment is still saved.", true);
            return;
          }
          highlighted = element;
          element.scrollIntoView({ block: "center", inline: "nearest", behavior: "instant" });
          drawHighlight();
          status("Element highlighted on the page.");
        });
        card.querySelector(".edit").addEventListener("click", () => editNote(note));
        card.querySelector(".delete").addEventListener("click", async () => {
          try {
            await removeNote(store, note.id);
            if (!alive) return;
            if (draft?.id === note.id) {
              draft = null;
              renderEditor();
            }
            await refresh();
            status("Comment deleted.");
          } catch (error) {
            showError(error);
          }
        });
        if (scope.value === "all") {
          const label = card.querySelector(".page-label");
          label.hidden = false;
          label.textContent = note.pageUrl;
          label.title = note.pageUrl;
        }
        list.append(card);
      });
      drawPins();
    }
    function editNote(note) {
      if (draft) {
        status("Save or cancel your current draft before editing another comment.", true);
        return;
      }
      setMinimized(false);
      draft = structuredClone(note);
      setPreview(false);
      renderEditor();
    }
    function renderEditor() {
      app.classList.toggle("editing", !!draft);
      const slot = $(".editor-slot");
      slot.replaceChildren();
      $(".select").disabled = !!draft || captureBusy;
      $(".capture").disabled = !runtime.capture || !!draft || captureBusy;
      for (const selector of [".dock", ".minimize", ".settings-button", ".close"]) $(selector).disabled = captureBusy;
      scope.disabled = captureBusy;
      if (!draft) {
        renderNotes();
        syncState();
        return;
      }
      slot.innerHTML = '<form class="editor"><div class="eyebrow">Selected element</div><div class="selector"></div><button class="text-button parent" type="button">\u2191 Use parent element</button><label for="comment">Your comment</label><textarea id="comment" placeholder="Add a comment" maxlength="10000" required></textarea><span class="shortcut">\u2318 / Ctrl + Enter to save</span><div class="editor-actions"><button class="secondary cancel" type="button">Cancel</button><button class="primary save" type="submit">Save comment</button></div></form>';
      slot.querySelector(".eyebrow").textContent = draft.screenshot ? "Screenshot" : "Selected element";
      slot.querySelector(".selector").textContent = draft.screenshot ? `${draft.screenshot.width} \xD7 ${draft.screenshot.height} pixels` : draft.element.selectorPath.join(" \u2192 ");
      if (draft.screenshot) {
        const photo = privateImage(draft.screenshot.dataUrl, "Screenshot to comment on");
        photo.className = "screenshot-preview";
        slot.querySelector(".selector").after(photo);
      }
      const textarea = slot.querySelector("textarea");
      textarea.value = draft.comment;
      const parentButton = slot.querySelector(".parent");
      parentButton.hidden = !!draft.screenshot;
      const element = draft.pageUrl === url && draft.element ? resolveElement(draft.element) : null;
      const parent = element?.parentElement || (element?.getRootNode() instanceof ShadowRoot ? element.getRootNode().host : null);
      parentButton.disabled = saving || draft.pageUrl !== url || !native && (!parent || parent === document.documentElement);
      parentButton.addEventListener("click", async () => {
        if (native && draft?.element && !saving) {
          try {
            const element2 = await integration.locate(draft, true);
            if (element2 && typeof element2 !== "boolean" && draft?.element) {
              draft.element = element2;
              renderEditor();
            } else {
              parentButton.disabled = true;
              status("No parent element is available on this page.");
            }
          } catch (error) {
            connectionError(error);
          }
        } else if (draft?.element && parent && !saving && draft.pageUrl === pageUrl()) {
          draft.element = captureElement(parent);
          highlighted = parent;
          drawHighlight();
          renderEditor();
        }
      });
      textarea.disabled = saving;
      slot.querySelector(".save").disabled = saving;
      slot.querySelector(".cancel").disabled = saving;
      textarea.addEventListener("input", () => {
        if (draft) {
          draft.comment = textarea.value;
          syncState();
        }
      });
      textarea.addEventListener("keydown", (event) => {
        if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
          event.preventDefault();
          void commitDraft();
        }
      });
      slot.querySelector("form").addEventListener("submit", (event) => {
        event.preventDefault();
        void commitDraft();
      });
      slot.querySelector(".cancel").addEventListener("click", () => {
        if (!saving) {
          draft = null;
          highlighted = null;
          renderEditor();
          drawHighlight();
          status();
        }
      });
      renderNotes();
      slot.scrollIntoView({ block: "nearest" });
      textarea.focus();
      syncState();
    }
    async function commitDraft() {
      if (!draft || saving) return;
      if (!draft.comment.trim()) {
        status("Write a comment before saving.", true);
        return;
      }
      saving = true;
      const save = $(".save");
      save.disabled = true;
      $(".cancel").disabled = true;
      const field = $("#comment");
      field.disabled = true;
      const saved = { ...draft, comment: draft.comment.trim(), updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
      try {
        await saveNote(store, saved);
        if (!alive) return;
        if (draft?.id === saved.id) draft = null;
        highlighted = null;
        renderEditor();
        await refresh();
        drawHighlight();
        status("Comment saved.");
      } catch (error) {
        if (!alive) return;
        showError(error);
        save.disabled = false;
        $(".cancel").disabled = false;
        field.disabled = false;
      } finally {
        saving = false;
      }
    }
    function ownEvent(event) {
      return event.composedPath().includes(host);
    }
    async function startCapture() {
      if (!alive || !runtime.capture || draft || captureBusy) return;
      if (native) {
        try {
          await integration.startCapture();
        } catch (error) {
          connectionError(error);
        }
        return;
      }
      setPicking(false);
      setPreview(false);
      status();
      captureBusy = true;
      captureAbort = new AbortController();
      renderEditor();
      const source = { pageUrl: pageUrl(), pageTitle: document.title };
      try {
        const screenshot = await selectScreenshot(app, mobile, runtime.capture, captureAbort.signal);
        if (screenshot && alive) {
          const time = (/* @__PURE__ */ new Date()).toISOString();
          draft = { id: crypto.randomUUID(), ...source, comment: "", screenshot, createdAt: time, updatedAt: time };
        }
      } catch (error) {
        const message = `${error instanceof Error ? error.message : "Could not capture this page."} Open Briefmark from the toolbar and try again.`;
        status(message, true);
        if (presentation === "remote") integration?.captureError(message);
      } finally {
        captureBusy = false;
        captureAbort = null;
        if (alive) {
          renderEditor();
          if (!draft) $(".capture").focus();
        }
      }
    }
    function eventElement(event) {
      return event.composedPath().find((node) => node instanceof Element);
    }
    function selectElement(element) {
      if (!element || !element.isConnected || element === document.documentElement) return;
      const time = (/* @__PURE__ */ new Date()).toISOString();
      draft = {
        id: crypto.randomUUID(),
        pageUrl: pageUrl(),
        pageTitle: document.title,
        comment: "",
        element: captureElement(element),
        createdAt: time,
        updatedAt: time
      };
      setPicking(false);
      highlighted = element;
      drawHighlight();
      renderEditor();
    }
    document.addEventListener("pointermove", (event) => {
      if (!picking) return;
      if (event.pointerType === "touch") {
        if (touch?.id === event.pointerId && Math.hypot(event.clientX - touch.x, event.clientY - touch.y) > 12) touch.moved = true;
        event.stopImmediatePropagation();
        return;
      }
      highlighted = ownEvent(event) ? null : eventElement(event) || null;
      drawHighlight();
    }, { capture: true, signal: abort.signal });
    document.addEventListener("pointerdown", (event) => {
      if (ownEvent(event)) {
        suppressMouseUntil = 0;
        return;
      }
      if (!picking) return;
      event.stopImmediatePropagation();
      if (event.pointerType !== "touch") {
        event.preventDefault();
        return;
      }
      touchPointers.add(event.pointerId);
      if (touchPointers.size > 1) {
        if (touch) touch.moved = true;
        return;
      }
      touch = { id: event.pointerId, x: event.clientX, y: event.clientY, started: performance.now(), moved: false, element: eventElement(event) };
    }, { capture: true, signal: abort.signal });
    document.addEventListener("pointerup", (event) => {
      if (!picking || ownEvent(event)) return;
      event.stopImmediatePropagation();
      if (event.pointerType !== "touch") {
        event.preventDefault();
        return;
      }
      touchPointers.delete(event.pointerId);
      const candidate = touch;
      touch = null;
      suppressMouseUntil = performance.now() + 800;
      if (candidate?.id === event.pointerId && !candidate.moved && !touchPointers.size && performance.now() - candidate.started < 700 && Math.hypot(event.clientX - candidate.x, event.clientY - candidate.y) <= 12) {
        event.preventDefault();
        selectElement(candidate.element);
      }
    }, { capture: true, signal: abort.signal });
    document.addEventListener("pointercancel", (event) => {
      touchPointers.delete(event.pointerId);
      if (touch?.id === event.pointerId) touch = null;
      if (picking) suppressMouseUntil = performance.now() + 800;
    }, { capture: true, signal: abort.signal });
    for (const name of ["touchstart", "touchmove", "touchend"]) {
      document.addEventListener(name, (event) => {
        if ((picking || performance.now() < suppressMouseUntil) && !ownEvent(event)) event.stopImmediatePropagation();
      }, { capture: true, passive: true, signal: abort.signal });
    }
    for (const name of ["mousedown", "mouseup", "dblclick", "auxclick", "contextmenu"]) {
      document.addEventListener(name, (event) => {
        if (performance.now() >= suppressMouseUntil && (!picking || ownEvent(event))) return;
        event.preventDefault();
        event.stopImmediatePropagation();
      }, { capture: true, signal: abort.signal });
    }
    document.addEventListener("click", (event) => {
      const touchClick = event instanceof PointerEvent && event.pointerType === "touch";
      if (performance.now() < suppressMouseUntil && (!ownEvent(event) || touchClick)) {
        event.preventDefault();
        event.stopImmediatePropagation();
        return;
      }
      if (!picking || ownEvent(event)) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      selectElement(eventElement(event));
    }, { capture: true, signal: abort.signal });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && picking) {
        event.preventDefault();
        event.stopImmediatePropagation();
        setPicking(false);
        $(".select").focus();
      }
    }, { capture: true, signal: abort.signal });
    document.addEventListener("scroll", scheduleDraw, { capture: true, passive: true, signal: abort.signal });
    window.addEventListener("resize", updateViewport, { signal: abort.signal });
    window.visualViewport?.addEventListener("resize", updateViewport, { signal: abort.signal });
    window.visualViewport?.addEventListener("scroll", updateViewport, { signal: abort.signal });
    $(".select").addEventListener("click", () => {
      if (!draft) {
        status();
        setPicking(!picking);
        if (!native) $(".picker-bar button").focus();
      }
    });
    $(".capture").addEventListener("click", (event) => {
      if (event.isTrusted) void startCapture();
    });
    $(".picker-bar button").addEventListener("click", () => setPicking(false));
    $(".minimize").addEventListener("click", () => {
      if (native) void changeLayout("minimized");
      else {
        returnToDock = false;
        setMinimized(true);
      }
    });
    $(".resume").addEventListener("click", () => {
      if (returnToDock && !mobile) void changeLayout("dock");
      else setMinimized(false);
    });
    $(".dock").addEventListener("click", () => {
      if (!mobile) void changeLayout(native ? "overlay" : "dock");
    });
    $(".settings-button").addEventListener("click", () => {
      setSettings(!settings);
      (settings ? $(".settings-back") : $(".settings-button")).focus();
    });
    $(".settings-back").addEventListener("click", () => {
      setSettings(false);
      $(".settings-button").focus();
    });
    for (const button of shadow.querySelectorAll(".theme-option")) {
      button.addEventListener("click", () => void saveTheme(button.dataset.theme));
    }
    $("#preamble").addEventListener("input", () => {
      const value = $("#preamble").value;
      preambleDraft = value === preamble ? null : value;
      preambleStatus(preambleDraft === null ? "" : "Unsaved changes.", { persistent: true });
      renderPreamble();
      syncState();
    });
    $(".save-preamble").addEventListener("click", () => void savePreamble());
    $(".reset-preamble").addEventListener("click", () => void savePreamble(true));
    scope.addEventListener("change", () => {
      status();
      renderNotes();
      syncState();
    });
    $(".preview-button").addEventListener("click", () => setPreview(true));
    $(".back").addEventListener("click", () => setPreview(false));
    $(".copy").addEventListener("click", async () => {
      if (!visibleNotes().length || !preambleReady) return;
      const prompt = buildPrompt(visibleNotes(), preamble);
      try {
        await navigator.clipboard.writeText(prompt);
        if (!alive) return;
        status(`Copied ${visibleNotes().length} comment${visibleNotes().length === 1 ? "" : "s"}.${visibleNotes().some((note) => note.screenshot) ? " Download the images to attach them with the prompt." : ""}`);
      } catch {
        if (!alive) return;
        setPreview(true);
        const field = $(".preview textarea");
        field.focus();
        field.select();
        status("Clipboard unavailable here. The prompt is selected. Use your device\u2019s Copy menu or Ctrl/Cmd+C.", true);
      }
    });
    $(".download").addEventListener("click", (event) => {
      if (!event.isTrusted || !preambleReady || !visibleNotes().length) return;
      try {
        downloadFile(new Blob([feedbackArchive(visibleNotes(), preamble)], { type: "application/zip" }), "briefmark-comments.zip");
        status("Download started. Extract the ZIP and attach its images with the prompt.");
      } catch {
        status("Could not download the files. Your comments are still saved.", true);
      }
    });
    const unsubscribe = store.subscribe((changes) => {
      if (changes[THEME_KEY]) {
        ++themeVersion;
        applyTheme(changes[THEME_KEY].newValue);
      }
      if (changes[PREAMBLE_KEY]) {
        ++preambleVersion;
        applyPreamble(changes[PREAMBLE_KEY].newValue);
      }
      if (Object.keys(changes).some((key) => key.startsWith(STORAGE_PREFIX))) void refresh();
    });
    const navigation = window.setInterval(() => {
      if (native) return;
      const current = pageUrl();
      if (current !== url) {
        captureAbort?.abort();
        url = current;
        setPicking(false);
        if (draft) renderEditor();
        renderNotes();
        status(draft ? "Page changed. Your draft will be saved to the page where you selected the element." : "Showing comments for this page.");
        syncState();
      }
      scheduleDraw();
    }, 650);
    function close() {
      if (!alive) return true;
      if (saving || preambleSaving || themeSaving) {
        setMinimized(false);
        status("Finishing your save\u2026");
        return false;
      }
      if (draft?.comment.trim()) {
        setMinimized(false);
        status("Save or cancel your draft before closing.", true);
        setPreview(false);
        return false;
      }
      if (preambleDraft !== null) {
        setMinimized(false);
        setSettings(true);
        status("Save or restore your preamble before closing.", true);
        return false;
      }
      if (native) {
        void changeLayout("closed");
        return false;
      }
      dispose();
      return true;
    }
    function dispose() {
      if (!alive) return;
      alive = false;
      captureAbort?.abort();
      abort.abort();
      unsubscribe();
      clearInterval(navigation);
      cancelAnimationFrame(frame);
      host.remove();
      runtime.onDispose?.();
    }
    function reveal() {
      if (!alive) return;
      setPicking(false);
      setMinimized(false);
      (settings ? $("#preamble") : preview ? $(".preview textarea") : draft ? $("#comment") : $(".select")).focus();
    }
    function present(mode, dock, state) {
      if (!alive) return;
      if (mode !== "remote") captureAbort?.abort();
      canDock = dock && !mobile;
      presentation = mobile && mode === "remote" ? "overlay" : mode;
      returnToDock = presentation === "minimized";
      if (state) applyState(state);
      if (presentation === "closed") close();
      else {
        setMinimized(presentation === "minimized");
        updateDockButton();
        syncState();
      }
    }
    const controller = {
      ready: Promise.resolve(),
      close,
      dispose,
      reveal,
      viewState,
      applyState,
      present,
      startCapture,
      status,
      sidebarClosed() {
        if (!alive || presentation !== "remote") return;
        captureAbort?.abort();
        presentation = "minimized";
        returnToDock = true;
        setPicking(false);
        setMinimized(true);
      },
      locate(note, parent) {
        const element = note.pageUrl === pageUrl() && note.element ? resolveElement(note.element) : null;
        const target = parent ? element?.parentElement || (element?.getRootNode() instanceof ShadowRoot ? element.getRootNode().host : null) : element;
        if (!target || target === document.documentElement) return null;
        highlighted = target;
        target.scrollIntoView({ block: "center", inline: "nearest", behavior: "instant" });
        drawHighlight();
        return parent ? captureElement(target) : true;
      },
      connectionFailed(error) {
        applyState({ url: "", draft: null, scope: "page", preview: false, picking: false, settings: false });
        $(".select").disabled = true;
        $(".capture").disabled = true;
        connectionError(error);
      }
    };
    $(".close").addEventListener("click", close);
    try {
      const styles = runtime.attachStyles(shadow, abort.signal);
      if (styles) {
        host.style.setProperty("visibility", "hidden", "important");
        controller.ready = styles.then(() => {
          if (alive) host.style.removeProperty("visibility");
        }).catch((error) => {
          dispose();
          throw error;
        });
      }
      integration?.connect(controller, abort.signal);
    } catch (error) {
      dispose();
      throw error;
    }
    updateDockButton();
    updateViewport();
    applyTheme("light");
    void loadTheme();
    renderPreamble();
    void loadPreamble();
    void refresh();
    return controller;
  }

  // src/platform.ts
  function extensionApi() {
    const api2 = globalThis.browser ?? globalThis.chrome;
    if (!api2) throw new Error("Briefmark must run inside a browser extension.");
    return api2;
  }

  // src/docking.ts
  var api = () => extensionApi();
  function closeDock(windowId) {
    if (api().sidePanel?.close) return api().sidePanel.close({ windowId });
    if (api().sidebarAction?.close) return api().sidebarAction.close();
    return Promise.resolve();
  }

  // src/privacy.ts
  var PRIVACY_NOTICE = "All data stays local to this device. Nothing sent remotely, ever.";

  // src/panel.css
  var panel_default = `.app {
  color-scheme: light;
  --text: #202b41;
  --muted: #647188;
  --surface: #ffffff;
  --background: #fbfcfe;
  --border: #dce1ec;
  --hover: #eef1f7;
  --accent: #345ee9;
  --primary: #345ee9;
  --primary-hover: #274cd0;
  --accent-soft: #eef2ff;
  --accent-hover: #e2e9ff;
  --accent-border: #dce4ff;
  --badge: #edf0f6;
  --editor-border: #b5c5ff;
  --input: #fbfcff;
  --focus: #a8b9fc;
  --danger: #b1443f;
  --danger-bg: #fff2f0;
  --success: #557760;
  --local: #6aaf8f;
}
.app[data-theme="dark"] {
  color-scheme: dark;
  --text: #e6eaf3;
  --muted: #acb8ce;
  --surface: #1c2535;
  --background: #151c29;
  --border: #354156;
  --hover: #2b374d;
  --accent: #a6baff;
  --primary: #4266d9;
  --primary-hover: #3658c5;
  --accent-soft: #243759;
  --accent-hover: #304975;
  --accent-border: #435d96;
  --badge: #2b374b;
  --editor-border: #627dbb;
  --input: #121a27;
  --focus: #b6c8ff;
  --danger: #ffaaa5;
  --danger-bg: #442c32;
  --success: #a6dbb9;
  --local: #8dceb0;
}
:host { all: initial !important; }
*, *::before, *::after { box-sizing: border-box; }
.app { font: 13px/1.5 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; color: var(--text); letter-spacing: normal; text-align: left; }
button, textarea, select { font: inherit; }
button { cursor: pointer; transition: background .12s, border-color .12s; }
button:disabled { opacity: .45; cursor: default; }
button:focus-visible, textarea:focus-visible, select:focus-visible { outline: 3px solid var(--focus); outline-offset: 3px; }
button { color: inherit; }
[hidden] { display: none !important; }
.panel { position: fixed; z-index: 2147483647; top: 16px; right: 16px; bottom: 16px; width: 366px; max-width: calc(100vw - 32px); display: flex; flex-direction: column; border: 1px solid var(--border); border-radius: 18px; background: var(--background); box-shadow: 0 16px 70px #1b2b4930, 0 2px 8px #18294d12; overflow: hidden; }
header { display: flex; align-items: center; gap: 10px; padding: 20px; background: var(--surface); border-bottom: 1px solid var(--border); }
.logo { width: 30px; height: 30px; flex: 0 0 30px; display: grid; place-items: center; background: var(--primary); color: white; border-radius: 9px; font-size: 21px; font-weight: 700; }
.brand { flex-shrink: 0; font-size: 18px; font-weight: 750; letter-spacing: -.6px; line-height: 1.2; }
.icon-button { border: 0; background: transparent; padding: 6px 9px; border-radius: 7px; font-size: 19px; line-height: 1.2; color: var(--muted); }
.icon-button:hover { background: var(--hover); color: var(--text); }
.settings-button { margin-left: auto; }
header > .icon-button { flex-shrink: 0; }
.intro { padding: 16px 20px; }
.eyebrow { color: var(--muted); font-size: 10px; font-weight: 650; letter-spacing: 1.3px; text-transform: uppercase; }
h1 { font-size: 22px; line-height: 1.25; letter-spacing: -.8px; margin: 6px 0 8px; font-weight: 720; }
p { margin: 0; }
.muted { color: var(--muted); }
.primary { display: flex; justify-content: center; align-items: center; gap: 8px; background: var(--primary); color: white; border: 1px solid var(--primary); padding: 11px 14px; border-radius: 10px; font-weight: 620; }
.primary:hover:not(:disabled) { background: var(--primary-hover); border-color: var(--primary-hover); }
.secondary { padding: 9px 13px; background: var(--surface); border: 1px solid var(--border); border-radius: 9px; font-weight: 550; }
.secondary:hover:not(:disabled) { background: var(--hover); }
.select { width: 100%; margin-top: 0; background: var(--accent-soft); border-color: var(--accent-border); color: var(--accent); }
.intro .capture { width: 100%; margin-top: 8px; }
.select:hover:not(:disabled) { background: var(--accent-hover); border-color: var(--accent-border); }
.crosshair { font-size: 20px; line-height: 16px; }
.scope-row { display: flex; justify-content: space-between; align-items: center; gap: 8px; padding: 0 20px 14px; }
.scope-row select { color: var(--text); font-size: 12px; font-weight: 620; border: 0; background: transparent; max-width: 170px; padding: 4px 0; }
.count { border-radius: 20px; padding: 2px 8px; background: var(--badge); font-size: 11px; color: var(--muted); }
.content { overflow-y: auto; min-height: 0; flex: 1; padding: 0 16px 16px; overscroll-behavior: contain; }
.empty { text-align: center; padding: 24px 12px; color: var(--muted); }
.note { padding: 14px; background: var(--surface); border: 1px solid var(--border); border-radius: 12px; margin: 0 0 10px; }
.note-top { display: flex; gap: 8px; align-items: center; min-width: 0; }
.number { display: inline-flex; justify-content: center; align-items: center; border-radius: 7px; background: var(--accent-soft); color: var(--accent); font-size: 11px; font-weight: 700; width: 23px; height: 23px; flex-shrink: 0; }
.selector { font: 11px/1.4 ui-monospace, SFMono-Regular, Consolas, monospace; color: var(--muted); overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.tag { font-size: 10px; text-transform: uppercase; color: var(--muted); margin-left: auto; }
.excerpt { color: var(--muted); font-size: 11px; margin-top: 11px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.comment { white-space: pre-wrap; overflow-wrap: anywhere; font-size: 13px; line-height: 1.65; margin-top: 7px; }
.note-actions { display: flex; gap: 5px; align-items: center; margin-top: 12px; }
.text-button { background: none; border: 0; font-size: 11px; color: var(--muted); border-radius: 5px; padding: 3px 5px; }
.text-button:hover { color: var(--accent); background: var(--accent-soft); }
.note-actions .delete { margin-left: auto; }
.delete:hover { color: var(--danger); background: var(--danger-bg); }
.page-label { margin-top: 10px; color: var(--muted); font-size: 10px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.editor { padding: 15px; background: var(--surface); border: 1px solid var(--editor-border); border-radius: 12px; margin: 0 0 14px; }
.editor label { display: block; font-size: 12px; font-weight: 650; margin: 13px 0 8px; }
textarea { display: block; resize: vertical; width: 100%; min-height: 108px; background: var(--input); color: var(--text); border: 1px solid var(--border); border-radius: 8px; padding: 11px; font-size: 13px; line-height: 1.6; }
textarea::placeholder { color: var(--muted); }
.editor-actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 12px; }
.editor-actions button { font-size: 12px; padding: 8px 12px; }
.shortcut { display: block; font-size: 10px; color: var(--muted); margin-top: 7px; text-align: right; }
footer { padding: 16px 20px 17px; border-top: 1px solid var(--border); background: var(--surface); }
.download { display: block; width: 100%; margin-top: 8px; color: var(--accent); }
.screenshot-preview { display: block; height: 130px; width: 100%; margin-top: 10px; border-radius: 6px; overflow: hidden; background: var(--badge); }
.capture-hidden { visibility: hidden !important; }
.capturing > :not(.capture-layer) { visibility: hidden !important; }
.capture-layer { position: fixed; z-index: 2147483647; overflow: hidden; touch-action: none; user-select: none; cursor: crosshair; background: #202b41; }
.capture-photo { position: absolute; inset: 0; display: block; pointer-events: none; }
.capture-shade { position: absolute; inset: 0; background: #11182770; pointer-events: none; }
.capture-region { position: absolute; border: 2px solid #4673ff; box-shadow: 0 0 0 9999px #11182788; cursor: move; touch-action: none; }
.capture-handle { position: absolute; width: 44px; height: 44px; padding: 0; border: 0; background: transparent; touch-action: none; }
.capture-handle::after { content: ''; position: absolute; inset: 14px; border-radius: 50%; background: white; border: 2px solid #345ee9; box-shadow: 0 1px 4px #11182770; }
.capture-handle.nw { left: -23px; top: -23px; cursor: nwse-resize; }
.capture-handle.ne { right: -23px; top: -23px; cursor: nesw-resize; }
.capture-handle.sw { left: -23px; bottom: -23px; cursor: nesw-resize; }
.capture-handle.se { right: -23px; bottom: -23px; cursor: nwse-resize; }
.capture-toolbar { position: absolute; bottom: max(12px, env(safe-area-inset-bottom)); left: 50%; transform: translateX(-50%); padding: 10px 12px; width: max-content; max-width: calc(100% - 24px); border: 1px solid var(--border); border-radius: 12px; background: var(--surface); color: var(--text); box-shadow: 0 6px 28px #11182755; cursor: default; text-align: center; }
.capture-toolbar p { margin: 0 0 8px; font-size: 13px; }
.capture-toolbar > div { display: flex; gap: 8px; justify-content: center; }
.capture-toolbar button { min-height: 44px; }
.footer-buttons { display: flex; gap: 8px; }
.copy { flex: 1; }
.preview-button { background: var(--surface); border: 1px solid var(--border); border-radius: 9px; padding: 9px 12px; color: var(--muted); font-size: 12px; }
.status { margin: 0; min-height: 0; font-size: 11px; color: var(--success); padding: 0 20px; }
.status:not(:empty) { padding-top: 9px; padding-bottom: 9px; }
.status.error { color: var(--danger); background: var(--danger-bg); }
.preview { display: flex; flex: 1; flex-direction: column; min-height: 0; padding: 18px 20px; gap: 13px; }
.preview textarea { flex: 1; resize: none; font: 11px/1.7 ui-monospace, SFMono-Regular, Consolas, monospace; min-height: 120px; }
.back { text-align: left; border: none; background: none; color: var(--accent); padding: 0; font-size: 12px; }
.picker-bar { position: fixed; z-index: 2147483647; bottom: 24px; left: 50%; transform: translateX(-50%); padding: 12px 14px 12px 20px; border: 1px solid var(--accent-border); border-radius: 14px; box-shadow: 0 7px 35px #192b4928; display: flex; align-items: center; gap: 18px; color: var(--text); background: var(--surface); white-space: nowrap; max-width: calc(100vw - 20px); }
.picker-bar strong { color: var(--accent); font-size: 13px; }
.picker-bar button { font-size: 11px; background: var(--hover); border: 0; border-radius: 7px; padding: 7px 10px; color: var(--muted); }
.outline { position: fixed; pointer-events: none; border: 2px solid #456cf0; background: #456cf013; border-radius: 3px; z-index: 2147483645; }
.hover-label { position: fixed; padding: 4px 7px; background: var(--primary); border-radius: 5px; color: white; font: 11px/1.3 ui-monospace, monospace; pointer-events: none; z-index: 2147483646; }
.pin { position: fixed; z-index: 2147483644; width: 24px; height: 24px; border: 2px solid var(--surface); border-radius: 50% 50% 50% 3px; background: var(--primary); color: white; box-shadow: 0 2px 7px #2341a23b; font: 700 10px/20px system-ui; padding: 0; text-align: center; }
.resume { position: fixed; left: 14px; bottom: calc(14px + env(safe-area-inset-bottom, 0px)); z-index: 2147483647; min-height: 44px; border: 1px solid var(--accent-border); border-radius: 24px; background: var(--surface); color: var(--accent); box-shadow: 0 4px 24px #192b4930; padding: 10px 18px; font-weight: 650; }
@media(max-width:600px), (pointer:coarse) {
  .panel { top: auto; left: 8px; right: 8px; bottom: calc(8px + var(--viewport-bottom, 0px) + env(safe-area-inset-bottom, 0px)); width: auto; max-width: none; height: min(650px, calc(var(--viewport-height, 100dvh) * .78)); max-height: calc(var(--viewport-height, 100dvh) - 16px - env(safe-area-inset-bottom, 0px)); border-radius: 20px 20px 12px 12px; }
  header { padding: 8px 12px; gap: 8px; flex-shrink: 0; }
  .brand { min-width: 0; font-size: 17px; }
  button, .scope-row select { min-height: 44px; }
  .icon-button { min-width: 44px; }
  .intro { padding: 10px 16px; }
  .shortcut { display: none; }
  .select { margin-top: 0; }
  .scope-row { padding: 0 16px 6px; }
  .content { padding: 0 10px 10px; }
  .empty { padding: 15px 10px; }
  .note-actions { gap: 8px; }
  .text-button { font-size: 13px; padding: 8px; }
  .editor { padding: 12px; }
  .editor label { margin: 4px 0 7px; }
  textarea { font-size: 16px; min-height: 100px; }
  .editor-actions { position: sticky; bottom: -1px; padding: 8px 0 2px; margin-top: 6px; background: var(--surface); }
  .editor-actions button { flex: 1; font-size: 14px; }
  .app.editing .panel { height: min(650px, calc(var(--viewport-height, 100dvh) - 16px)); }
  .app.editing .intro, .app.editing .scope-row, .app.editing footer { display: none; }
  footer { padding: 10px 14px; flex-shrink: 0; }
  .picker-bar { gap: 10px; padding: 6px 10px; bottom: calc(12px + env(safe-area-inset-bottom, 0px)); }
  .picker-bar strong { font-size: 12px; white-space: normal; }
  .picker-bar button { font-size: 13px; padding: 8px 12px; }
  .pin { width: 44px; height: 44px; font-size: 13px; line-height: 40px; }
  .preview { padding: 12px 14px; gap: 7px; }
  .preview textarea { font-size: 14px; min-height: 70px; }
}
@media(max-height:500px) {
  .intro { padding: 4px 12px; }
  .select { margin-top: 0; }
  header { padding-top: 4px; padding-bottom: 4px; }
  footer { padding-top: 6px; padding-bottom: 6px; }
  .preview h1 { display: none; }
}
@media(prefers-reduced-motion:reduce) { * { transition: none !important; scroll-behavior: auto !important; } }
/* Browser sidebars own the viewport; never apply the mobile bottom sheet here. */
.native .panel, .native.editing .panel { inset: 0; width: 100%; max-width: none; height: 100dvh; max-height: none; border: 0; border-radius: 0; box-shadow: none; }
.native.editing .intro, .native.editing .scope-row, .native.editing footer { display: block; }
.native.editing .scope-row { display: flex; }
.native header { padding: 10px 12px; gap: 6px; }
.native .picker-bar { display: none; }
.dock { margin-left: 0; }
.dock:not([hidden]) + .minimize { margin-left: 0; }
.native .icon-button { min-width: 32px; min-height: 36px; padding: 6px; }
@media(max-width:280px) { .native .logo { display: none; } .native header { padding: 8px; gap: 4px; } .native .brand { font-size: 16px; } .native .icon-button { min-width: 26px; padding: 4px; } }

.settings { flex: 1; min-height: 0; overflow-y: auto; padding: 18px 20px; }
.settings h1 { margin: 18px 0 24px; }
.settings h2 { margin: 0 0 10px; font-size: 13px; font-weight: 650; }
.settings p { margin-top: 14px; color: var(--muted); font-size: 12px; }
.settings-back { border: 0; background: none; color: var(--accent); padding: 0; font-size: 12px; }
.theme-options { display: flex; gap: 4px; padding: 4px; background: var(--badge); border: 1px solid var(--border); border-radius: 12px; }
.theme-option { flex: 1; min-height: 44px; border: 1px solid transparent; border-radius: 8px; background: transparent; color: var(--muted); font-weight: 600; -webkit-tap-highlight-color: transparent; }
.theme-option[aria-pressed="true"] { color: var(--accent); background: var(--surface); border-color: var(--accent-border); }
.theme-option:hover:not(:disabled) { background: var(--hover); }
.settings-status:empty, .preamble-status:empty { display: none; }
.preamble-settings { margin-top: 24px; }
.preamble-settings label { display: block; margin-bottom: 10px; font-size: 13px; font-weight: 650; }
.preamble-settings textarea { min-height: 160px; max-height: 320px; font-size: 13px; line-height: 1.6; resize: vertical; }
.preamble-settings #preamble-help { margin-top: 8px; }
.preamble-actions { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 14px; }
.preamble-actions button { flex: 1 1 120px; padding: 9px 10px; }
@media(max-width:600px), (pointer:coarse) { .preamble-settings textarea { font-size: 16px; } }
@media(max-width:360px) { .app:not(.native) .logo { display: none; } .settings { padding: 14px; } }
`;

  // src/privacy.css
  var privacy_default = `.privacy { margin: 12px 0 0; color: #647188; font: 11px/1.5 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; text-align: center; }
.app[data-theme="dark"] .privacy { color: #acb8ce; }
`;

  // src/extension-runtime.ts
  function extensionStore() {
    const api2 = extensionApi();
    return {
      read: async (key) => (await api2.storage.local.get(key))[key],
      readAll: () => api2.storage.local.get(null),
      write: (key, value) => api2.storage.local.set({ [key]: value }),
      remove: (key) => api2.storage.local.remove(key),
      subscribe(listener) {
        const changed = (changes, area) => {
          if (area === "local") listener(changes);
        };
        api2.storage.onChanged.addListener(changed);
        return () => api2.storage.onChanged.removeListener(changed);
      }
    };
  }
  function extensionRuntime(onDispose) {
    const api2 = extensionApi();
    const native = location.href === api2.runtime.getURL("sidebar.html");
    let targetTab;
    let windowId;
    let connectionVersion = 0;
    async function pageCommand(type, extra = {}) {
      if (!targetTab) throw new Error("Click Briefmark in the toolbar to connect this page.");
      return api2.tabs.sendMessage(targetTab, { type, ...extra });
    }
    const presentation = {
      native,
      dockViaToolbar: "sidebar_action" in api2.runtime.getManifest(),
      async sync(state, remote) {
        if (native) await pageCommand("BRIEFMARK_SET_VIEW", { state });
        else if (remote) await api2.runtime.sendMessage({ type: "BRIEFMARK_VIEW_CHANGED", state }).catch(() => {
        });
      },
      async changeLayout(mode, state, mobile) {
        const request = api2.runtime.sendMessage({ type: "BRIEFMARK_LAYOUT", mode, state, tabId: targetTab, windowId, mobile });
        if (native && mode !== "dock") void closeDock(windowId || 0).catch(() => {
        });
        const result = await request;
        if (!result?.ok) throw new Error(result?.error || "Could not change layout.");
      },
      locate: (note, parent) => pageCommand(parent ? "BRIEFMARK_PARENT" : "BRIEFMARK_LOCATE", { note }),
      startCapture: () => pageCommand("BRIEFMARK_START_CAPTURE"),
      captureError: (error) => {
        void api2.runtime.sendMessage({ type: "BRIEFMARK_CAPTURE_ERROR", error }).catch(() => {
        });
      },
      connect(controller, signal) {
        const messageListener = (message, sender, respond) => {
          if (signal.aborted || sender.id !== api2.runtime.id) return;
          if (native) {
            if (message?.type === "BRIEFMARK_VIEW_CHANGED" && sender.tab?.id === targetTab) controller.applyState(message.state);
            if (message?.type === "BRIEFMARK_CAPTURE_ERROR" && sender.tab?.id === targetTab) controller.status(message.error, true);
            return;
          }
          if (sender.url && !sender.url.startsWith(api2.runtime.getURL(""))) return;
          if (message?.type === "BRIEFMARK_PRESENT") {
            controller.present(message.mode, !!message.canDock, message.state);
            respond(true);
          } else if (message?.type === "BRIEFMARK_START_CAPTURE") {
            void controller.startCapture();
            respond(true);
          } else if (message?.type === "BRIEFMARK_GET_VIEW") respond(controller.viewState());
          else if (message?.type === "BRIEFMARK_SET_VIEW") {
            controller.applyState(message.state);
            respond(true);
          } else if (message?.type === "BRIEFMARK_SIDEBAR_CLOSED") {
            controller.sidebarClosed();
            respond(true);
          } else if (message?.type === "BRIEFMARK_LOCATE" || message?.type === "BRIEFMARK_PARENT") {
            respond(controller.locate(message.note, message.type === "BRIEFMARK_PARENT"));
          }
        };
        api2.runtime.onMessage.addListener(messageListener);
        signal.addEventListener("abort", () => api2.runtime.onMessage.removeListener(messageListener), { once: true });
        if (!native) return;
        const port = api2.runtime.connect({ name: "briefmark-sidebar" });
        port.onMessage.addListener((result) => {
          if (signal.aborted || result.version !== connectionVersion) return;
          if (!result.ok) {
            controller.connectionFailed(result.error);
            return;
          }
          controller.applyState(result.value);
          controller.status();
        });
        async function connect() {
          const version = ++connectionVersion;
          try {
            const tabs = await api2.tabs.query({ active: true, windowId });
            if (signal.aborted || version !== connectionVersion) return;
            const tab = tabs[0];
            if (!tab?.id) throw new Error("No active tab");
            targetTab = tab.id;
            port.postMessage({ tabId: targetTab, version });
          } catch (error) {
            if (!signal.aborted && version === connectionVersion) controller.connectionFailed(error);
          }
        }
        const activated = (info) => {
          if (info.windowId === windowId) void connect();
        };
        const updated = (tabId, change) => {
          if (tabId === targetTab && change.status === "complete") void connect();
        };
        api2.tabs.onActivated.addListener(activated);
        api2.tabs.onUpdated.addListener(updated);
        signal.addEventListener("abort", () => {
          ++connectionVersion;
          api2.tabs.onActivated.removeListener(activated);
          api2.tabs.onUpdated.removeListener(updated);
          port.disconnect();
        }, { once: true });
        void api2.windows.getCurrent().then((window2) => {
          if (!signal.aborted) {
            windowId = window2.id;
            void connect();
          }
        }).catch((error) => {
          if (!signal.aborted) controller.connectionFailed(error);
        });
      }
    };
    return {
      store: extensionStore(),
      presentation,
      onDispose,
      privacyNotice: PRIVACY_NOTICE,
      settingsLabel: "Extension settings",
      storageError: "Could not save or load comments. Keep your draft and try again. If the extension was reloaded, refresh this page.",
      attachStyles(shadow) {
        const sheet = document.createElement("style");
        sheet.textContent = panel_default + privacy_default;
        shadow.prepend(sheet);
      },
      async capture() {
        const result = await api2.runtime.sendMessage({ type: "BRIEFMARK_CAPTURE_VISIBLE" });
        if (!result?.ok) throw new Error(result?.error || "Could not capture this page.");
        return result.value;
      }
    };
  }

  // src/extension-content.ts
  var global = globalThis;
  if (!global.__pagebrief) {
    global.__pagebrief = mount(extensionRuntime(() => {
      delete global.__pagebrief;
    }));
  }
})();
