import { parseArgs } from 'node:util';

// Safari is on hold. Keep its implementation for an explicit future reactivation.
export const safariEnabled = false;
export const safariDisabledReason = 'Safari builds and checks are disabled while Safari is on hold.';
export function assertSafariEnabled() {
  if (!safariEnabled) throw new Error(safariDisabledReason);
}

const targets = {
  chromium: { name: 'chromium', label: 'Chrome', outdir: 'dist', syntax: 'chrome142', format: 'esm', archiveSuffix: '' },
  firefox: { name: 'firefox', label: 'Firefox / Android', outdir: 'dist-firefox', syntax: 'firefox142', format: 'iife', archiveSuffix: '-firefox-unsigned' },
  // Safari 26.6.2 loaded the shared module worker in the native feasibility test.
  // This syntax target is a candidate build setting, not a supported-version claim.
  safari: { name: 'safari', label: 'Safari (development)', outdir: 'dist-safari', syntax: 'safari26.6', format: 'esm', archiveSuffix: '-safari-web' },
};

export function browserTarget(args = process.argv.slice(2)) {
  const { values } = parseArgs({ args, options: { target: { type: 'string' }, firefox: { type: 'boolean' } } });
  if (values.firefox && values.target) throw new Error('Use either --firefox or --target, not both.');
  const requested = values.target ?? (values.firefox ? 'firefox' : 'chromium');
  const name = requested === 'chrome' ? 'chromium' : requested;
  if (!Object.hasOwn(targets, name)) throw new Error(`Unsupported target: ${requested}. Choose chromium, firefox, or safari.`);
  return targets[name];
}

export function browserManifest(source, version, target) {
  const manifest = structuredClone(source);
  manifest.version = version;
  if (target.name !== 'chromium') {
    delete manifest.minimum_chrome_version;
    delete manifest.side_panel;
    manifest.permissions = manifest.permissions.filter(permission => permission !== 'sidePanel');
  }
  if (target.name === 'firefox') {
    // Android's Extensions menu activates the picker directly in one tap.
    delete manifest.action.default_popup;
    manifest.sidebar_action = { default_panel: 'sidebar.html', default_title: 'Briefmark', default_icon: 'icons/48.png', open_at_install: false };
    manifest.background = { scripts: ['background.js'] };
    manifest.browser_specific_settings = {
      gecko: { id: 'briefmark@briefmark.app', strict_min_version: '142.0', data_collection_permissions: { required: ['none'] } },
      gecko_android: { strict_min_version: '142.0' },
    };
  }
  return manifest;
}
