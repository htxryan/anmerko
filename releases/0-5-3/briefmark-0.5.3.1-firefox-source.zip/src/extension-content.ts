import { mount } from './content';
import { extensionRuntime } from './extension-runtime';
import type { Controller } from './runtime';

const global = globalThis as typeof globalThis & { __pagebrief?: Controller };
if (!global.__pagebrief) {
  global.__pagebrief = mount(extensionRuntime(() => { delete global.__pagebrief; }));
}
