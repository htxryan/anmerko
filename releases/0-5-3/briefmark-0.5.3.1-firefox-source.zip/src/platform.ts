// Firefox's browser namespace returns Promises. Chrome 120+ does too, through
// chrome. Resolve this lazily so the prompt formatter also runs outside a browser.
export function extensionApi(): typeof chrome {
  const api = (globalThis as typeof globalThis & { browser?: typeof chrome }).browser ?? globalThis.chrome;
  if (!api) throw new Error('Briefmark must run inside a browser extension.');
  return api;
}
