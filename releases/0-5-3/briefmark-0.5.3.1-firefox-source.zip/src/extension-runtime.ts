import { closeDock } from './docking';
import styles from './panel.css';
import type { Presentation, Runtime } from './runtime';

import { extensionApi } from './platform';
import type { Store } from './runtime';

export function extensionStore(): Store {
  const api = extensionApi();
  return {
    read: async key => (await api.storage.local.get(key))[key],
    readAll: () => api.storage.local.get(null),
    write: (key, value) => api.storage.local.set({ [key]: value }),
    remove: key => api.storage.local.remove(key),
    subscribe(listener) {
      const changed = (changes: Record<string, chrome.storage.StorageChange>, area: string) => {
        if (area === 'local') listener(changes);
      };
      api.storage.onChanged.addListener(changed);
      return () => api.storage.onChanged.removeListener(changed);
    },
  };
}


export function extensionRuntime(onDispose: () => void): Runtime {
  const api = extensionApi();
  const native = location.href === api.runtime.getURL('sidebar.html');
  let targetTab: number | undefined;
  let windowId: number | undefined;
  let connectionVersion = 0;
  async function pageCommand(type: string, extra: Record<string, unknown> = {}) {
    if (!targetTab) throw new Error('Click Briefmark in the toolbar to connect this page.');
    return api.tabs.sendMessage(targetTab, { type, ...extra });
  }
  const presentation: Presentation = {
    native,
    dockViaToolbar: 'sidebar_action' in api.runtime.getManifest(),
    async sync(state, remote) {
      if (native) {
        // Settings remain usable while disconnected, but an empty page identity
        // must never overwrite the page controller's current URL or draft.
        if (state.url) await pageCommand('BRIEFMARK_SET_VIEW', { state });
      } else if (remote) await api.runtime.sendMessage({ type: 'BRIEFMARK_VIEW_CHANGED', state }).catch(() => {});
    },
    async changeLayout(mode, state, mobile) {
      const request = api.runtime.sendMessage({ type: 'BRIEFMARK_LAYOUT', mode, state: state.url ? state : undefined, tabId: targetTab, windowId, mobile });
      // Firefox requires close() in the original click, before any await/message hop.
      if (native && mode !== 'dock') void closeDock(windowId || 0).catch(() => {});
      const result = await request;
      if (!result?.ok) throw new Error(result?.error || 'Could not change layout.');
    },
    locate: (note, parent) => pageCommand(parent ? 'BRIEFMARK_PARENT' : 'BRIEFMARK_LOCATE', { note }),
    hierarchy: note => pageCommand('BRIEFMARK_HIERARCHY', { note }),
    startCapture: () => pageCommand('BRIEFMARK_START_CAPTURE'),
    captureError: error => { void api.runtime.sendMessage({ type: 'BRIEFMARK_CAPTURE_ERROR', error }).catch(() => {}); },
    connect(controller, signal) {
      const messageListener = (message: any, sender: chrome.runtime.MessageSender, respond: (value?: unknown) => void) => {
        if (signal.aborted || sender.id !== api.runtime.id) return;
        if (native) {
          if (message?.type === 'BRIEFMARK_VIEW_CHANGED' && sender.tab?.id === targetTab) controller.applyState(message.state);
          if (message?.type === 'BRIEFMARK_CAPTURE_ERROR' && sender.tab?.id === targetTab) controller.status(message.error, true);
          return;
        }
        if (sender.url && !sender.url.startsWith(api.runtime.getURL(''))) return;
        if (message?.type === 'BRIEFMARK_PRESENT') { controller.present(message.mode, !!message.canDock, message.state, message.notifySidebar); respond(true); }
        else if (message?.type === 'BRIEFMARK_START_CAPTURE') { void controller.startCapture(); respond(true); }
        else if (message?.type === 'BRIEFMARK_GET_VIEW') respond(controller.viewState());
        else if (message?.type === 'BRIEFMARK_SET_VIEW') { controller.applyState(message.state); respond(true); }
        else if (message?.type === 'BRIEFMARK_SIDEBAR_CLOSED') { controller.sidebarClosed(); respond(true); }
        else if (message?.type === 'BRIEFMARK_HIERARCHY') respond(controller.hierarchy(message.note));
        else if (message?.type === 'BRIEFMARK_LOCATE' || message?.type === 'BRIEFMARK_PARENT') {
          respond(controller.locate(message.note, message.type === 'BRIEFMARK_PARENT'));
        }
      };
      api.runtime.onMessage.addListener(messageListener);
      signal.addEventListener('abort', () => api.runtime.onMessage.removeListener(messageListener), { once: true });
      if (!native) return;
      const port = api.runtime.connect({ name: 'briefmark-sidebar' });
      port.onMessage.addListener(result => {
        if (signal.aborted || result.version !== connectionVersion) return;
        if (!result.ok) { controller.connectionFailed(result.error); return; }
        controller.applyState(result.value);
      });
      async function connect() {
        const version = ++connectionVersion;
        try {
          const tabs = await api.tabs.query({ active: true, windowId });
          if (signal.aborted || version !== connectionVersion) return;
          const tab = tabs[0];
          if (!tab?.id) throw new Error('No active tab');
          targetTab = tab.id;
          // Startup and its response share the lifetime of this sidebar port.
          port.postMessage({ tabId: targetTab, version });
        } catch (error) {
          if (!signal.aborted && version === connectionVersion) controller.connectionFailed(error);
        }
      }
      const activated = (info: { tabId: number; windowId: number }) => { if (info.windowId === windowId) void connect(); };
      const updated = (tabId: number, change: { status?: string }) => { if (tabId === targetTab && change.status === 'complete') void connect(); };
      api.tabs.onActivated.addListener(activated);
      api.tabs.onUpdated.addListener(updated);
      signal.addEventListener('abort', () => {
        ++connectionVersion;
        api.tabs.onActivated.removeListener(activated);
        api.tabs.onUpdated.removeListener(updated);
        port.disconnect();
      }, { once: true });
      // Chrome can reuse the sidebar document after pagehide. Its mounted
      // controller stays connected until disposal or actual context destruction.
      void api.windows.getCurrent().then(window => {
        if (!signal.aborted) { windowId = window.id; void connect(); }
      }).catch(error => { if (!signal.aborted) controller.connectionFailed(error); });
    },
  };
  return {
    store: extensionStore(), presentation, onDispose,
    settingsLabel: 'Extension settings',
    storageError: 'Could not save or load comments. Keep your draft and try again. If the extension was reloaded, refresh this page.',
    attachStyles(shadow) {
      const sheet = document.createElement('style');
      sheet.textContent = styles;
      shadow.prepend(sheet);
    },
    async capture() {
      const result = await api.runtime.sendMessage({ type: 'BRIEFMARK_CAPTURE_VISIBLE' });
      if (!result?.ok) throw new Error(result?.error || 'Could not capture this page.');
      return result.value;
    },
  };
}
