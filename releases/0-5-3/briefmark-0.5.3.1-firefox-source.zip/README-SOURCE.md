# Briefmark 0.5.3.1 — Firefox self-distribution source

Requires Node.js 24 and npm. Run:

    npm ci
    npm run build:firefox

The resulting dist-firefox directory is the submitted extension. esbuild bundles TypeScript and embeds panel.css; it does not minify or obfuscate the code. All extension source and icons are included. No network requests, analytics, AI calls, or external runtime libraries are used by the extension.

This archive contains only files needed to rebuild the Firefox extension, not the brochure or test suite.

Derived only for unlisted Mozilla signing from the exact 0.5.3 source at ee99023240b3f7d47264b6fdc0d720ab43d7011c; the extension code is unchanged and only release version metadata differs.
