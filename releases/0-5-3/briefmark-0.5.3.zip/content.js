"use strict";
(() => {
  // src/support-icon.ts
  var supportIconAttributes = { "class": "support-icon", "width": "13", "height": "18", "aria-hidden": "true", "focusable": "false", "viewBox": "0 0 35 50", "fill": "currentColor" };
  var supportIconPaths = [
    "M30.7512 11.6307L30.7171 11.6106L30.6382 11.5865C30.6699 11.6134 30.7097 11.6289 30.7512 11.6307Z",
    "M31.2481 15.2031L31.21 15.2138L31.2481 15.2031Z",
    "M30.7659 11.6253C30.761 11.6247 30.7563 11.6236 30.7517 11.6219C30.7514 11.6251 30.7514 11.6283 30.7517 11.6314C30.7569 11.6307 30.7618 11.6286 30.7659 11.6253Z",
    "M30.7515 11.6314H30.7572V11.6278L30.7515 11.6314Z",
    "M31.2178 15.1962L31.2753 15.1634L31.2967 15.1514L31.3161 15.1307C31.2796 15.1464 31.2463 15.1686 31.2178 15.1962Z",
    "M30.8507 11.7088L30.7945 11.6553L30.7563 11.6345C30.7768 11.6707 30.8107 11.6973 30.8507 11.7088Z",
    "M16.715 46.3714C16.6701 46.3908 16.6307 46.4212 16.6006 46.4597L16.636 46.4369C16.6601 46.4149 16.6942 46.3888 16.715 46.3714Z",
    "M24.9235 44.7473C24.9235 44.6965 24.8987 44.7059 24.9048 44.8864C24.9048 44.8717 24.9108 44.857 24.9134 44.843C24.9168 44.8109 24.9195 44.7794 24.9235 44.7473Z",
    "M24.0719 46.3714C24.027 46.3908 23.9877 46.4212 23.9575 46.4597L23.993 46.4369C24.017 46.4149 24.0512 46.3888 24.0719 46.3714Z",
    "M10.9344 46.7574C10.9003 46.7277 10.8586 46.7082 10.814 46.7012C10.8501 46.7186 10.8862 46.736 10.9103 46.7493L10.9344 46.7574Z",
    "M9.63391 45.5042C9.62859 45.4515 9.61242 45.4005 9.58643 45.3544C9.60484 45.4024 9.62025 45.4516 9.63258 45.5015L9.63391 45.5042Z",
    "M18.3715 23.0976C16.5857 23.8665 14.5591 24.7382 11.9326 24.7382C10.8339 24.736 9.74049 24.5844 8.68213 24.2875L10.4987 43.0444C10.563 43.8284 10.9181 44.5594 11.4935 45.0923C12.0689 45.6251 12.8225 45.9208 13.6047 45.9207C13.6047 45.9207 16.1804 46.0552 17.0398 46.0552C17.9648 46.0552 20.7385 45.9207 20.7385 45.9207C21.5205 45.9207 22.274 45.6249 22.8493 45.092C23.4245 44.5592 23.7795 43.8283 23.8438 43.0444L25.7895 22.3173C24.92 22.0187 24.0425 21.8203 23.0533 21.8203C21.3424 21.8196 19.964 22.4122 18.3715 23.0976Z",
    "M3.05859 15.095L3.08936 15.1238L3.10943 15.1358C3.09397 15.1205 3.07693 15.1068 3.05859 15.095Z",
    "M34.1896 13.3639L33.916 11.9762C33.6706 10.7312 33.1134 9.55468 31.8426 9.10468C31.4353 8.96073 30.9732 8.89885 30.6608 8.60086C30.3485 8.30288 30.2562 7.84009 30.1839 7.41094C30.0502 6.62326 29.9244 5.83492 29.7873 5.04859C29.6689 4.37257 29.5753 3.61315 29.267 2.99296C28.8657 2.16022 28.033 1.67322 27.205 1.35102C26.7807 1.19173 26.3477 1.05698 25.9081 0.947426C23.8394 0.398542 21.6644 0.196746 19.5362 0.0817228C16.9817 -0.0600379 14.4204 -0.0173274 11.872 0.209526C9.97525 0.383071 7.97745 0.592939 6.17495 1.25281C5.51616 1.49429 4.8373 1.7842 4.33634 2.29609C3.72169 2.92502 3.52104 3.89768 3.96982 4.68199C4.28886 5.23895 4.82927 5.63245 5.40246 5.89276C6.14906 6.22818 6.92877 6.48341 7.72865 6.65421C9.95585 7.14928 12.2626 7.34368 14.538 7.42641C17.0599 7.52878 19.5859 7.44582 22.0958 7.1782C22.7165 7.10959 23.336 7.0273 23.9545 6.93134C24.6828 6.81901 25.1503 5.86115 24.9356 5.19388C24.6788 4.39611 23.9886 4.08669 23.208 4.2071C23.093 4.22526 22.9786 4.24208 22.8636 4.25889L22.7807 4.271C22.5163 4.30463 22.2518 4.33602 21.9874 4.36517C21.4412 4.42437 20.8937 4.4728 20.3448 4.51046C19.1155 4.59656 17.8828 4.63625 16.6508 4.63827C15.4403 4.63827 14.229 4.60396 13.0211 4.52392C12.47 4.48759 11.9202 4.4414 11.3718 4.38535C11.1223 4.35912 10.8735 4.33154 10.6247 4.3006L10.3879 4.27033L10.3364 4.26293L10.091 4.22728C9.58933 4.15127 9.08771 4.06382 8.59144 3.95822C8.54136 3.94704 8.49657 3.91902 8.46446 3.87879C8.43236 3.83855 8.41486 3.7885 8.41486 3.73691C8.41486 3.68533 8.43236 3.63528 8.46446 3.59504C8.49657 3.55481 8.54136 3.52679 8.59144 3.51561H8.6008C9.03086 3.42346 9.46426 3.34476 9.899 3.27615C10.0439 3.25328 10.1893 3.23086 10.3351 3.20888H10.3391C10.6113 3.19072 10.8849 3.14162 11.1557 3.10933C13.5125 2.86279 15.8832 2.77874 18.2513 2.85776C19.4011 2.89139 20.5501 2.95933 21.6945 3.07637C21.9406 3.10193 22.1854 3.12884 22.4302 3.15911C22.5238 3.17054 22.6181 3.18399 22.7124 3.19543L22.9024 3.22301C23.4562 3.30597 24.0071 3.40664 24.5551 3.52503C25.367 3.70261 26.4097 3.76046 26.7709 4.65508C26.8859 4.93894 26.9381 5.25442 27.0016 5.5524L27.0826 5.93245C27.0847 5.93927 27.0863 5.94624 27.0873 5.9533C27.2785 6.85017 27.4701 7.74704 27.6618 8.64391C27.6758 8.71017 27.6762 8.77862 27.6628 8.84501C27.6493 8.9114 27.6225 8.97429 27.5838 9.02977C27.5451 9.08525 27.4955 9.13212 27.4381 9.16746C27.3806 9.2028 27.3165 9.22585 27.2498 9.23517H27.2444L27.1274 9.25132L27.0117 9.26679C26.6452 9.31477 26.2782 9.35961 25.9108 9.40132C25.1871 9.48428 24.4623 9.55603 23.7364 9.61657C22.294 9.7372 20.8486 9.81635 19.4004 9.85401C18.6625 9.87374 17.9247 9.88294 17.1872 9.88159C14.2517 9.87926 11.3188 9.70768 8.40283 9.36769C8.08714 9.33002 7.77145 9.28966 7.45577 9.24863C7.70056 9.28024 7.27786 9.22441 7.19225 9.2123C6.9916 9.18405 6.79095 9.15468 6.5903 9.12419C5.91679 9.02262 5.24729 8.8975 4.57511 8.78786C3.76249 8.65333 2.98531 8.72059 2.25026 9.12419C1.6469 9.45624 1.15857 9.96544 0.850401 10.5838C0.533376 11.243 0.439071 11.9608 0.297279 12.6691C0.155487 13.3774 -0.0652275 14.1395 0.0183763 14.8666C0.198292 16.4359 1.28915 17.7113 2.85823 17.9965C4.33434 18.2655 5.81847 18.4835 7.30662 18.6691C13.1524 19.3892 19.0582 19.4753 24.9223 18.9261C25.3998 18.8812 25.8767 18.8324 26.3529 18.7794C26.5016 18.763 26.6521 18.7802 26.7934 18.8299C26.9347 18.8795 27.0631 18.9603 27.1693 19.0663C27.2755 19.1724 27.3567 19.3009 27.4071 19.4426C27.4575 19.5843 27.4757 19.7356 27.4605 19.8853L27.312 21.3369C27.0128 24.2701 26.7136 27.2031 26.4144 30.1358C26.1023 33.2157 25.7882 36.2953 25.472 39.3747C25.3829 40.242 25.2937 41.109 25.2045 41.9758C25.1189 42.8294 25.1069 43.7099 24.9457 44.5534C24.6915 45.8799 23.7986 46.6945 22.4957 46.9925C21.3021 47.2657 20.0827 47.4091 18.8586 47.4203C17.5016 47.4277 16.1452 47.3672 14.7881 47.3746C13.3395 47.3826 11.5651 47.2481 10.4468 46.1638C9.46426 45.2113 9.32849 43.72 9.19472 42.4306C9.01637 40.7234 8.83957 39.0164 8.66434 37.3097L7.68116 27.8192L7.0451 21.6786C7.0344 21.577 7.0237 21.4768 7.01367 21.3745C6.93742 20.642 6.42176 19.925 5.60913 19.962C4.91354 19.9929 4.12299 20.5875 4.20458 21.3745L4.67611 25.927L5.65126 35.3442C5.92905 38.0191 6.20617 40.6944 6.48262 43.3703C6.53613 43.8828 6.58628 44.3967 6.64247 44.9093C6.94812 47.7102 9.075 49.2196 11.7089 49.6448C13.2472 49.8936 14.8229 49.9448 16.384 49.9703C18.3851 50.0026 20.4063 50.08 22.3747 49.7154C25.2915 49.1773 27.4799 47.2185 27.7922 44.1801C27.8814 43.303 27.9706 42.4256 28.0597 41.548C28.3563 38.6458 28.6523 35.7433 28.9479 32.8406L29.9151 23.3562L30.3585 19.0095C30.3806 18.794 30.4711 18.5913 30.6166 18.4315C30.7621 18.2717 30.9549 18.1633 31.1665 18.1223C32.0005 17.9588 32.7977 17.6796 33.391 17.0413C34.3354 16.0249 34.5233 14.6998 34.1896 13.3639ZM2.81542 14.3016C2.82813 14.2955 2.80472 14.4052 2.79469 14.4563C2.79268 14.3789 2.7967 14.3103 2.81542 14.3016ZM2.89635 14.9312C2.90304 14.9265 2.9231 14.9534 2.94384 14.9857C2.9124 14.9561 2.89234 14.9339 2.89568 14.9312H2.89635ZM2.97594 15.0368C3.0047 15.0859 3.02009 15.1168 2.97594 15.0368V15.0368ZM3.13579 15.1673H3.1398C3.1398 15.172 3.14716 15.1767 3.14984 15.1814C3.1454 15.1762 3.14048 15.1715 3.13513 15.1673H3.13579ZM31.1277 14.9722C30.828 15.2588 30.3766 15.392 29.9305 15.4586C24.9276 16.2052 19.8519 16.5832 14.7942 16.4164C11.1745 16.292 7.59287 15.8877 4.00928 15.3785C3.65815 15.3287 3.27758 15.2642 3.03614 15.0038C2.58133 14.5128 2.80472 13.524 2.9231 12.9307C3.03145 12.3872 3.23879 11.6628 3.88154 11.5854C4.88478 11.467 6.04989 11.8928 7.04243 12.0442C8.2374 12.2276 9.43684 12.3744 10.6407 12.4848C15.7787 12.9556 21.0029 12.8823 26.1181 12.1935C27.0505 12.0675 27.9795 11.9211 28.9051 11.7543C29.7298 11.6056 30.6441 11.3264 31.1424 12.1854C31.4841 12.7706 31.5296 13.5536 31.4768 14.2148C31.4605 14.5029 31.3354 14.7739 31.127 14.9722H31.1277Z"
  ];
  function createSupportIcon() {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    for (const [name, value] of Object.entries(supportIconAttributes)) svg.setAttribute(name, value);
    for (const d of supportIconPaths) {
      const path = document.createElementNS(svg.namespaceURI, "path");
      path.setAttribute("d", d);
      svg.append(path);
    }
    return svg;
  }

  // src/icons.ts
  var shapes = {
    select: [{ tag: "circle", attributes: { cx: "12", cy: "12", r: "7" } }, { tag: "path", attributes: { d: "M12 2v5m0 10v5M2 12h5m10 0h5" } }],
    camera: [{ tag: "path", attributes: { d: "M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3z" } }, { tag: "circle", attributes: { cx: "12", cy: "13", r: "4" } }],
    pin: [{ tag: "path", attributes: { d: "M9 3h6l-1 7 4 4v2H6v-2l4-4-1-7Zm3 13v6" } }],
    unpin: [{ tag: "path", attributes: { d: "m2 2 20 20M9 3h6l-1 7 4 4v2M10 10l-4 4v2h10m-4 0v6" } }],
    settings: [{ tag: "path", attributes: { d: "m9 3-1 3-3 1-2 3 2 2-1 3 2 3h3l2 3h3l1-3 3-1 2-3-2-2 1-3-2-3h-3l-2-3H9Z" } }, { tag: "circle", attributes: { cx: "12", cy: "12", r: "3" } }],
    minus: [{ tag: "path", attributes: { d: "M5 12h14" } }],
    close: [{ tag: "path", attributes: { d: "m6 6 12 12M6 18 18 6" } }],
    back: [{ tag: "path", attributes: { d: "m10 5-7 7 7 7M3 12h18" } }],
    sun: [{ tag: "circle", attributes: { cx: "12", cy: "12", r: "4" } }, { tag: "path", attributes: { d: "M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5" } }],
    moon: [{ tag: "path", attributes: { d: "M21 13a9 9 0 0 1-10-10 9 9 0 1 0 10 10Z" } }],
    save: [{ tag: "path", attributes: { d: "M5 3h12l4 4v14H3V3h2Zm2 0v6h10V3M7 21v-8h10v8" } }],
    restore: [{ tag: "path", attributes: { d: "M3 4v6h6M3 10a9 9 0 1 1 1 8" } }],
    copy: [{ tag: "rect", attributes: { x: "8", y: "8", width: "13", height: "13", rx: "2" } }, { tag: "path", attributes: { d: "M16 8V3H3v13h5" } }],
    download: [{ tag: "path", attributes: { d: "M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5" } }],
    comment: [{ tag: "path", attributes: { d: "M21 14a3 3 0 0 1-3 3H8l-5 4V6a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3v8Z" } }],
    "comment-add": [{ tag: "path", attributes: { d: "M21 14a3 3 0 0 1-3 3H8l-5 4V6a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3v8ZM12 6v8m-4-4h8" } }],
    edit: [{ tag: "path", attributes: { d: "m15 5 4 4M4 16 16 4a2.8 2.8 0 0 1 4 4L8 20l-5 1 1-5Z" } }],
    trash: [{ tag: "path", attributes: { d: "M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7" } }],
    parent: [{ tag: "path", attributes: { d: "m6 9 6-6 6 6M12 3v14a4 4 0 0 0 4 4h4" } }],
    check: [{ tag: "path", attributes: { d: "m4 12 5 5L20 6" } }],
    connect: [{ tag: "path", attributes: { d: "M7 17 17 7M7 7h10v10" } }],
    maximize: [{ tag: "path", attributes: { d: "M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5" } }],
    field: [{ tag: "rect", attributes: { x: "3", y: "5", width: "18", height: "14", rx: "2" } }, { tag: "path", attributes: { d: "M7 9v6m9 0h2m-5 0h1" } }],
    expand: [{ tag: "path", attributes: { d: "M14 4h6v6M20 4l-7 7M10 20H4v-6M4 20l7-7" } }],
    collapse: [{ tag: "path", attributes: { d: "M20 4l-7 7m0-6v6h6M4 20l7-7m-6 0h6v6" } }],
    chevron: [{ tag: "path", attributes: { d: "m6 9 6 6 6-6" } }]
  };
  function icon(name) {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    for (const [attribute, value] of Object.entries({ class: "button-icon", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "1.75", "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true", focusable: "false" })) svg.setAttribute(attribute, value);
    const iconShapes = shapes[name];
    for (const shape of iconShapes) {
      const child = document.createElementNS(svg.namespaceURI, shape.tag);
      for (const [attribute, value] of Object.entries(shape.attributes)) child.setAttribute(attribute, value);
      svg.append(child);
    }
    return svg;
  }
  function renderIcons(root) {
    for (const placeholder of root.querySelectorAll("[data-icon]")) {
      const name = placeholder.dataset.icon;
      if (name && Object.hasOwn(shapes, name)) placeholder.replaceChildren(icon(name));
    }
  }

  // src/comment-card.ts
  var elementTypes = {
    textarea: "Text Area",
    input: "Input",
    select: "Select",
    button: "Button",
    a: "Link",
    img: "Image",
    p: "Paragraph",
    div: "Container",
    span: "Text",
    form: "Form",
    em: "Emphasis",
    strong: "Strong Text",
    h1: "Heading",
    h2: "Heading",
    h3: "Heading",
    h4: "Heading",
    h5: "Heading",
    h6: "Heading"
  };
  function createCommentCard(note, number, editing = false) {
    const card = document.createElement(editing ? "form" : "article");
    card.className = editing ? "editor" : "note";
    card.innerHTML = `<div class="note-top"><span class="number"></span><strong class="note-title"></strong><div class="note-actions" role="group" aria-label="Comment actions"><button class="text-button locate" type="button" aria-label="Locate"><span data-icon="select"></span></button></div></div>
    <div class="note-metadata"><div class="note-kind"><span data-icon="field"></span><span class="tag"></span></div><div class="hierarchy"><code class="selector"></code><button class="text-button hierarchy-toggle" type="button" aria-label="Show Full Element Hierarchy" aria-expanded="false" hidden></button></div><div class="page-label" hidden></div></div>
    <div class="comment-body"><textarea class="comment" rows="3"></textarea></div>`;
    if (note.screenshot) card.querySelector(".note-kind [data-icon]").setAttribute("data-icon", "camera");
    if (note.kind === "page") {
      card.querySelector(".note-kind [data-icon]").setAttribute("data-icon", "comment");
      card.querySelector(".locate").hidden = true;
    }
    if (editing) {
      card.querySelector(".note-actions").insertAdjacentHTML("beforeend", '<span class="editing-badge"><span data-icon="edit"></span>Editing</span>');
      card.querySelector(".note-kind").insertAdjacentHTML("beforeend", '<button class="text-button parent" type="button" aria-label="Use Parent Element" title="Use Parent Element"><span data-icon="parent"></span></button>');
      card.querySelector(".comment-body").insertAdjacentHTML("beforeend", '<div class="editor-actions"><span class="shortcut">\u2318 / Ctrl + Enter to save</span><button class="secondary cancel" type="button"><span data-icon="close"></span>Cancel</button><button class="primary save" type="submit"><span data-icon="save"></span>Save</button></div>');
    } else {
      card.querySelector(".note-actions").insertAdjacentHTML("beforeend", '<button class="text-button edit" type="button" aria-label="Edit"><span data-icon="edit"></span></button><button class="text-button delete" type="button" aria-label="Delete"><span data-icon="trash"></span></button>');
    }
    renderIcons(card);
    card.querySelector(".number").textContent = String(number);
    card.querySelector(".number").setAttribute("aria-label", `Comment Number ${number}`);
    const type = note.element ? elementTypes[note.element.tag] || note.element.tag.charAt(0).toUpperCase() + note.element.tag.slice(1) : note.screenshot ? "Screenshot" : "Page";
    const title = note.element ? note.element.label || note.element.text || `Unnamed ${type}` : note.screenshot ? "Screenshot" : "Global Comment";
    const heading = card.querySelector(".note-title");
    heading.textContent = title;
    heading.title = title;
    card.querySelector(".tag").textContent = note.screenshot ? `${note.screenshot.width} \xD7 ${note.screenshot.height} px` : type;
    const field = card.querySelector("textarea");
    field.textContent = note.comment;
    field.readOnly = !editing;
    if (editing) {
      field.id = "comment";
      field.placeholder = "Add a comment";
      field.maxLength = 1e4;
      field.required = true;
    }
    field.setAttribute("aria-label", editing ? "Comment" : `Comment ${number}`);
    const hierarchy = card.querySelector(".hierarchy");
    hierarchy.hidden = !note.element;
    const path = card.querySelector(".selector");
    const toggle = card.querySelector(".hierarchy-toggle");
    path.id = `hierarchy-${crypto.randomUUID()}`;
    toggle.setAttribute("aria-controls", path.id);
    if (note.element) field.setAttribute("aria-describedby", path.id);
    let parts = note.element?.hierarchy?.length ? note.element.hierarchy : note.element?.selectorPath || [];
    let expanded = false;
    function render() {
      if (!card.isConnected || !hierarchy.clientWidth) return;
      hierarchy.classList.toggle("expanded", expanded);
      path.textContent = parts.join(" > ");
      path.title = path.textContent;
      toggle.setAttribute("aria-expanded", String(expanded));
      toggle.setAttribute("aria-label", expanded ? "Collapse Element Hierarchy" : "Show Full Element Hierarchy");
      toggle.replaceChildren(icon(expanded ? "collapse" : "expand"));
      toggle.hidden = !expanded;
      if (expanded || path.scrollWidth <= path.clientWidth + 1) return;
      toggle.hidden = false;
      const tail = parts.slice(-Math.min(3, parts.length));
      do {
        path.textContent = (tail.length < parts.length ? "... " : "") + tail.join(" > ");
        if (path.scrollWidth <= path.clientWidth + 1 || tail.length === 1) break;
        tail.shift();
      } while (tail.length);
    }
    toggle.addEventListener("click", () => {
      expanded = !expanded;
      render();
    });
    const observer = new ResizeObserver(render);
    observer.observe(hierarchy);
    return {
      card,
      setHierarchy(value) {
        parts = value;
        render();
      },
      dispose: () => observer.disconnect()
    };
  }

  // src/screenshot.ts
  var clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  function privateImage(dataUrl, alt) {
    const host = document.createElement("briefmark-image");
    const root = host.attachShadow({ mode: "closed" });
    const image = document.createElement("img");
    image.src = dataUrl;
    image.alt = alt;
    image.style.cssText = "display:block;width:100%;height:100%;object-fit:contain;pointer-events:none;";
    root.append(image);
    return host;
  }
  async function selectScreenshot(app, mobile, capture, signal) {
    const viewport = window.visualViewport;
    const width = viewport?.width ?? innerWidth;
    const height = viewport?.height ?? innerHeight;
    const left = viewport?.offsetLeft ?? 0;
    const top = viewport?.offsetTop ?? 0;
    const zoom = viewport?.scale ?? 1;
    const root = document.compatMode === "BackCompat" ? document.body : document.documentElement;
    const captureWidth = width + Math.max(0, innerWidth - root.clientWidth) / zoom;
    const captureHeight = height + Math.max(0, innerHeight - root.clientHeight) / zoom;
    const scroll = { x: window.scrollX + left, y: window.scrollY + top };
    const startUrl = location.href;
    const valid = () => !signal.aborted && !document.hidden && location.href === startUrl && Math.abs((viewport?.width ?? innerWidth) - width) < 1 && Math.abs((viewport?.height ?? innerHeight) - height) < 1 && Math.abs(window.scrollX + (viewport?.offsetLeft ?? 0) - scroll.x) < 1 && Math.abs(window.scrollY + (viewport?.offsetTop ?? 0) - scroll.y) < 1;
    let dataUrl;
    app.classList.add("capture-hidden");
    try {
      await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
      if (!valid()) throw new Error("The page moved. Try capturing again.");
      dataUrl = await capture();
    } finally {
      app.classList.remove("capture-hidden");
    }
    if (!valid()) throw new Error("The page moved during capture. Try again.");
    const image = new Image();
    image.src = dataUrl;
    await image.decode();
    if (!valid()) throw new Error("The page moved during capture. Try again.");
    const layer = document.createElement("div");
    layer.className = "capture-layer";
    layer.setAttribute("role", "dialog");
    layer.setAttribute("aria-label", "Select screenshot region");
    Object.assign(layer.style, { left: `${left}px`, top: `${top}px`, width: `${width}px`, height: `${height}px` });
    const photo = privateImage(dataUrl, "Captured page");
    photo.className = "capture-photo";
    Object.assign(photo.style, { width: `${captureWidth}px`, height: `${captureHeight}px` });
    dataUrl = "";
    layer.append(photo);
    layer.insertAdjacentHTML("beforeend", `<div class="capture-shade"></div><div class="capture-region" tabindex="0" aria-label="Move screenshot region"><button class="capture-handle nw" data-corner="nw" aria-label="Resize top left"></button><button class="capture-handle ne" data-corner="ne" aria-label="Resize top right"></button><button class="capture-handle sw" data-corner="sw" aria-label="Resize bottom left"></button><button class="capture-handle se" data-corner="se" aria-label="Resize bottom right"></button></div><div class="capture-toolbar"><p></p><div><button class="secondary capture-cancel"><span data-icon="close"></span>Cancel</button><button class="primary capture-use" disabled><span data-icon="check"></span>Use Screenshot</button></div></div>`);
    renderIcons(layer);
    const region = layer.querySelector(".capture-region");
    const use = layer.querySelector(".capture-use");
    const toolbar = layer.querySelector(".capture-toolbar");
    toolbar.querySelector("p").textContent = mobile ? "Drag the box or its corners." : "Drag to select an area.";
    app.classList.add("capturing");
    app.append(layer);
    const min = 12;
    let rect = mobile ? { x: Math.round(width * 0.15), y: Math.round(height * 0.2), width: Math.round(width * 0.7), height: Math.round(height * 0.45) } : null;
    function render() {
      region.hidden = !rect;
      layer.querySelector(".capture-shade").hidden = !!rect;
      use.disabled = !rect || rect.width < min || rect.height < min;
      if (rect) Object.assign(region.style, { left: `${rect.x}px`, top: `${rect.y}px`, width: `${rect.width}px`, height: `${rect.height}px` });
    }
    render();
    return new Promise((resolve, reject) => {
      const listeners = new AbortController();
      let finished = false;
      function finish(result, error) {
        if (finished) return;
        finished = true;
        listeners.abort();
        signal.removeEventListener("abort", aborted);
        layer.remove();
        app.classList.remove("capturing");
        image.src = "";
        if (error) reject(error);
        else resolve(result);
      }
      const aborted = () => finish(null);
      signal.addEventListener("abort", aborted, { once: true });
      const changed = () => {
        if (!valid()) finish(null, new Error("The page changed. Capture the region again."));
      };
      for (const target of [window, viewport].filter(Boolean)) {
        for (const name of ["resize", "scroll"]) target.addEventListener(name, changed, { signal: listeners.signal });
      }
      document.addEventListener("visibilitychange", changed, { signal: listeners.signal });
      layer.addEventListener("wheel", (event) => event.preventDefault(), { passive: false, signal: listeners.signal });
      let drag = null;
      const pointers = /* @__PURE__ */ new Set();
      layer.addEventListener("pointerdown", (event) => {
        if (!event.isTrusted || toolbar.contains(event.target)) return;
        event.preventDefault();
        event.stopPropagation();
        pointers.add(event.pointerId);
        if (pointers.size > 1) {
          if (drag) rect = drag.before;
          drag = null;
          render();
          return;
        }
        const x = clamp(event.clientX - left, 0, width), y = clamp(event.clientY - top, 0, height);
        const target = event.target;
        const corner = target.dataset.corner || (target === region ? "move" : "new");
        const before = rect && { ...rect };
        if (!rect || corner === "new") rect = { x, y, width: 0, height: 0 };
        drag = { id: event.pointerId, x, y, corner, original: { ...rect }, before };
        layer.setPointerCapture(event.pointerId);
        render();
      }, { signal: listeners.signal });
      layer.addEventListener("pointermove", (event) => {
        if (!event.isTrusted || !drag || drag.id !== event.pointerId) return;
        event.preventDefault();
        const x = clamp(event.clientX - left, 0, width), y = clamp(event.clientY - top, 0, height);
        const original = drag.original;
        if (drag.corner === "move") rect = { ...original, x: clamp(original.x + x - drag.x, 0, width - original.width), y: clamp(original.y + y - drag.y, 0, height - original.height) };
        else {
          const anchorX = drag.corner === "new" ? drag.x : original.x + (drag.corner.includes("w") ? original.width : 0);
          const anchorY = drag.corner === "new" ? drag.y : original.y + (drag.corner.includes("n") ? original.height : 0);
          rect = { x: Math.min(x, anchorX), y: Math.min(y, anchorY), width: Math.abs(x - anchorX), height: Math.abs(y - anchorY) };
        }
        render();
      }, { signal: listeners.signal });
      for (const name of ["pointerup", "pointercancel"]) layer.addEventListener(name, (event) => {
        pointers.delete(event.pointerId);
        if (drag?.id === event.pointerId) {
          if (name === "pointercancel") rect = drag.before;
          drag = null;
          render();
        }
      }, { signal: listeners.signal });
      document.addEventListener("keydown", (event) => {
        if (!event.isTrusted) return;
        if (event.key === "Escape") {
          event.preventDefault();
          event.stopImmediatePropagation();
          finish(null);
        } else if (rect && ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) {
          event.preventDefault();
          const step = event.shiftKey ? 10 : 1;
          const active = layer.getRootNode().activeElement;
          const corner = active?.dataset.corner;
          const dx = event.key === "ArrowLeft" ? -step : event.key === "ArrowRight" ? step : 0;
          const dy = event.key === "ArrowUp" ? -step : event.key === "ArrowDown" ? step : 0;
          if (corner) {
            const x1 = corner.includes("w") ? clamp(rect.x + dx, 0, rect.x + rect.width - min) : rect.x;
            const y1 = corner.includes("n") ? clamp(rect.y + dy, 0, rect.y + rect.height - min) : rect.y;
            const x2 = corner.includes("e") ? clamp(rect.x + rect.width + dx, rect.x + min, width) : rect.x + rect.width;
            const y2 = corner.includes("s") ? clamp(rect.y + rect.height + dy, rect.y + min, height) : rect.y + rect.height;
            rect = { x: x1, y: y1, width: x2 - x1, height: y2 - y1 };
          } else rect = { ...rect, x: clamp(rect.x + dx, 0, width - rect.width), y: clamp(rect.y + dy, 0, height - rect.height) };
          render();
        } else if (event.key === "Tab") {
          const controls = [...layer.querySelectorAll('button:not(:disabled), [tabindex="0"]')].filter((el) => el.getClientRects().length);
          const current = layer.getRootNode().activeElement;
          const index = controls.indexOf(current);
          event.preventDefault();
          controls[(index + (event.shiftKey ? controls.length - 1 : 1)) % controls.length]?.focus();
        }
      }, { capture: true, signal: listeners.signal });
      function activate(button, action) {
        let tap = null;
        button.addEventListener("pointerdown", (event) => {
          if (!event.isTrusted || event.pointerType !== "touch") return;
          tap = event.isPrimary ? { id: event.pointerId, x: event.clientX, y: event.clientY, time: performance.now() } : null;
        }, { signal: listeners.signal });
        button.addEventListener("pointercancel", () => {
          tap = null;
        }, { signal: listeners.signal });
        button.addEventListener("pointermove", (event) => {
          if (tap && Math.hypot(event.clientX - tap.x, event.clientY - tap.y) > 12) tap = null;
        }, { signal: listeners.signal });
        button.addEventListener("pointerup", (event) => {
          const candidate = tap;
          tap = null;
          const bounds = button.getBoundingClientRect();
          if (!event.isTrusted || button.disabled || candidate?.id !== event.pointerId || performance.now() - candidate.time > 700 || event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) return;
          event.preventDefault();
          event.stopPropagation();
          const cleanup = () => {
            document.removeEventListener("click", suppress, true);
            document.removeEventListener("pointerdown", cleanup, true);
            clearTimeout(timer);
          };
          const suppress = (click) => {
            if (!click.isTrusted || click.detail === 0) return;
            click.preventDefault();
            click.stopImmediatePropagation();
            cleanup();
          };
          const timer = setTimeout(cleanup, 800);
          document.addEventListener("click", suppress, true);
          document.addEventListener("pointerdown", cleanup, true);
          action();
        }, { signal: listeners.signal });
        button.addEventListener("click", (event) => {
          if (event.isTrusted && !button.disabled) action();
        }, { signal: listeners.signal });
      }
      activate(layer.querySelector(".capture-cancel"), () => finish(null));
      activate(use, () => {
        if (!rect || use.disabled || drag) return;
        if (!valid()) {
          changed();
          return;
        }
        try {
          const x = Math.round(rect.x * image.naturalWidth / captureWidth), y = Math.round(rect.y * image.naturalHeight / captureHeight);
          const right = Math.round((rect.x + rect.width) * image.naturalWidth / captureWidth);
          const bottom = Math.round((rect.y + rect.height) * image.naturalHeight / captureHeight);
          const scale = Math.min(1, 2400 / Math.max(right - x, bottom - y));
          const canvas = document.createElement("canvas");
          canvas.width = Math.max(1, Math.round((right - x) * scale));
          canvas.height = Math.max(1, Math.round((bottom - y) * scale));
          canvas.getContext("2d").drawImage(image, x, y, right - x, bottom - y, 0, 0, canvas.width, canvas.height);
          const cropped = canvas.toDataURL("image/png");
          if (cropped.length > 28e5) {
            toolbar.querySelector("p").textContent = "Image is too large. Select a smaller area.";
            return;
          }
          finish({
            dataUrl: cropped,
            width: canvas.width,
            height: canvas.height,
            region: { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height) },
            viewport: { width: Math.round(width), height: Math.round(height) },
            scroll
          });
        } catch {
          finish(null, new Error("Could not crop this screenshot. Try again."));
        }
      });
      (rect ? region : layer.querySelector(".capture-cancel")).focus();
    });
  }

  // src/core.ts
  var STORAGE_PREFIX = "pagebrief:note:v1:";
  var shorten = (text, max = 240) => text.replace(/\s+/g, " ").trim().slice(0, max);
  function pageUrl(url = location.href) {
    const parsed = new URL(url);
    parsed.username = "";
    parsed.password = "";
    return parsed.href;
  }
  function pageIdentity(url) {
    try {
      const parsed = new URL(pageUrl(url));
      if (["google.com", "www.google.com"].includes(parsed.hostname) && parsed.pathname === "/") {
        parsed.searchParams.delete("zx");
      }
      return parsed.href;
    } catch {
      return url;
    }
  }
  function samePage(first, second) {
    return pageIdentity(first) === pageIdentity(second);
  }
  function selectorWithinRoot(element) {
    const root = element.getRootNode();
    const unique = (selector) => root.querySelectorAll(selector).length === 1;
    const segments = [];
    let node = element;
    while (node) {
      if (node.id && unique(`#${CSS.escape(node.id)}`)) {
        segments.unshift(`#${CSS.escape(node.id)}`);
        break;
      }
      const testId = node.getAttribute("data-testid");
      if (testId) {
        const selector = `[data-testid="${CSS.escape(testId)}"]`;
        if (unique(selector)) {
          segments.unshift(selector);
          break;
        }
      }
      const tag = CSS.escape(node.localName);
      const parent = node.parentNode;
      const siblings = parent ? Array.from(parent.children).filter((s) => s.localName === node.localName) : [];
      segments.unshift(siblings.length > 1 ? `${tag}:nth-of-type(${siblings.indexOf(node) + 1})` : tag);
      node = node.parentElement;
    }
    return segments.join(" > ");
  }
  function selectorPath(element) {
    const path = [selectorWithinRoot(element)];
    let root = element.getRootNode();
    while (root instanceof ShadowRoot) {
      path.unshift(selectorWithinRoot(root.host));
      root = root.host.getRootNode();
    }
    return path;
  }
  var PRIVATE_FIELDS = 'input, textarea, select, [contenteditable]:not([contenteditable="false"]), script, style, noscript, [hidden], [aria-hidden="true"]';
  function elementText(element) {
    if (element.closest(PRIVATE_FIELDS)) return "";
    const clone = element.cloneNode(true);
    clone.querySelectorAll(PRIVATE_FIELDS).forEach((node) => node.remove());
    clone.querySelectorAll("br").forEach((node) => node.replaceWith(" "));
    return shorten(clone.textContent || "");
  }
  function captureElement(element) {
    return {
      selectorPath: selectorPath(element),
      hierarchy: elementHierarchy(element),
      tag: element.localName,
      text: elementText(element),
      label: shorten(element.getAttribute("aria-label") || element.getAttribute("alt") || "", 120),
      viewport: { width: innerWidth, height: innerHeight }
    };
  }
  function elementHierarchy(element) {
    const path = [];
    let node = element;
    while (node) {
      const parent = node.parentNode;
      const siblings = parent ? Array.from(parent.children).filter((sibling) => sibling.localName === node.localName) : [];
      path.unshift(siblings.length > 1 ? `${node.localName}:nth-of-type(${siblings.indexOf(node) + 1})` : node.localName);
      const root = node.getRootNode();
      node = node.parentElement;
      if (!node && root instanceof ShadowRoot) {
        path.unshift("#shadow-root");
        node = root.host;
      }
    }
    return path;
  }
  function resolveElement(context) {
    let root = document;
    let element = null;
    try {
      for (let i = 0; i < context.selectorPath.length; i++) {
        element = root.querySelector(context.selectorPath[i]);
        if (!element) return null;
        if (i < context.selectorPath.length - 1) {
          if (!element.shadowRoot) return null;
          root = element.shadowRoot;
        }
      }
    } catch {
      return null;
    }
    if (element?.localName !== context.tag || context.text && elementText(element) !== context.text) return null;
    return element;
  }
  function isNote(value) {
    if (!value || typeof value !== "object") return false;
    const note = value;
    const validBase = typeof note.id === "string" && typeof note.pageUrl === "string" && typeof note.pageTitle === "string" && typeof note.comment === "string" && typeof note.createdAt === "string" && typeof note.updatedAt === "string";
    if (!validBase) return false;
    if (note.kind !== void 0) return note.kind === "page" && !("element" in note) && !("screenshot" in note);
    return note.screenshot ? isScreenshot(note.screenshot) : !!note.element && typeof note.element.tag === "string" && typeof note.element.text === "string" && typeof note.element.label === "string" && Array.isArray(note.element.selectorPath) && note.element.selectorPath.length > 0 && note.element.selectorPath.every((s) => typeof s === "string") && (note.element.hierarchy === void 0 || Array.isArray(note.element.hierarchy) && note.element.hierarchy.every((segment) => typeof segment === "string")) && Number.isFinite(note.element.viewport?.width) && Number.isFinite(note.element.viewport?.height);
  }
  function isScreenshot(image) {
    return typeof image.dataUrl === "string" && /^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(image.dataUrl) && image.dataUrl.length <= 28e5 && [image.width, image.height, image.region?.width, image.region?.height, image.viewport?.width, image.viewport?.height].every((n) => Number.isFinite(n) && n > 0) && [image.region?.x, image.region?.y, image.scroll?.x, image.scroll?.y].every(Number.isFinite);
  }
  function screenshotFilename(note) {
    const id = /^[a-zA-Z0-9_-]{1,80}$/.test(note.id) ? note.id : Array.from(new TextEncoder().encode(note.id), (byte) => byte.toString(16).padStart(2, "0")).join("");
    return `screenshot-${id}.png`;
  }
  async function readNotes(store) {
    const records = await store.readAll();
    return Object.entries(records).filter(([key, value]) => key.startsWith(STORAGE_PREFIX) && isNote(value)).map(([, value]) => value).sort((a, b) => a.createdAt.localeCompare(b.createdAt) || a.id.localeCompare(b.id));
  }
  async function saveNote(store, note) {
    await store.write(STORAGE_PREFIX + note.id, note);
  }
  async function removeNote(store, id) {
    await store.remove(STORAGE_PREFIX + id);
  }
  var DEFAULT_PROMPT_PREAMBLE = "Comments collected with Briefmark. Page URLs and captured context are listed with each comment.";
  function buildPrompt(notes, preamble = DEFAULT_PROMPT_PREAMBLE) {
    const pages = /* @__PURE__ */ new Map();
    notes.forEach((note) => {
      const key = pageIdentity(note.pageUrl);
      pages.set(key, [...pages.get(key) || [], note]);
    });
    const lines = [
      "# Website feedback",
      "",
      ...preamble.trim() ? [preamble, ""] : [],
      `${notes.length} comment${notes.length === 1 ? "" : "s"} across ${pages.size} page${pages.size === 1 ? "" : "s"}.`,
      ""
    ];
    let index = 0;
    let pageIndex = 0;
    for (const pageNotes of pages.values()) {
      lines.push(
        `## Page ${++pageIndex}`,
        "",
        `- **Title:** ${inlineCode(pageNotes[0].pageTitle)}`,
        `- **URL:** ${inlineCode(pageNotes[0].pageUrl)}`,
        ""
      );
      for (const note of pageNotes) {
        lines.push(`### Comment ${++index}`, "", quote(note.comment), "");
        if (note.kind === "page") {
          lines.push("- **Scope:** Entire page (global comment)", "");
          continue;
        }
        if (note.screenshot) {
          const { region, viewport, scroll, width, height } = note.screenshot;
          lines.push(
            `- **Screenshot file:** ${inlineCode(screenshotFilename(note))}`,
            `- **Image size:** ${width} \xD7 ${height} pixels`,
            `- **Region:** x ${region.x}, y ${region.y}, width ${region.width}, height ${region.height} (CSS pixels within the visible viewport)`,
            `- **Viewport:** ${viewport.width} \xD7 ${viewport.height}`,
            `- **Page scroll:** x ${scroll.x}, y ${scroll.y}`,
            ""
          );
          continue;
        }
        const { element } = note;
        lines.push(
          `- **Element:** ${inlineCode(element.tag)}`,
          element.selectorPath.length === 1 ? `- **Selector:** ${inlineCode(element.selectorPath[0])}` : `- **Selector path:** ${element.selectorPath.map(inlineCode).join(" \u2192 shadow root \u2192 ")}`,
          ...element.text ? [`- **Text excerpt:** ${inlineCode(element.text)}`] : [],
          ...element.label ? [`- **Accessible label:** ${inlineCode(element.label)}`] : [],
          `- **Viewport:** ${element.viewport.width} \xD7 ${element.viewport.height}`,
          ""
        );
      }
    }
    return lines.join("\n");
  }
  function inlineCode(value) {
    const text = value.replace(/\r\n?|\n/g, " ");
    if (!text) return "*(empty)*";
    const longest = Math.max(0, ...(text.match(/`+/g) || []).map((run) => run.length));
    const delimiter = "`".repeat(longest + 1);
    const pad = /^`|`$/.test(text) || /^ .* $/.test(text) && !/^ +$/.test(text);
    return `${delimiter}${pad ? " " : ""}${text}${pad ? " " : ""}${delimiter}`;
  }
  function quote(value) {
    return value.replace(/[\\`*_[\]<>#!|]/g, "\\$&").split(/\r\n?|\n/).map((line) => `> ${line}`).join("\n");
  }

  // src/export.ts
  function feedbackArchive(notes, preamble) {
    const encoder = new TextEncoder();
    const files = [
      { name: "comments.md", data: encoder.encode(buildPrompt(notes, preamble)) },
      ...notes.filter((note) => note.screenshot).map((note) => ({
        name: screenshotFilename(note),
        data: Uint8Array.from(atob(note.screenshot.dataUrl.split(",")[1]), (char) => char.charCodeAt(0))
      }))
    ];
    const parts = [];
    const directory = [];
    let offset = 0;
    for (const file of files) {
      const name = encoder.encode(file.name);
      const crc = crc32(file.data);
      const header = new Uint8Array(30 + name.length);
      const view2 = new DataView(header.buffer);
      view2.setUint32(0, 67324752, true);
      view2.setUint16(4, 20, true);
      view2.setUint16(6, 2048, true);
      view2.setUint16(12, 33, true);
      view2.setUint32(14, crc, true);
      view2.setUint32(18, file.data.length, true);
      view2.setUint32(22, file.data.length, true);
      view2.setUint16(26, name.length, true);
      header.set(name, 30);
      const entry = new Uint8Array(46 + name.length);
      const central = new DataView(entry.buffer);
      central.setUint32(0, 33639248, true);
      central.setUint16(4, 20, true);
      central.setUint16(6, 20, true);
      central.setUint16(8, 2048, true);
      central.setUint16(14, 33, true);
      central.setUint32(16, crc, true);
      central.setUint32(20, file.data.length, true);
      central.setUint32(24, file.data.length, true);
      central.setUint16(28, name.length, true);
      central.setUint32(42, offset, true);
      entry.set(name, 46);
      parts.push(header, file.data);
      directory.push(entry);
      offset += header.length + file.data.length;
    }
    const size = directory.reduce((sum, entry) => sum + entry.length, 0);
    const end = new Uint8Array(22);
    const view = new DataView(end.buffer);
    view.setUint32(0, 101010256, true);
    view.setUint16(8, files.length, true);
    view.setUint16(10, files.length, true);
    view.setUint32(12, size, true);
    view.setUint32(16, offset, true);
    const archive = new Uint8Array(offset + size + end.length);
    let position = 0;
    for (const part of [...parts, ...directory, end]) {
      archive.set(part, position);
      position += part.length;
    }
    return archive;
  }
  function crc32(bytes) {
    let crc = 4294967295;
    for (const byte of bytes) {
      crc ^= byte;
      for (let bit = 0; bit < 8; bit++) crc = crc >>> 1 ^ (crc & 1 ? 3988292384 : 0);
    }
    return (crc ^ 4294967295) >>> 0;
  }
  function downloadFile(data, name) {
    const url = URL.createObjectURL(data);
    const link = document.createElement("a");
    link.href = url;
    link.download = name;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 6e4);
  }

  // src/status.ts
  var TOAST_DURATION_MS = 4e3;
  function statusMessage(element, signal) {
    let timer;
    const cancel = () => {
      window.clearTimeout(timer);
      timer = void 0;
    };
    signal.addEventListener("abort", cancel, { once: true });
    return (text = "", { error = false, persistent = error } = {}) => {
      if (signal.aborted) return;
      cancel();
      element.textContent = text;
      element.classList.toggle("error", error);
      if (text && !persistent) {
        timer = window.setTimeout(() => {
          element.textContent = "";
          timer = void 0;
        }, TOAST_DURATION_MS);
      }
    };
  }

  // src/split-menu.ts
  function splitMenu(group, toggle, menu, signal) {
    const items = () => [...menu.querySelectorAll('[role="menuitem"]')].filter((item) => !item.disabled);
    function setOpen(open, restoreFocus = false, last = false) {
      open = open && !toggle.disabled;
      menu.hidden = !open;
      toggle.setAttribute("aria-expanded", String(open));
      if (open) (last ? items().at(-1) : items()[0])?.focus();
      else if (restoreFocus) toggle.focus();
    }
    toggle.addEventListener("click", () => setOpen(!!menu.hidden), { signal });
    group.addEventListener("keydown", (event) => {
      if (event.target !== toggle && !menu.contains(event.target)) return;
      if (["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key)) {
        event.preventDefault();
        if (menu.hidden) {
          setOpen(true, false, event.key === "ArrowUp" || event.key === "End");
          return;
        }
        const enabled = items();
        const current = enabled.indexOf(event.target);
        const next = event.key === "Home" ? 0 : event.key === "End" ? enabled.length - 1 : (current + (event.key === "ArrowUp" ? -1 : 1) + enabled.length) % enabled.length;
        enabled[next]?.focus();
      } else if (!menu.hidden && ["Escape", "Tab"].includes(event.key)) {
        if (event.key === "Escape") event.preventDefault();
        setOpen(false, true);
      }
    }, { signal });
    const dismiss = (event) => {
      if (!event.composedPath().includes(menu) && !event.composedPath().includes(toggle)) setOpen(false);
    };
    document.addEventListener("pointerdown", dismiss, { capture: true, signal });
    document.addEventListener("focusin", dismiss, { capture: true, signal });
    return setOpen;
  }

  // src/content.ts
  var THEME_KEY = "briefmark:theme";
  var PREAMBLE_KEY = "briefmark:prompt-preamble";
  var CONFIRM_DELETE_KEY = "briefmark:confirm-comment-deletion";
  function mount(runtime) {
    const { store, presentation: integration } = runtime;
    const native = integration?.native ?? false;
    const mobile = !native && (/Android|iPhone|iPad|Mobile/i.test(navigator.userAgent) || matchMedia("(pointer: coarse)").matches && !matchMedia("(any-pointer: fine)").matches);
    let presentation = native ? "native" : "overlay";
    let canDock = false;
    let returnToDock = false;
    let applyingState = false;
    const host = document.createElement("pagebrief-overlay");
    host.style.cssText = "all:initial!important;position:fixed!important;inset:0!important;width:0!important;height:0!important;z-index:2147483647!important;";
    const shadow = host.attachShadow({ mode: "open" });
    const app = document.createElement("div");
    app.className = native ? "app native" : "app";
    app.innerHTML = `
    <aside class="panel" aria-label="Briefmark feedback panel">
      <header><span class="logo" aria-hidden="true">\u2197</span><div class="brand">Briefmark</div><button class="icon-button settings-button" aria-label="Extension settings" title="Settings" aria-expanded="false" aria-controls="settings"><span data-icon="settings"></span></button><button class="icon-button dock" hidden aria-label="Dock sidebar" title="Dock sidebar"><span data-icon="pin"></span></button><button class="icon-button minimize" aria-label="Minimize comments" title="Minimize comments"><span data-icon="minus"></span></button><button class="icon-button close" aria-label="Close Briefmark" title="Close Briefmark"><span data-icon="close"></span></button></header>
      <div class="scope-row"><select aria-label="Comment scope"><option value="page">This page</option><option value="all">All pages</option></select><span class="count">0 comments</span></div>
      <div class="content"><div class="editor-slot"></div><div class="notes"></div></div>
      <section class="settings" id="settings" aria-label="Extension settings" hidden><div class="settings-heading"><button class="settings-back"><span data-icon="back"></span>Back</button><h1>Settings</h1></div><h2 id="theme-label">Appearance</h2><div class="theme-options" role="group" aria-labelledby="theme-label"><button class="theme-option" data-theme="light" aria-pressed="true"><span data-icon="sun"></span>Light</button><button class="theme-option" data-theme="dark" aria-pressed="false"><span data-icon="moon"></span>Dark</button></div><p class="settings-status" role="status" aria-live="polite"></p><section class="preferences" aria-labelledby="preferences-title"><h2 id="preferences-title">Preferences</h2><div class="preference-row"><span id="confirm-delete-label">Show individual comment deletion confirmation</span><button class="confirm-delete-toggle" role="switch" aria-checked="true" aria-labelledby="confirm-delete-label" disabled><span class="switch-track" aria-hidden="true"></span><span class="switch-value" aria-hidden="true">On</span></button></div><p class="preferences-status" role="status" aria-live="polite"></p></section><div class="preamble-settings"><label for="preamble">Prompt Preamble</label><p id="preamble-help">Text before the comments. Markdown supported.</p><textarea id="preamble" rows="7" aria-describedby="preamble-help" spellcheck="false" disabled></textarea><div class="preamble-actions"><button class="primary save-preamble" disabled><span data-icon="save"></span>Save Preamble</button><button class="secondary reset-preamble" disabled><span data-icon="restore"></span>Restore Default</button></div><p class="preamble-status" role="status" aria-live="polite"></p></div></section>
      <p class="status" role="status" aria-live="polite"></p>
      <button class="danger-button clear-copied" hidden><span data-icon="trash"></span>Delete All Comments</button>
      <footer><section class="intro split-button" role="group" aria-label="Comment Actions"><button class="primary select split-main"><span data-icon="select"></span><span class="button-label">Select Element</span></button><button class="primary comment-options split-options" aria-label="More Comment Options" title="More Comment Options" aria-haspopup="menu" aria-expanded="false" aria-controls="comment-menu"><span data-icon="chevron"></span></button><div class="comment-menu split-menu" id="comment-menu" role="menu" aria-label="Comment Options" hidden><button class="menu-action capture" role="menuitem" tabindex="-1"><span data-icon="camera"></span><span class="button-label">Take Screenshot</span></button><button class="menu-action global-comment" role="menuitem" tabindex="-1"><span data-icon="comment"></span>New Global Comment</button></div></section><div class="footer-buttons split-button" role="group" aria-label="Prompt Actions"><button class="primary copy split-main" disabled><span data-icon="copy"></span>Copy Prompt</button><button class="primary copy-options split-options" aria-label="More Prompt Options" title="More Prompt Options" aria-haspopup="menu" aria-expanded="false" aria-controls="copy-menu" disabled><span data-icon="chevron"></span></button><div class="copy-menu split-menu" id="copy-menu" role="menu" aria-label="Prompt Options" hidden><button class="danger-button delete-all" role="menuitem" tabindex="-1" aria-disabled="true"><span data-icon="trash"></span>Delete All Comments</button></div></div><button class="text-button download" hidden><span data-icon="download"></span>Download Markdown + Images</button><a class="support-link" href="https://buymeacoffee.com/htxryan" target="_blank" rel="noopener noreferrer" aria-label="Buy me a coffee (opens in new tab)" hidden>Buy me a coffee</a></footer>
      <div class="connection-shade" aria-hidden="true" hidden></div>
      <div class="connection-prompt" role="status" tabindex="-1" hidden><span data-icon="connect"></span><p class="connection-instruction">Click Briefmark in the browser toolbar to connect this page.</p><p>Browser settings and protected pages cannot be annotated.</p></div>
      <dialog class="delete-dialog" aria-labelledby="delete-title" aria-describedby="delete-description"><form method="dialog"><h2 id="delete-title">Delete All Comments?</h2><p id="delete-description"></p><div class="dialog-actions"><button class="secondary" value="cancel" autofocus><span data-icon="close"></span>Cancel</button><button class="danger-button" value="delete"><span data-icon="trash"></span><span class="button-label">Delete All Comments</span></button></div></form></dialog>
    </aside>
    <div class="minimized-actions" role="group" aria-label="Quick Comment Actions" hidden><button class="quick-action quick-select" aria-label="Select Element" title="Select Element"><span data-icon="select"></span></button><button class="quick-action quick-capture" aria-label="Take Screenshot" title="Take Screenshot"><span data-icon="camera"></span></button><button class="quick-action quick-global-comment" aria-label="New Global Comment" title="New Global Comment"><span data-icon="comment-add"></span></button><button class="resume" hidden aria-label="Show Briefmark comments" title="Reopen Comments"><span data-icon="comment"></span><span class="button-label">Comments</span><span data-icon="maximize"></span></button></div>
    <div class="picker-bar" hidden><strong>\u2316 Tap or click an element</strong><button><span data-icon="close"></span>Cancel</button></div>
    <div class="editor-shade" aria-hidden="true" hidden><div class="editor-cutout" hidden></div></div>
    <div class="outline" hidden></div><div class="hover-label" hidden></div><div class="pins"></div>`;
    renderIcons(app);
    app.querySelector(".support-link").prepend(createSupportIcon());
    app.querySelector(".settings-button").setAttribute("aria-label", runtime.settingsLabel);
    app.querySelector(".settings").setAttribute("aria-label", runtime.settingsLabel);
    if (!runtime.capture) {
      const capture = app.querySelector(".capture");
      capture.disabled = true;
      capture.title = runtime.captureUnavailable || "Screenshots unavailable";
    }
    shadow.append(app);
    document.documentElement.append(host);
    const $ = (selector) => shadow.querySelector(selector);
    const abort = new AbortController();
    for (const name of ["keydown", "keypress", "keyup"]) {
      shadow.addEventListener(name, (event) => event.stopPropagation(), { signal: abort.signal });
    }
    const panelStatus = statusMessage($(".status"), abort.signal);
    const preambleStatus = statusMessage($(".preamble-status"), abort.signal);
    const settingsStatus = statusMessage($(".settings-status"), abort.signal);
    const preferencesStatus = statusMessage($(".preferences-status"), abort.signal);
    let notes = [];
    let noteViews = [];
    let disposeEditor;
    let url = native ? "" : pageUrl();
    let title = native ? "" : document.title;
    let draft = null;
    let composeOnPage = false;
    let composingFromMinimized = false;
    let picking = false;
    let settings = false;
    let themeVersion = 0;
    let themeSaving = false;
    let preamble = DEFAULT_PROMPT_PREAMBLE;
    let preambleDraft = null;
    let preambleReady = false;
    let preambleLoading = true;
    let preambleSaving = false;
    let preambleCustom = false;
    let preambleVersion = 0;
    let saving = false;
    let copyFailed = false;
    let copiedComments = null;
    let pendingDeletion = null;
    let confirmIndividualDeletion = true;
    let deletionPreferenceVersion = 0;
    let deletionPreferenceSaving = false;
    let deleting = false;
    let connectionWarning = false;
    let captureBusy = false;
    let captureAbort = null;
    let highlighted = null;
    let locatedId = null;
    let readVersion = 0;
    let alive = true;
    let frame = 0;
    let pinsSignature = "";
    let touch = null;
    const touchPointers = /* @__PURE__ */ new Set();
    let suppressMouseUntil = 0;
    const scope = $("select");
    const setCopyMenu = splitMenu($(".footer-buttons"), $(".copy-options"), $("#copy-menu"), abort.signal);
    const setCommentMenu = splitMenu($(".intro"), $(".comment-options"), $("#comment-menu"), abort.signal);
    function viewState() {
      return { url, pageTitle: native ? title : document.title, draft, scope: scope.value, picking, settings, preambleDraft, capturing: captureBusy, composeOnPage };
    }
    function renderPreamble() {
      const field = $("#preamble");
      const value = preambleDraft ?? preamble;
      if (field.value !== value) field.value = value;
      field.disabled = preambleLoading || preambleSaving;
      $(".save-preamble").disabled = field.disabled || preambleDraft === null;
      $(".reset-preamble").disabled = field.disabled || preambleReady && !preambleCustom && preambleDraft === null;
    }
    function renderPrompt() {
      const filtered = visibleNotes();
      if (copiedComments && commentSignature(copiedComments) !== commentSignature(filtered)) copiedComments = null;
      const showClear = !!copiedComments && !settings && !draft;
      $(".clear-copied").hidden = !showClear;
      $(".clear-copied").disabled = deleting;
      $(".delete-all").setAttribute("aria-disabled", String(!filtered.length));
      $(".delete-all").title = filtered.length ? "" : "No comments to delete.";
      $(".copy-options").disabled = !filtered.length;
      if ($(".copy-options").disabled || connectionWarning) setCopyMenu(false);
      $(".copy").disabled = !filtered.length || !preambleReady || deleting;
      $(".download").hidden = settings || !copyFailed && !filtered.some((note) => note.screenshot);
      $(".download").disabled = !preambleReady;
    }
    function commentSignature(list) {
      return JSON.stringify(list.map((note) => [note.id, note.updatedAt, note.comment]));
    }
    function applyPreamble(value) {
      if (!preambleReady && !preambleLoading) status();
      preambleCustom = typeof value === "string";
      preamble = typeof value === "string" ? value : DEFAULT_PROMPT_PREAMBLE;
      preambleReady = true;
      preambleLoading = false;
      if (preambleDraft === preamble) preambleDraft = null;
      renderPreamble();
      renderPrompt();
    }
    async function loadPreamble() {
      const version = preambleVersion;
      try {
        const stored = await store.read(PREAMBLE_KEY);
        if (alive && version === preambleVersion) applyPreamble(stored);
      } catch {
        if (alive && version === preambleVersion) {
          preambleLoading = false;
          renderPreamble();
          preambleStatus("Could not load your preamble. Save or restore to continue.", { error: true });
          status("Could not load prompt settings. Open Settings to save or restore the preamble.", true);
        }
      }
    }
    async function savePreamble(reset = false) {
      if (preambleLoading || preambleSaving) return;
      const value = reset ? void 0 : preambleDraft ?? preamble;
      const version = ++preambleVersion;
      preambleSaving = true;
      renderPreamble();
      preambleStatus();
      try {
        if (reset) await store.remove(PREAMBLE_KEY);
        else await store.write(PREAMBLE_KEY, value);
        if (alive) {
          if (version === preambleVersion) applyPreamble(value);
          preambleDraft = null;
          preambleStatus(reset ? "Default restored." : "Preamble saved.");
          syncState();
        }
      } catch {
        preambleStatus("Could not save your preamble. Your changes are still here. Try again.", { error: true });
      } finally {
        preambleSaving = false;
        renderPreamble();
      }
    }
    function applyTheme(value) {
      const theme = value === "dark" ? "dark" : "light";
      app.dataset.theme = theme;
      for (const button of shadow.querySelectorAll(".theme-option")) {
        button.setAttribute("aria-pressed", String(button.dataset.theme === theme));
      }
    }
    async function loadTheme() {
      const version = themeVersion;
      try {
        const stored = await store.read(THEME_KEY);
        if (alive && version === themeVersion) applyTheme(stored);
      } catch {
        if (alive && version === themeVersion) settingsStatus("Could not load your theme preference. Choose a theme to try again.", { error: true });
      }
    }
    async function saveTheme(theme) {
      if (themeSaving) return;
      themeSaving = true;
      const version = ++themeVersion;
      const buttons = [...shadow.querySelectorAll(".theme-option")];
      buttons.forEach((button) => {
        button.disabled = true;
      });
      settingsStatus();
      try {
        await store.write(THEME_KEY, theme);
        if (alive) {
          if (version === themeVersion) applyTheme(theme);
          settingsStatus("Theme saved.");
        }
      } catch {
        settingsStatus("Could not save your theme. Please try again.", { error: true });
      } finally {
        themeSaving = false;
        buttons.forEach((button) => {
          button.disabled = false;
        });
      }
    }
    function applyDeletionPreference(value) {
      confirmIndividualDeletion = value !== false;
      $(".confirm-delete-toggle").setAttribute("aria-checked", String(confirmIndividualDeletion));
      $(".switch-value").textContent = confirmIndividualDeletion ? "On" : "Off";
    }
    async function loadDeletionPreference() {
      const version = deletionPreferenceVersion;
      try {
        const value = await store.read(CONFIRM_DELETE_KEY);
        if (alive && version === deletionPreferenceVersion) applyDeletionPreference(value);
      } catch {
        if (alive && version === deletionPreferenceVersion) preferencesStatus("Could not load this preference. Deletion confirmation remains on.", { error: true });
      } finally {
        if (alive) $(".confirm-delete-toggle").disabled = deletionPreferenceSaving;
      }
    }
    $(".confirm-delete-toggle").addEventListener("click", async () => {
      if (deletionPreferenceSaving) return;
      deletionPreferenceSaving = true;
      const version = ++deletionPreferenceVersion;
      const value = !confirmIndividualDeletion;
      $(".confirm-delete-toggle").disabled = true;
      preferencesStatus();
      try {
        await store.write(CONFIRM_DELETE_KEY, value);
        if (alive) {
          if (version === deletionPreferenceVersion) applyDeletionPreference(value);
          preferencesStatus("Preference saved.");
        }
      } catch {
        if (alive) preferencesStatus("Could not save this preference. Please try again.", { error: true });
      } finally {
        deletionPreferenceSaving = false;
        if (alive) $(".confirm-delete-toggle").disabled = false;
      }
    });
    function renderView() {
      $(".settings").hidden = !settings;
      $(".connection-prompt").hidden = !connectionWarning || settings;
      $(".connection-shade").hidden = !connectionWarning || settings;
      $(".settings-button").setAttribute("aria-expanded", String(settings));
      $(".intro").hidden = settings;
      $(".scope-row").hidden = settings;
      $(".content").hidden = settings;
      $(".footer-buttons").hidden = settings;
      $(".support-link").hidden = !settings;
      if (settings) setCommentMenu(false);
      renderPrompt();
      scheduleDraw();
    }
    function setSettings(value) {
      if (value && composeOnPage) {
        composeOnPage = false;
        renderEditor();
      }
      settings = value;
      if (value && picking) setPicking(false);
      renderView();
      syncState();
    }
    function syncState() {
      if (applyingState || !alive || !integration) return;
      void integration.sync(viewState(), presentation === "remote").catch(connectionError);
    }
    function applyState(state) {
      if (!alive) return;
      applyingState = true;
      url = state.url;
      if (native) title = state.pageTitle ?? "";
      draft = state.draft;
      composeOnPage = !!draft && !!state.composeOnPage && (native || presentation === "remote");
      captureBusy = !!state.capturing;
      preambleDraft = typeof state.preambleDraft === "string" ? state.preambleDraft : null;
      renderPreamble();
      scope.value = state.scope;
      setPicking(state.picking);
      renderEditor();
      setSettings(!!state.settings);
      applyingState = false;
      if (state.url && connectionWarning) setConnectionWarning(false);
    }
    function setConnectionWarning(value) {
      const prompt = $(".connection-prompt");
      const changed = connectionWarning !== value;
      const restoreFocus = shadow.activeElement === prompt;
      connectionWarning = value;
      if (value) {
        setCopyMenu(false);
        setCommentMenu(false);
      }
      prompt.hidden = !value || settings;
      $(".connection-shade").hidden = prompt.hidden;
      if (value && changed && !settings) prompt.focus({ preventScroll: true });
      else if (!value && restoreFocus) $(".select").focus({ preventScroll: true });
    }
    function connectionError(error) {
      setConnectionWarning(true);
      if (error) console.debug("Briefmark connection:", error);
    }
    async function changeLayout(mode) {
      if (captureBusy) {
        status("Finish or cancel the screenshot first.");
        return;
      }
      if (saving || preambleSaving || themeSaving || deletionPreferenceSaving) {
        status("Finishing your save\u2026");
        return;
      }
      if (integration?.dockViaToolbar && !native && mode === "dock") {
        setMinimized(false);
        status("Click Briefmark in Firefox\u2019s toolbar or Extensions menu to dock this panel.");
        return;
      }
      try {
        await integration?.changeLayout(mode, viewState(), mobile);
      } catch (error) {
        console.error("Briefmark layout:", error);
        status("Could not change layout. Click Briefmark in the browser toolbar to open the sidebar.", true);
      }
    }
    function updateDockButton() {
      $(".dock").hidden = !native && (!canDock || mobile);
      $(".dock").replaceChildren(icon(native ? "unpin" : "pin"));
      $(".dock").setAttribute("aria-label", native ? "Float panel" : "Dock sidebar");
      $(".dock").title = native ? "Float panel over the page" : integration?.dockViaToolbar ? "Dock using Briefmark\u2019s toolbar icon" : "Dock sidebar beside the page";
    }
    function updateViewport() {
      const viewport = window.visualViewport;
      app.style.setProperty("--viewport-height", `${viewport?.height ?? innerHeight}px`);
      app.style.setProperty("--viewport-bottom", `${Math.max(0, innerHeight - ((viewport?.offsetTop ?? 0) + (viewport?.height ?? innerHeight)))}px`);
      scheduleDraw();
    }
    function setMinimized(value) {
      setCopyMenu(false);
      setCommentMenu(false);
      $(".panel").hidden = !native && (presentation === "remote" && !composeOnPage || value || picking);
      $(".resume").hidden = native || presentation === "remote" || !value || picking;
      $(".minimized-actions").hidden = $(".resume").hidden;
      $(".quick-select").disabled = !!draft || captureBusy;
      $(".quick-capture").disabled = !runtime.capture || !!draft || captureBusy;
      $(".quick-global-comment").disabled = !!draft || captureBusy;
      if (value && shadow.activeElement instanceof HTMLElement) shadow.activeElement.blur();
      updateViewport();
    }
    let minimizing = false;
    let minimizeAnimation;
    async function minimize() {
      if (minimizing || captureBusy) return;
      if (saving || preambleSaving || themeSaving || deletionPreferenceSaving) {
        status("Finishing your save\u2026");
        return;
      }
      if (native && integration?.dockViaToolbar) {
        await changeLayout("minimized");
        return;
      }
      const panel = $(".panel");
      let animation;
      minimizing = true;
      panel.inert = true;
      try {
        if (!matchMedia("(prefers-reduced-motion: reduce)").matches) {
          animation = panel.animate([
            { transform: "none", opacity: 1, transformOrigin: "bottom right" },
            { transform: "translate(-14px, -14px) scale(.35, .06)", opacity: 0, transformOrigin: "bottom right" }
          ], { duration: 240, easing: "cubic-bezier(.4, 0, .2, 1)", fill: "forwards" });
          minimizeAnimation = animation;
          try {
            await animation.finished;
          } catch {
            return;
          }
        }
        if (!alive) return;
        if (native) await changeLayout("minimized");
        else {
          returnToDock = false;
          setMinimized(true);
          $(".resume").focus({ preventScroll: true });
        }
      } finally {
        animation?.cancel();
        minimizeAnimation = void 0;
        panel.inert = false;
        minimizing = false;
      }
    }
    function visibleNotes() {
      return scope.value === "all" ? notes : notes.filter((note) => samePage(note.pageUrl, url));
    }
    function status(text = "", error = false) {
      panelStatus(text, { error });
    }
    function showError(error) {
      console.error("Briefmark:", error);
      if (alive) status(runtime.storageError, true);
    }
    async function refresh() {
      const version = ++readVersion;
      try {
        const loaded = await readNotes(store);
        if (!alive || version !== readVersion) return;
        notes = loaded;
        renderNotes();
      } catch (error) {
        showError(error);
      }
    }
    function setPicking(value) {
      picking = value;
      if (value) locatedId = null;
      setMinimized(false);
      $(".picker-bar").hidden = !value || native;
      $(".select .button-label").textContent = value ? "Cancel Selection" : "Select Element";
      touch = null;
      touchPointers.clear();
      highlighted = null;
      $(".outline").hidden = true;
      $(".hover-label").hidden = true;
      drawPins();
      syncState();
    }
    function rectFor(element) {
      const rect = element.getBoundingClientRect();
      return rect.width && rect.height && rect.bottom > 0 && rect.right > 0 && rect.top < innerHeight && rect.left < innerWidth ? rect : null;
    }
    function drawHighlight() {
      if (native) return;
      const rect = !draft && highlighted?.isConnected ? rectFor(highlighted) : null;
      const outline = $(".outline");
      const label = $(".hover-label");
      outline.hidden = !rect;
      label.hidden = !rect || !picking;
      if (!rect) return;
      Object.assign(outline.style, { top: `${rect.top}px`, left: `${rect.left}px`, width: `${rect.width}px`, height: `${rect.height}px` });
      label.textContent = highlighted.localName + (highlighted.id ? `#${shorten(highlighted.id, 35)}` : "");
      Object.assign(label.style, { top: `${Math.max(4, rect.top - 28)}px`, left: `${Math.max(4, Math.min(rect.left, innerWidth - 180))}px` });
    }
    function noteRect(note) {
      if (note.kind === "page" || !samePage(note.pageUrl, pageUrl())) return null;
      if (note.screenshot) {
        const { region, scroll } = note.screenshot;
        return new DOMRect(region.x + scroll.x - scrollX, region.y + scroll.y - scrollY, region.width, region.height);
      }
      const element = resolveElement(note.element);
      return element ? rectFor(element) : null;
    }
    function drawEditorShade() {
      const shade = $(".editor-shade");
      shade.hidden = native || !draft || !samePage(draft.pageUrl, pageUrl()) || picking || settings || presentation !== "remote" && $(".panel").hidden;
      if (shade.hidden || !draft) return;
      const rect = noteRect(draft);
      const cutout = $(".editor-cutout");
      const visible = !!rect && rect.bottom > 0 && rect.right > 0 && rect.top < innerHeight && rect.left < innerWidth;
      cutout.hidden = !visible;
      shade.classList.toggle("has-target", visible);
      if (rect && visible) {
        Object.assign(cutout.style, { top: `${rect.top}px`, left: `${rect.left}px`, width: `${rect.width}px`, height: `${rect.height}px` });
      }
    }
    function drawPins() {
      if (native) return;
      const pins = $(".pins");
      const positions = visibleNotes().flatMap((note, index) => {
        if (!samePage(note.pageUrl, url)) return [];
        const rect = noteRect(note);
        if (!rect || rect.bottom <= 0 || rect.right <= 0 || rect.top >= innerHeight || rect.left >= innerWidth) return [];
        return [{ note, index, rect, top: Math.max(2, rect.top - 12), left: Math.max(2, Math.min(rect.left - 12, innerWidth - 26)) }];
      });
      const signature = JSON.stringify([locatedId, picking, positions.map(({ note, index, rect, top, left }) => [note.id, note.updatedAt, index, rect.x, rect.y, rect.width, rect.height, top, left])]);
      if (signature === pinsSignature) return;
      pinsSignature = signature;
      pins.replaceChildren();
      positions.forEach(({ note, index, rect, top, left }) => {
        const outline = document.createElement("div");
        outline.className = "saved-outline";
        outline.classList.toggle("active", note.id === locatedId);
        outline.dataset.noteId = note.id;
        outline.setAttribute("aria-hidden", "true");
        Object.assign(outline.style, { top: `${rect.top}px`, left: `${rect.left}px`, width: `${rect.width}px`, height: `${rect.height}px` });
        const pin = document.createElement("button");
        pin.className = "pin";
        pin.classList.toggle("active", note.id === locatedId);
        pin.dataset.noteId = note.id;
        pin.disabled = picking;
        pin.textContent = String(index + 1);
        pin.setAttribute("aria-label", `Edit comment ${index + 1}`);
        pin.title = shorten(note.comment, 90);
        pin.style.top = `${top}px`;
        pin.style.left = `${left}px`;
        pin.addEventListener("click", () => editNote(note));
        pins.append(outline, pin);
      });
    }
    function draw() {
      frame = 0;
      drawEditorShade();
      drawHighlight();
      drawPins();
    }
    function scheduleDraw() {
      if (alive && !frame) frame = requestAnimationFrame(draw);
    }
    function liveHierarchy(note) {
      if (!note.element || !samePage(note.pageUrl, pageUrl())) return null;
      const element = resolveElement(note.element);
      return element ? elementHierarchy(element) : null;
    }
    function commentView(note, number, editing = false) {
      const missingHierarchy = note.element && !note.element.hierarchy?.length;
      const hierarchy = !native && missingHierarchy ? liveHierarchy(note) : null;
      const displayNote = hierarchy && note.element ? { ...note, element: { ...note.element, hierarchy } } : note;
      const view = createCommentCard(displayNote, number, editing);
      if (native && missingHierarchy && samePage(note.pageUrl, url)) {
        void integration.hierarchy(note).then((parts) => {
          if (alive && view.card.isConnected && samePage(note.pageUrl, url) && parts?.length) view.setHierarchy(parts);
        }).catch(() => {
        });
      }
      if (note.screenshot) {
        const photo = privateImage(note.screenshot.dataUrl, editing ? "Screenshot to comment on" : "Comment screenshot");
        photo.className = "screenshot-preview";
        view.card.querySelector(".note-metadata").append(photo);
      }
      const locate = view.card.querySelector(".locate");
      locate.disabled = !samePage(note.pageUrl, url);
      locate.addEventListener("click", async () => {
        try {
          const found = native ? await integration.locate(note, false) : locateNote(note, false);
          status(found ? `${note.screenshot ? "Screenshot region" : "Element"} highlighted on the page.` : "This element has changed or is no longer on the page. Your comment is still saved.", !found);
        } catch (error) {
          connectionError(error);
        }
      });
      return view;
    }
    function renderNotes() {
      if (locatedId && !notes.some((note) => note.id === locatedId)) locatedId = null;
      const filtered = visibleNotes();
      $(".count").textContent = `${filtered.length} comment${filtered.length === 1 ? "" : "s"}`;
      $(".resume .button-label").textContent = `${filtered.length} Comment${filtered.length === 1 ? "" : "s"}`;
      renderPrompt();
      const list = $(".notes");
      noteViews.forEach((dispose2) => dispose2());
      noteViews = [];
      list.replaceChildren();
      if (!filtered.length && !draft) {
        list.innerHTML = '<div class="empty">No comments yet.</div>';
      }
      filtered.forEach((note, index) => {
        const { card, dispose: dispose2 } = commentView(note, index + 1);
        noteViews.push(dispose2);
        card.querySelector(".edit").addEventListener("click", () => editNote(note));
        card.querySelector(".delete").addEventListener("click", () => {
          if (deleting) return;
          if (confirmIndividualDeletion) showDeleteConfirmation({ kind: "single", note });
          else void deleteComment(note);
        });
        if (scope.value === "all") {
          const label = card.querySelector(".page-label");
          label.hidden = false;
          label.textContent = note.pageUrl;
          label.title = note.pageUrl;
        }
        list.append(card);
      });
      drawPins();
    }
    function editNote(note) {
      if (draft) {
        status("Save or cancel your current draft before editing another comment.", true);
        return;
      }
      setMinimized(false);
      draft = structuredClone(note);
      composeOnPage = presentation === "remote";
      setSettings(false);
      renderEditor();
    }
    function locateNote(note, parent) {
      if (note.kind === "page" || !samePage(note.pageUrl, pageUrl())) return null;
      if (note.screenshot) {
        if (parent) return null;
        const { region, scroll } = note.screenshot;
        window.scrollTo({ left: Math.max(0, scroll.x + region.x + region.width / 2 - innerWidth / 2), top: Math.max(0, scroll.y + region.y + region.height / 2 - innerHeight / 2), behavior: "instant" });
        highlighted = null;
      } else {
        const element = resolveElement(note.element);
        const target = parent ? element?.parentElement || (element?.getRootNode() instanceof ShadowRoot ? element.getRootNode().host : null) : element;
        if (!target || target === document.documentElement) return null;
        target.scrollIntoView({ block: "center", inline: "nearest", behavior: "instant" });
        highlighted = parent ? target : null;
        if (parent) {
          drawHighlight();
          return captureElement(target);
        }
      }
      locatedId = note.id;
      drawHighlight();
      drawPins();
      return true;
    }
    function renderEditor() {
      scheduleDraw();
      if (!draft) composeOnPage = false;
      app.classList.toggle("composing", composeOnPage && !native);
      if (presentation === "remote") setMinimized(false);
      app.classList.toggle("editing", !!draft);
      const slot = $(".editor-slot");
      disposeEditor?.();
      disposeEditor = void 0;
      slot.replaceChildren();
      $(".select").disabled = !!draft || captureBusy || native && !url;
      $(".capture").disabled = !runtime.capture || !!draft || captureBusy || native && !url;
      $(".comment-options").disabled = !!draft || captureBusy || !url;
      $(".global-comment").disabled = !!draft || captureBusy || !url;
      if ($(".comment-options").disabled) setCommentMenu(false);
      for (const selector of [".dock", ".minimize", ".settings-button", ".close"]) $(selector).disabled = captureBusy;
      scope.disabled = captureBusy || native && !url;
      if (!draft) {
        renderNotes();
        syncState();
        if (composingFromMinimized && !captureBusy && !picking) {
          composingFromMinimized = false;
          setMinimized(true);
          $(".resume").focus({ preventScroll: true });
        }
        return;
      }
      if (native && composeOnPage) {
        slot.innerHTML = '<div class="draft-on-page"><p>Write your comment in the editor on the page.</p><button class="secondary edit-in-sidebar" type="button"><span data-icon="edit"></span>Edit in Sidebar</button></div>';
        renderIcons(slot);
        slot.querySelector(".edit-in-sidebar").addEventListener("click", () => {
          composeOnPage = false;
          renderEditor();
        });
        renderNotes();
        syncState();
        return;
      }
      const filtered = visibleNotes();
      const index = filtered.findIndex((note) => note.id === draft.id);
      const view = commentView(draft, index < 0 ? filtered.length + 1 : index + 1, true);
      disposeEditor = view.dispose;
      slot.append(view.card);
      const textarea = slot.querySelector("textarea");
      textarea.value = draft.comment;
      const parentButton = slot.querySelector(".parent");
      parentButton.hidden = !draft.element;
      const element = samePage(draft.pageUrl, url) && draft.element ? resolveElement(draft.element) : null;
      const parent = element?.parentElement || (element?.getRootNode() instanceof ShadowRoot ? element.getRootNode().host : null);
      parentButton.disabled = saving || !samePage(draft.pageUrl, url) || !native && (!parent || parent === document.documentElement);
      parentButton.addEventListener("click", async () => {
        if (native && draft?.element && !saving) {
          try {
            const element2 = await integration.locate(draft, true);
            if (element2 && typeof element2 !== "boolean" && draft?.element) {
              draft.element = element2;
              renderEditor();
            } else {
              parentButton.disabled = true;
              status("No parent element is available on this page.");
            }
          } catch (error) {
            connectionError(error);
          }
        } else if (draft?.element && parent && !saving && samePage(draft.pageUrl, pageUrl())) {
          draft.element = captureElement(parent);
          highlighted = parent;
          drawHighlight();
          renderEditor();
        }
      });
      textarea.disabled = saving;
      slot.querySelector(".save").disabled = saving;
      slot.querySelector(".cancel").disabled = saving;
      textarea.addEventListener("input", () => {
        if (draft) {
          draft.comment = textarea.value;
          syncState();
        }
      });
      textarea.addEventListener("keydown", (event) => {
        if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
          event.preventDefault();
          void commitDraft();
        }
      });
      slot.querySelector("form").addEventListener("submit", (event) => {
        event.preventDefault();
        void commitDraft();
      });
      slot.querySelector(".cancel").addEventListener("click", () => {
        if (!saving) {
          draft = null;
          highlighted = null;
          renderEditor();
          drawHighlight();
          status();
        }
      });
      renderNotes();
      slot.scrollIntoView({ block: "nearest" });
      textarea.focus();
      syncState();
    }
    async function commitDraft() {
      if (!draft || saving) return;
      if (!draft.comment.trim()) {
        status("Write a comment before saving.", true);
        return;
      }
      saving = true;
      const save = $(".save");
      save.disabled = true;
      $(".cancel").disabled = true;
      const field = $("#comment");
      field.disabled = true;
      const saved = { ...draft, comment: draft.comment.trim(), updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
      try {
        await saveNote(store, saved);
        if (!alive) return;
        if (draft?.id === saved.id) draft = null;
        highlighted = null;
        renderEditor();
        await refresh();
        drawHighlight();
        status("Comment saved.");
      } catch (error) {
        if (!alive) return;
        showError(error);
        save.disabled = false;
        $(".cancel").disabled = false;
        field.disabled = false;
      } finally {
        saving = false;
      }
    }
    function ownEvent(event) {
      return event.composedPath().includes(host);
    }
    async function startCapture() {
      if (!alive || !runtime.capture || draft || captureBusy) return;
      if (native) {
        try {
          await integration.startCapture();
        } catch (error) {
          connectionError(error);
        }
        return;
      }
      setPicking(false);
      setSettings(false);
      status();
      captureBusy = true;
      captureAbort = new AbortController();
      renderEditor();
      const source = { pageUrl: pageUrl(), pageTitle: document.title };
      try {
        const screenshot = await selectScreenshot(app, mobile, runtime.capture, captureAbort.signal);
        if (screenshot && alive) {
          const time = (/* @__PURE__ */ new Date()).toISOString();
          draft = { id: crypto.randomUUID(), ...source, comment: "", screenshot, createdAt: time, updatedAt: time };
          composeOnPage = presentation === "remote" || composingFromMinimized;
        }
      } catch (error) {
        if (composingFromMinimized) {
          composingFromMinimized = false;
          setMinimized(false);
        }
        const message = `${error instanceof Error ? error.message : "Could not capture this page."} Open Briefmark from the toolbar and try again.`;
        status(message, true);
        if (presentation === "remote") integration?.captureError(message);
      } finally {
        captureBusy = false;
        captureAbort = null;
        if (alive) {
          renderEditor();
          if (!draft && $(".minimized-actions").hidden) $(".comment-options").focus();
        }
      }
    }
    function startGlobalComment() {
      if (!alive || draft || captureBusy || !url || connectionWarning) return;
      setCommentMenu(false);
      const time = (/* @__PURE__ */ new Date()).toISOString();
      draft = {
        id: crypto.randomUUID(),
        kind: "page",
        pageUrl: native ? url : pageUrl(),
        pageTitle: native ? title : document.title,
        comment: "",
        createdAt: time,
        updatedAt: time
      };
      composeOnPage = composingFromMinimized;
      setPicking(false);
      setSettings(false);
      status();
      renderEditor();
    }
    function eventElement(event) {
      return event.composedPath().find((node) => node instanceof Element);
    }
    function selectElement(element) {
      if (!element || !element.isConnected || element === document.documentElement) return;
      const time = (/* @__PURE__ */ new Date()).toISOString();
      draft = {
        id: crypto.randomUUID(),
        pageUrl: pageUrl(),
        pageTitle: document.title,
        comment: "",
        element: captureElement(element),
        createdAt: time,
        updatedAt: time
      };
      composeOnPage = presentation === "remote" || composingFromMinimized;
      setPicking(false);
      highlighted = element;
      drawHighlight();
      renderEditor();
    }
    document.addEventListener("pointermove", (event) => {
      if (!picking) return;
      if (event.pointerType === "touch") {
        if (touch?.id === event.pointerId && Math.hypot(event.clientX - touch.x, event.clientY - touch.y) > 12) touch.moved = true;
        event.stopImmediatePropagation();
        return;
      }
      highlighted = ownEvent(event) ? null : eventElement(event) || null;
      drawHighlight();
    }, { capture: true, signal: abort.signal });
    document.addEventListener("pointerdown", (event) => {
      if (ownEvent(event)) {
        suppressMouseUntil = 0;
        return;
      }
      if (!picking) return;
      event.stopImmediatePropagation();
      if (event.pointerType !== "touch") {
        event.preventDefault();
        return;
      }
      touchPointers.add(event.pointerId);
      if (touchPointers.size > 1) {
        if (touch) touch.moved = true;
        return;
      }
      touch = { id: event.pointerId, x: event.clientX, y: event.clientY, started: performance.now(), moved: false, element: eventElement(event) };
    }, { capture: true, signal: abort.signal });
    document.addEventListener("pointerup", (event) => {
      if (!picking || ownEvent(event)) return;
      event.stopImmediatePropagation();
      if (event.pointerType !== "touch") {
        event.preventDefault();
        return;
      }
      touchPointers.delete(event.pointerId);
      const candidate = touch;
      touch = null;
      suppressMouseUntil = performance.now() + 800;
      if (candidate?.id === event.pointerId && !candidate.moved && !touchPointers.size && performance.now() - candidate.started < 700 && Math.hypot(event.clientX - candidate.x, event.clientY - candidate.y) <= 12) {
        event.preventDefault();
        selectElement(candidate.element);
      }
    }, { capture: true, signal: abort.signal });
    document.addEventListener("pointercancel", (event) => {
      touchPointers.delete(event.pointerId);
      if (touch?.id === event.pointerId) touch = null;
      if (picking) suppressMouseUntil = performance.now() + 800;
    }, { capture: true, signal: abort.signal });
    for (const name of ["touchstart", "touchmove", "touchend"]) {
      document.addEventListener(name, (event) => {
        if ((picking || performance.now() < suppressMouseUntil) && !ownEvent(event)) event.stopImmediatePropagation();
      }, { capture: true, passive: true, signal: abort.signal });
    }
    for (const name of ["mousedown", "mouseup", "dblclick", "auxclick", "contextmenu"]) {
      document.addEventListener(name, (event) => {
        if (performance.now() >= suppressMouseUntil && (!picking || ownEvent(event))) return;
        event.preventDefault();
        event.stopImmediatePropagation();
      }, { capture: true, signal: abort.signal });
    }
    document.addEventListener("click", (event) => {
      const touchClick = event instanceof PointerEvent && event.pointerType === "touch";
      if (performance.now() < suppressMouseUntil && (!ownEvent(event) || touchClick)) {
        event.preventDefault();
        event.stopImmediatePropagation();
        return;
      }
      if (!picking || ownEvent(event)) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      selectElement(eventElement(event));
    }, { capture: true, signal: abort.signal });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && picking) {
        event.preventDefault();
        event.stopImmediatePropagation();
        cancelSelection();
      }
    }, { capture: true, signal: abort.signal });
    document.addEventListener("scroll", scheduleDraw, { capture: true, passive: true, signal: abort.signal });
    window.addEventListener("resize", updateViewport, { signal: abort.signal });
    window.visualViewport?.addEventListener("resize", updateViewport, { signal: abort.signal });
    window.visualViewport?.addEventListener("scroll", updateViewport, { signal: abort.signal });
    $(".select").addEventListener("click", () => {
      if (!draft) {
        status();
        setPicking(!picking);
        if (!native) $(".picker-bar button").focus();
      }
    });
    $(".capture").addEventListener("click", (event) => {
      if (event.isTrusted) {
        setCommentMenu(false);
        void startCapture();
      }
    });
    $(".global-comment").addEventListener("click", startGlobalComment);
    function cancelSelection() {
      setPicking(false);
      if (composingFromMinimized && !draft) {
        composingFromMinimized = false;
        setMinimized(true);
        $(".quick-select").focus({ preventScroll: true });
      } else $(".select").focus();
    }
    $(".picker-bar button").addEventListener("click", cancelSelection);
    $(".quick-select").addEventListener("click", () => {
      if (draft || captureBusy) return;
      composingFromMinimized = true;
      setSettings(false);
      status();
      setPicking(true);
      $(".picker-bar button").focus();
    });
    $(".quick-capture").addEventListener("click", (event) => {
      if (!event.isTrusted || draft || captureBusy || !runtime.capture) return;
      composingFromMinimized = true;
      void startCapture();
    });
    $(".quick-global-comment").addEventListener("click", () => {
      if (draft || captureBusy) return;
      composingFromMinimized = true;
      startGlobalComment();
    });
    $(".minimize").addEventListener("click", () => {
      void minimize();
    });
    $(".resume").addEventListener("click", () => {
      if (returnToDock && !mobile) void changeLayout("dock");
      else setMinimized(false);
    });
    $(".dock").addEventListener("click", () => {
      if (!mobile) void changeLayout(native ? "overlay" : "dock");
    });
    $(".settings-button").addEventListener("click", () => {
      setSettings(!settings);
      (settings ? $(".settings-back") : $(".settings-button")).focus();
    });
    $(".settings-back").addEventListener("click", () => {
      setSettings(false);
      $(".settings-button").focus();
    });
    for (const button of shadow.querySelectorAll(".theme-option")) {
      button.addEventListener("click", () => void saveTheme(button.dataset.theme));
    }
    $("#preamble").addEventListener("input", () => {
      const value = $("#preamble").value;
      preambleDraft = value === preamble ? null : value;
      preambleStatus(preambleDraft === null ? "" : "Unsaved changes.", { persistent: true });
      renderPreamble();
      syncState();
    });
    $(".save-preamble").addEventListener("click", () => void savePreamble());
    $(".reset-preamble").addEventListener("click", () => void savePreamble(true));
    scope.addEventListener("change", () => {
      status();
      renderNotes();
      syncState();
    });
    $(".copy").addEventListener("click", async () => {
      setCopyMenu(false);
      const copied = visibleNotes();
      if (!copied.length || !preambleReady || deleting) return;
      const prompt = buildPrompt(copied, preamble);
      try {
        await navigator.clipboard.writeText(prompt);
        if (!alive) return;
        copyFailed = false;
        copiedComments = copied;
        renderPrompt();
        status(`Copied ${copied.length} comment${copied.length === 1 ? "" : "s"}.${copied.some((note) => note.screenshot) ? " Download the images to attach them with the prompt." : ""}`);
      } catch {
        if (!alive) return;
        copyFailed = true;
        copiedComments = null;
        renderPrompt();
        status("Could not copy. Use Download Markdown + Images to export your comments.", true);
      }
    });
    const deleteDialog = $(".delete-dialog");
    function confirmDelete(event) {
      renderPrompt();
      const current = visibleNotes();
      if (!current.length || deleting) return;
      if (saving) {
        status("Finishing your save\u2026");
        return;
      }
      setCopyMenu(false, event.currentTarget === $(".delete-all"));
      showDeleteConfirmation({ kind: "all", notes: current });
    }
    function showDeleteConfirmation(request) {
      if (deleting || deleteDialog.open) return;
      pendingDeletion = request;
      const all = request.kind === "all";
      $("#delete-title").textContent = all ? "Delete All Comments?" : "Delete Comment?";
      $(".delete-dialog .button-label").textContent = all ? "Delete All Comments" : "Delete Comment";
      const description = request.kind === "single" ? "this comment" : request.notes.length === 1 ? "this comment" : `all ${request.notes.length} comments`;
      $("#delete-description").textContent = `This will delete ${description}. This cannot be undone.`;
      deleteDialog.returnValue = "";
      deleteDialog.showModal();
    }
    $(".delete-all").addEventListener("click", confirmDelete);
    $(".clear-copied").addEventListener("click", confirmDelete);
    deleteDialog.addEventListener("close", () => {
      const request = pendingDeletion;
      pendingDeletion = null;
      if (deleteDialog.returnValue !== "delete" || !request) return;
      if (request.kind === "all") void deleteComments(request.notes);
      else void deleteComment(request.note);
    });
    async function deleteComment(note) {
      if (deleting || !alive) return;
      deleting = true;
      renderPrompt();
      try {
        await removeNote(store, note.id);
        if (!alive) return;
        if (draft?.id === note.id) {
          draft = null;
          renderEditor();
        }
        await refresh();
        status("Comment deleted.");
      } catch (error) {
        if (alive) showError(error);
      } finally {
        deleting = false;
        if (alive) renderPrompt();
      }
    }
    async function deleteComments(confirmed) {
      if (deleting || !alive) return;
      deleting = true;
      renderPrompt();
      try {
        const stored = await readNotes(store);
        const current = scope.value === "all" ? stored : stored.filter((note) => samePage(note.pageUrl, url));
        if (!alive) return;
        if (commentSignature(confirmed) !== commentSignature(current)) {
          copiedComments = null;
          await refresh();
          status("Comments changed. Review them and try again.");
          return;
        }
        const results = await Promise.allSettled(confirmed.map((note) => removeNote(store, note.id)));
        if (!alive) return;
        copiedComments = null;
        if (draft && confirmed.some((note, index) => note.id === draft?.id && results[index].status === "fulfilled")) {
          draft = null;
          highlighted = null;
          renderEditor();
        }
        await refresh();
        const failed = results.filter((result) => result.status === "rejected").length;
        status(failed ? "Some comments could not be deleted. Try deleting the remaining comments again." : "Comments deleted.", !!failed);
      } catch (error) {
        if (alive) showError(error);
      } finally {
        deleting = false;
        if (alive) renderPrompt();
      }
    }
    $(".download").addEventListener("click", (event) => {
      if (!event.isTrusted || !preambleReady || !visibleNotes().length) return;
      try {
        downloadFile(new Blob([feedbackArchive(visibleNotes(), preamble)], { type: "application/zip" }), "briefmark-comments.zip");
        status("Download started. Extract the ZIP and attach its images with the prompt.");
      } catch {
        status("Could not download the files. Your comments are still saved.", true);
      }
    });
    const unsubscribe = store.subscribe((changes) => {
      if (changes[CONFIRM_DELETE_KEY]) {
        ++deletionPreferenceVersion;
        applyDeletionPreference(changes[CONFIRM_DELETE_KEY].newValue);
      }
      if (changes[THEME_KEY]) {
        ++themeVersion;
        applyTheme(changes[THEME_KEY].newValue);
      }
      if (changes[PREAMBLE_KEY]) {
        ++preambleVersion;
        applyPreamble(changes[PREAMBLE_KEY].newValue);
      }
      if (Object.keys(changes).some((key) => key.startsWith(STORAGE_PREFIX))) void refresh();
    });
    const navigation = window.setInterval(() => {
      if (native) return;
      if (title !== document.title) {
        title = document.title;
        syncState();
      }
      const current = pageUrl();
      if (current !== url) {
        captureAbort?.abort();
        url = current;
        locatedId = null;
        setPicking(false);
        if (draft) renderEditor();
        renderNotes();
        status(draft ? "Page changed. Your draft will be saved to the page where you started the comment." : "Showing comments for this page.");
        syncState();
      }
      scheduleDraw();
    }, 650);
    function close() {
      if (!alive) return true;
      if (saving || preambleSaving || themeSaving || deletionPreferenceSaving) {
        setMinimized(false);
        status("Finishing your save\u2026");
        return false;
      }
      if (draft?.comment.trim()) {
        setMinimized(false);
        status("Save or cancel your draft before closing.", true);
        setSettings(false);
        return false;
      }
      if (preambleDraft !== null) {
        setMinimized(false);
        setSettings(true);
        status("Save or restore your preamble before closing.", true);
        return false;
      }
      if (native) {
        void changeLayout("closed");
        return false;
      }
      dispose();
      return true;
    }
    function dispose() {
      if (!alive) return;
      alive = false;
      minimizeAnimation?.cancel();
      captureAbort?.abort();
      abort.abort();
      unsubscribe();
      clearInterval(navigation);
      cancelAnimationFrame(frame);
      noteViews.forEach((dispose2) => dispose2());
      disposeEditor?.();
      host.remove();
      runtime.onDispose?.();
    }
    function reveal() {
      if (!alive) return;
      minimizeAnimation?.cancel();
      setPicking(false);
      setMinimized(false);
      (settings ? $("#preamble") : draft ? $("#comment") ?? $(".edit-in-sidebar") : $(".select")).focus();
    }
    function present(mode, dock, state, notifySidebar = true) {
      if (!alive) return;
      if (mode !== "remote") captureAbort?.abort();
      canDock = dock && !mobile;
      presentation = mobile && mode === "remote" ? "overlay" : mode;
      returnToDock = presentation === "minimized";
      if (state) applyState(state);
      else if (presentation !== "remote" && composeOnPage) {
        composeOnPage = false;
        renderEditor();
      }
      if (presentation === "closed") close();
      else {
        setMinimized(presentation === "minimized");
        updateDockButton();
        if (notifySidebar) syncState();
      }
    }
    const controller = {
      ready: Promise.resolve(),
      close,
      dispose,
      reveal,
      viewState,
      applyState,
      present,
      startCapture,
      status,
      sidebarClosed() {
        if (!alive || presentation !== "remote") return;
        captureAbort?.abort();
        presentation = "minimized";
        returnToDock = true;
        composeOnPage = false;
        renderEditor();
        setPicking(false);
        setMinimized(true);
      },
      locate: locateNote,
      hierarchy: liveHierarchy,
      connectionFailed(error) {
        applyState({ url: "", draft: null, scope: "page", picking: false, settings: false });
        $(".select").disabled = true;
        $(".capture").disabled = true;
        connectionError(error);
      }
    };
    $(".close").addEventListener("click", close);
    try {
      const styles = runtime.attachStyles(shadow, abort.signal);
      if (styles) {
        host.style.setProperty("visibility", "hidden", "important");
        controller.ready = styles.then(() => {
          if (alive) host.style.removeProperty("visibility");
        }).catch((error) => {
          dispose();
          throw error;
        });
      }
      if (native) {
        $(".select").disabled = true;
        $(".capture").disabled = true;
        $(".comment-options").disabled = true;
        $(".global-comment").disabled = true;
        scope.disabled = true;
        setConnectionWarning(true);
      }
      integration?.connect(controller, abort.signal);
    } catch (error) {
      dispose();
      throw error;
    }
    updateDockButton();
    updateViewport();
    applyTheme("light");
    void loadTheme();
    void loadDeletionPreference();
    renderPreamble();
    void loadPreamble();
    void refresh();
    return controller;
  }

  // src/platform.ts
  function extensionApi() {
    const api2 = globalThis.browser ?? globalThis.chrome;
    if (!api2) throw new Error("Briefmark must run inside a browser extension.");
    return api2;
  }

  // src/docking.ts
  var api = () => extensionApi();
  function closeDock(windowId) {
    if (api().sidePanel?.close) return api().sidePanel.close({ windowId });
    if (api().sidebarAction?.close) return api().sidebarAction.close();
    return Promise.resolve();
  }

  // src/panel.css
  var panel_default = `.app {
  color-scheme: light;
  --text: #202b41;
  --muted: #647188;
  --surface: #ffffff;
  --card-header: #f7f9fc;
  --background: #fbfcfe;
  --border: #dce1ec;
  --hover: #eef1f7;
  --accent: #345ee9;
  --primary: #345ee9;
  --primary-hover: #274cd0;
  --accent-soft: #eef2ff;
  --accent-hover: #e2e9ff;
  --accent-border: #dce4ff;
  --badge: #edf0f6;
  --editor-border: #b5c5ff;
  --input: #fbfcff;
  --focus: #a8b9fc;
  --danger: #b1443f;
  --danger-bg: #fff2f0;
  --success: #557760;
  --local: #6aaf8f;
  --scrim: #11182766;
}
.app[data-theme="dark"] {
  color-scheme: dark;
  --text: #e6eaf3;
  --muted: #acb8ce;
  --surface: #1c2535;
  --card-header: #202c3e;
  --background: #151c29;
  --border: #354156;
  --hover: #2b374d;
  --accent: #a6baff;
  --primary: #4266d9;
  --primary-hover: #3658c5;
  --accent-soft: #243759;
  --accent-hover: #304975;
  --accent-border: #435d96;
  --badge: #2b374b;
  --editor-border: #627dbb;
  --input: #121a27;
  --focus: #b6c8ff;
  --danger: #ffaaa5;
  --danger-bg: #442c32;
  --success: #a6dbb9;
  --local: #8dceb0;
}
:host { all: initial !important; }
*, *::before, *::after { box-sizing: border-box; }
.app { font: 13px/1.5 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; color: var(--text); letter-spacing: normal; text-align: left; }
button, textarea, select { font: inherit; }
button { display: inline-flex; align-items: center; justify-content: center; gap: 6px; cursor: pointer; transition: background .12s, border-color .12s; }
button:disabled { opacity: .45; cursor: default; }
button:focus-visible, textarea:focus-visible, select:focus-visible { outline: 3px solid var(--focus); outline-offset: 3px; }
button { color: inherit; }
[hidden] { display: none !important; }
.panel { position: fixed; z-index: 2147483647; top: 16px; right: 16px; bottom: 16px; width: 366px; max-width: calc(100vw - 32px); display: flex; flex-direction: column; border: 1px solid var(--border); border-radius: 18px; background: var(--background); box-shadow: 0 16px 70px #1b2b4930, 0 2px 8px #18294d12; overflow: hidden; }
header { display: flex; align-items: center; gap: 10px; padding: 8px 20px; background: var(--surface); border-bottom: 1px solid var(--border); }
.panel > header { position: relative; z-index: 2; }
.logo { width: 30px; height: 30px; flex: 0 0 30px; display: grid; place-items: center; background: var(--primary); color: white; border-radius: 9px; font-size: 21px; font-weight: 700; }
.brand { flex-shrink: 0; font-size: 18px; font-weight: 750; letter-spacing: -.6px; line-height: 1.2; }
.icon-button { width: 32px; height: 32px; border: 0; background: transparent; padding: 8px; border-radius: 7px; font-size: 19px; line-height: 1.2; color: var(--muted); }
.icon-button:hover { background: var(--hover); color: var(--text); }
.settings-button { margin-left: auto; }
header > .icon-button { flex-shrink: 0; }
.intro { margin-bottom: 10px; }
.button-icon, [data-icon] { display: block; width: 16px; height: 16px; flex-shrink: 0; }
.button-label { min-width: 0; overflow-wrap: anywhere; }
.eyebrow { color: var(--muted); font-size: 10px; font-weight: 650; letter-spacing: 1.3px; text-transform: uppercase; }
h1 { font-size: 22px; line-height: 1.25; letter-spacing: -.8px; margin: 6px 0 8px; font-weight: 720; }
p { margin: 0; }
.muted { color: var(--muted); }
.primary { display: flex; justify-content: center; align-items: center; gap: 8px; background: var(--primary); color: white; border: 1px solid var(--primary); padding: 11px 14px; border-radius: 10px; font-weight: 620; }
.primary:hover:not(:disabled) { background: var(--primary-hover); border-color: var(--primary-hover); }
.secondary { padding: 9px 13px; background: var(--surface); border: 1px solid var(--border); border-radius: 9px; font-weight: 550; }
.secondary:hover:not(:disabled) { background: var(--hover); }
.select, .comment-options { background: var(--accent-soft); border-color: var(--accent-border); color: var(--accent); }
.select:hover:not(:disabled), .comment-options:hover:not(:disabled) { background: var(--accent-hover); border-color: var(--accent-border); }
.scope-row { display: flex; justify-content: space-between; align-items: center; gap: 8px; padding: 6px 20px; }
.scope-row select { color: var(--text); font-size: 12px; font-weight: 620; border: 0; background: transparent; max-width: 170px; padding: 4px 0; }
.count { border-radius: 20px; padding: 2px 8px; background: var(--badge); font-size: 11px; color: var(--muted); }
.content { overflow-y: auto; min-height: 0; flex: 1; padding: 0 16px 16px; overscroll-behavior: contain; }
.empty { text-align: center; padding: 24px 12px; color: var(--muted); }
.note, .editor { padding: 0; background: var(--surface); border: 1px solid var(--border); border-radius: 12px; margin: 0 0 10px; overflow: hidden; }
.note-top { display: flex; gap: 8px; align-items: center; min-width: 0; padding: 6px 10px; border-bottom: 1px solid var(--border); background: var(--card-header); }
.number { display: inline-flex; justify-content: center; align-items: center; border-radius: 6px; background: var(--accent-soft); color: var(--accent); font-size: 11px; font-weight: 700; width: 24px; height: 24px; flex-shrink: 0; }
.note-title { flex: 1; min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; font-size: 14px; font-weight: 650; }
.note-actions { display: flex; gap: 2px; align-items: center; margin-left: auto; flex-shrink: 0; }
.note .note-top { position: relative; min-height: 40px; }
.note .note-actions { position: absolute; right: 6px; top: 50%; transform: translateY(-50%); padding-left: 4px; border-radius: 6px; background: var(--card-header); box-shadow: -12px 0 12px var(--card-header); opacity: 0; }
.note:hover .note-actions, .note:focus-within .note-actions { opacity: 1; }
@media(hover:none), (pointer:coarse) { .note .note-actions { opacity: 1; } .note .note-top { min-height: 56px; } }
.note-actions .text-button { position: relative; width: 28px; height: 28px; min-height: 28px; padding: 6px; }
.note-actions .text-button:hover::after, .note-actions .text-button:focus-visible::after { content: attr(aria-label); position: absolute; top: calc(100% + 4px); left: 50%; transform: translateX(-50%); padding: 3px 7px; border-radius: 4px; background: var(--text); color: var(--surface); font-size: 11px; line-height: 18px; white-space: nowrap; pointer-events: none; z-index: 1; }
.note-actions .text-button.delete::after { right: 0; left: auto; transform: none; }
.editing-badge { display: inline-flex; align-items: center; gap: 4px; padding: 3px 6px; border-radius: 5px; background: var(--accent-soft); color: var(--accent); font-size: 11px; font-weight: 550; white-space: nowrap; }
.editing-badge [data-icon], .editing-badge .button-icon { width: 12px; height: 12px; }
.note-metadata { padding: 6px 12px; border-bottom: 1px solid var(--border); }
.note-kind { display: flex; align-items: center; gap: 6px; min-height: 20px; }
.note-kind > [data-icon], .note-kind > [data-icon] .button-icon { width: 13px; height: 13px; color: var(--muted); }
.tag { font-size: 11px; color: var(--muted); }
.hierarchy { display: flex; align-items: flex-start; gap: 6px; margin-top: 2px; }
.selector { flex: 1; min-width: 0; font: 11px/24px ui-monospace, SFMono-Regular, Consolas, monospace; color: var(--muted); overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.hierarchy.expanded .selector { white-space: normal; overflow-wrap: anywhere; line-height: 20px; }
.text-button { background: none; border: 0; font-size: 11px; color: var(--muted); border-radius: 5px; padding: 3px 5px; }
.text-button:hover { color: var(--accent); background: var(--accent-soft); }
.hierarchy .hierarchy-toggle, .note-kind .parent { flex: 0 0 24px; width: 24px; height: 24px; min-height: 24px; padding: 4px; }
.note-kind .parent { margin-left: auto; }
.delete:hover { color: var(--danger); background: var(--danger-bg); }
.page-label { margin-top: 4px; color: var(--muted); font-size: 10px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.comment-body { padding: 8px; }
textarea { display: block; resize: vertical; width: 100%; min-height: 108px; background: var(--input); color: var(--text); border: 1px solid var(--border); border-radius: 8px; padding: 11px; font-size: 13px; line-height: 1.6; }
textarea::placeholder { color: var(--muted); }
.note .comment, .editor .comment { margin: 0; min-height: 80px; height: 80px; padding: 8px; font-size: 13px; line-height: 1.5; }
.editor .comment { border-color: var(--editor-border); }
.editor .comment:focus { outline: 2px solid var(--focus); outline-offset: 1px; }
.editor-actions { display: flex; align-items: center; justify-content: flex-end; gap: 6px; margin-top: 8px; }
.editor-actions button { flex-shrink: 0; gap: 5px; min-height: 28px; font-size: 11px; padding: 3px 8px; border-radius: 6px; }
.editor-actions [data-icon], .editor-actions .button-icon { width: 13px; height: 13px; }
.shortcut { display: block; font-size: 10px; line-height: 1.35; color: var(--muted); margin-right: auto; white-space: nowrap; }
footer { padding: 16px 20px 17px; border-top: 1px solid var(--border); background: var(--surface); }
.support-link { display: flex; align-items: center; gap: 6px; width: fit-content; max-width: 100%; margin-inline: auto; color: var(--accent); font-size: 12px; text-underline-offset: 3px; }
.support-icon { flex-shrink: 0; filter: grayscale(1); }
.support-link:hover { text-decoration-thickness: 2px; }
.support-link:focus-visible { outline: 3px solid var(--accent); outline-offset: 3px; }
.danger-button { min-height: 40px; padding: 8px 12px; border: 1px solid #b42318; border-radius: 9px; background: #b42318; color: #fff; font-weight: 600; }
.danger-button:hover:not(:disabled):not([aria-disabled="true"]) { background: #912018; border-color: #912018; }
.clear-copied { flex-shrink: 0; margin: 0 20px 12px; }
.delete-dialog { width: 340px; max-width: calc(100vw - 32px); margin: auto; padding: 24px; color: var(--text); background: var(--surface); border: 1px solid var(--border); border-radius: 16px; box-shadow: 0 16px 70px #11182740; }
.delete-dialog::backdrop { background: #11182766; }
.delete-dialog h2 { margin: 0 0 10px; font-size: 18px; line-height: 1.3; }
.delete-dialog p { color: var(--muted); }
.dialog-actions { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 8px; margin-top: 24px; }
.download { display: flex; width: 100%; margin-top: 8px; color: var(--accent); }
.screenshot-preview { display: block; height: 130px; width: 100%; margin-top: 6px; border-radius: 6px; overflow: hidden; background: var(--badge); }
.capture-hidden { visibility: hidden !important; }
.capturing > :not(.capture-layer) { visibility: hidden !important; }
.capture-layer { position: fixed; z-index: 2147483647; overflow: hidden; touch-action: none; user-select: none; cursor: crosshair; background: #202b41; }
.capture-photo { position: absolute; inset: 0; display: block; pointer-events: none; }
.capture-shade { position: absolute; inset: 0; background: #11182770; pointer-events: none; }
.capture-region { position: absolute; border: 2px solid #4673ff; box-shadow: 0 0 0 9999px #11182788; cursor: move; touch-action: none; }
.capture-handle { position: absolute; width: 44px; height: 44px; padding: 0; border: 0; background: transparent; touch-action: none; }
.capture-handle::after { content: ''; position: absolute; inset: 14px; border-radius: 50%; background: white; border: 2px solid #345ee9; box-shadow: 0 1px 4px #11182770; }
.capture-handle.nw { left: -23px; top: -23px; cursor: nwse-resize; }
.capture-handle.ne { right: -23px; top: -23px; cursor: nesw-resize; }
.capture-handle.sw { left: -23px; bottom: -23px; cursor: nesw-resize; }
.capture-handle.se { right: -23px; bottom: -23px; cursor: nwse-resize; }
.capture-toolbar { position: absolute; bottom: max(12px, env(safe-area-inset-bottom)); left: 50%; transform: translateX(-50%); padding: 10px 12px; width: max-content; max-width: calc(100% - 24px); border: 1px solid var(--border); border-radius: 12px; background: var(--surface); color: var(--text); box-shadow: 0 6px 28px #11182755; cursor: default; text-align: center; }
.capture-toolbar p { margin: 0 0 8px; font-size: 13px; }
.capture-toolbar > div { display: flex; gap: 8px; justify-content: center; }
.capture-toolbar button { min-height: 44px; }
.split-button { position: relative; display: flex; }
.split-main { flex: 1; min-width: 0; min-height: 44px; border-radius: 10px 0 0 10px; }
.split-options { flex: 0 0 44px; padding: 0; border-radius: 0 10px 10px 0; }
.copy-options, .copy-options:hover:not(:disabled) { border-left-color: #ffffff55; }
.copy:focus-visible, .copy-options:focus-visible { outline-offset: -4px; outline-color: white; }
.split-menu { position: absolute; z-index: 1; right: 0; bottom: calc(100% + 8px); min-width: min(210px, 100%); max-width: 100%; padding: 4px; border: 1px solid var(--border); border-radius: 10px; background: var(--surface); box-shadow: 0 6px 24px #192b4926; }
.copy-menu { width: 100%; padding: 0; border: 0; }
.copy-menu .delete-all { border-radius: inherit; }
.comment-menu { min-width: min(230px, 100%); }
.menu-action { padding: 8px 12px; border: 0; background: transparent; color: var(--text); font-weight: 550; }
.menu-action:hover:not(:disabled), .menu-action:focus-visible { background: var(--hover); }
.menu-action:focus-visible { outline-offset: -3px; }
.select:focus-visible, .comment-options:focus-visible { outline-offset: -4px; }
.comment-options { border-left: 0; }
.delete-all, .menu-action { justify-content: flex-start; width: 100%; min-height: 44px; border-radius: 6px; }
.delete-all[aria-disabled="true"] { opacity: .45; cursor: default; }
.status { margin: 0; min-height: 0; font-size: 11px; color: var(--success); padding: 0 20px; }
.status:not(:empty) { padding-top: 9px; padding-bottom: 9px; }
.status.error { color: var(--danger); background: var(--danger-bg); }
.connection-shade { position: absolute; inset: 0; z-index: 1; background: var(--scrim); pointer-events: none; }
.connection-prompt { position: absolute; top: 50%; transform: translateY(-50%); left: 16px; right: 16px; z-index: 2; display: flex; flex-direction: column; align-items: flex-start; gap: 12px; max-height: calc(100% - 220px); padding: 20px; overflow-y: auto; border: 1px solid var(--accent-border); border-radius: 14px; background: var(--accent-soft); color: var(--muted); box-shadow: 0 8px 28px #1b2b4918; font-size: 12px; line-height: 1.6; }
.connection-prompt .connection-instruction { color: var(--text); font-size: 15px; font-weight: 550; line-height: 1.5; }
.connection-prompt > [data-icon] { display: grid; place-items: center; width: 32px; height: 32px; border-radius: 9px; background: var(--surface); color: var(--accent); }
.connection-prompt .button-icon { width: 22px; height: 22px; }
.connection-prompt:focus { outline: none; }
.picker-bar { position: fixed; z-index: 2147483647; bottom: 24px; left: 50%; transform: translateX(-50%); padding: 12px 14px 12px 20px; border: 1px solid var(--accent-border); border-radius: 14px; box-shadow: 0 7px 35px #192b4928; display: flex; align-items: center; gap: 18px; color: var(--text); background: var(--surface); white-space: nowrap; max-width: calc(100vw - 20px); }
.picker-bar strong { color: var(--accent); font-size: 13px; }
.picker-bar button { font-size: 11px; background: var(--hover); border: 0; border-radius: 7px; padding: 7px 10px; color: var(--muted); }
.outline { position: fixed; pointer-events: none; border: 2px solid #456cf0; background: #456cf013; border-radius: 3px; z-index: 2147483645; }
.editor-shade { position: fixed; inset: 0; overflow: hidden; pointer-events: none; z-index: 2147483645; }
.editor-shade:not(.has-target) { background: var(--scrim); }
.editor-cutout { position: absolute; border: 2px solid var(--accent); border-radius: 3px; box-shadow: 0 0 0 100vmax var(--scrim); }
.hover-label { position: fixed; padding: 4px 7px; background: var(--primary); border-radius: 5px; color: white; font: 11px/1.3 ui-monospace, monospace; pointer-events: none; z-index: 2147483646; }
.saved-outline { position: fixed; pointer-events: none; border: 2px solid var(--muted); opacity: .55; border-radius: 3px; z-index: 2147483643; }
.saved-outline.active { border-color: var(--primary); background: #456cf013; opacity: 1; }
.pin { position: fixed; z-index: 2147483644; width: 24px; height: 24px; border: 2px solid var(--surface); border-radius: 50% 50% 50% 3px; background: var(--muted); color: white; box-shadow: 0 2px 7px #2341a23b; font: 700 10px/20px system-ui; padding: 0; text-align: center; }
.pin.active { background: var(--primary); }
.pin:disabled { pointer-events: none; }
.minimized-actions { position: fixed; right: calc(14px + env(safe-area-inset-right, 0px)); bottom: calc(14px + env(safe-area-inset-bottom, 0px)); z-index: 2147483647; display: flex; align-items: center; gap: 8px; max-width: calc(100vw - 28px - env(safe-area-inset-left, 0px) - env(safe-area-inset-right, 0px)); transform-origin: bottom right; animation: resume-in .32s cubic-bezier(.16, 1, .3, 1); }
.resume, .quick-action { min-height: 44px; border: 1px solid var(--accent-border); background: var(--surface); color: var(--accent); box-shadow: 0 4px 24px #192b4930; }
.resume { min-width: 0; border-radius: 24px; padding: 10px 12px; font-weight: 650; }
.resume .button-label { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.quick-action { width: 44px; height: 44px; flex: 0 0 44px; border-radius: 50%; padding: 0; }
.resume:hover, .quick-action:hover:not(:disabled) { background: var(--accent-soft); }
@keyframes resume-in { from { opacity: 0; transform: translateY(-16px) scale(1.2); } to { opacity: 1; transform: translateY(0) scale(1); } }
@media(max-width:600px), (pointer:coarse) {
  .panel { top: auto; left: 8px; right: 8px; bottom: calc(8px + var(--viewport-bottom, 0px) + env(safe-area-inset-bottom, 0px)); width: auto; max-width: none; height: min(650px, calc(var(--viewport-height, 100dvh) * .78)); max-height: calc(var(--viewport-height, 100dvh) - 16px - env(safe-area-inset-bottom, 0px)); border-radius: 20px 20px 12px 12px; }
  header { padding: 4px 12px; gap: 8px; flex-shrink: 0; }
  .brand { min-width: 0; font-size: 17px; }
  button, .scope-row select { min-height: 44px; }
  .icon-button { min-width: 44px; }
  .shortcut { display: none; }
  .select { margin-top: 0; }
  .scope-row { padding: 4px 16px; }
  .content { padding: 0 10px 10px; }
  .empty { padding: 15px 10px; }
  .note-actions { gap: 2px; }
  .text-button { font-size: 13px; padding: 8px; }
  .editor { padding: 0; }
  textarea, .note .comment, .editor .comment { font-size: 16px; min-height: 100px; }
  .editor-actions { position: sticky; bottom: -1px; padding: 4px 0 0; margin-top: 4px; background: var(--surface); }
  .editor-actions button { flex: 1; font-size: 14px; }
  .app.editing .panel { height: min(650px, calc(var(--viewport-height, 100dvh) - 16px)); }
  .app.editing .intro, .app.editing .scope-row, .app.editing footer { display: none; }
  .app.editing footer:has(.support-link:not([hidden])) { display: block; }
  footer { padding: 10px 14px; flex-shrink: 0; }
  .picker-bar { gap: 10px; padding: 6px 10px; bottom: calc(12px + env(safe-area-inset-bottom, 0px)); }
  .picker-bar strong { font-size: 12px; white-space: normal; }
  .picker-bar button { font-size: 13px; padding: 8px 12px; }
  .pin { width: 44px; height: 44px; font-size: 13px; line-height: 40px; }
}
@media(max-height:500px) {
  .select { margin-top: 0; }
  header { padding-top: 4px; padding-bottom: 4px; }
  footer { padding-top: 6px; padding-bottom: 6px; }
}
@media(prefers-reduced-motion:reduce) { * { animation: none !important; transition: none !important; scroll-behavior: auto !important; } }
/* Browser sidebars own the viewport; never apply the mobile bottom sheet here. */
.native .panel, .native.editing .panel { inset: 0; width: 100%; max-width: none; height: 100dvh; max-height: none; border: 0; border-radius: 0; box-shadow: none; }
.native.editing .intro { display: flex; }
.native.editing .scope-row, .native.editing footer { display: block; }
.native.editing .scope-row { display: flex; }
.native header { padding: 6px 12px; gap: 6px; }
.native .picker-bar { display: none; }
.native .note .comment, .native .editor .comment { min-height: 80px; height: 80px; font-size: 13px; }
.native .editor-actions { position: static; padding: 0; margin-top: 8px; }
.native .editor-actions button { flex: 0 0 auto; font-size: 11px; }
.native .shortcut { display: block; }
@media(max-width:300px) { .native .shortcut { font-size: 9px; } .native .editor-actions { gap: 4px; } .native .editor-actions button { font-size: 10px; padding-inline: 5px; } }
@media(pointer:coarse) { .note-actions .text-button, .hierarchy .hierarchy-toggle, .note-kind .parent { min-width: 44px; min-height: 44px; } .editor-actions button { min-height: 44px; } }
.dock { display: inline-flex; align-items: center; justify-content: center; margin-left: 0; }
.dock:not([hidden]) + .minimize { margin-left: 0; }
.native .icon-button { min-width: 32px; min-height: 32px; padding: 8px; }
.draft-on-page { margin-bottom: 14px; padding: 16px; border: 1px solid var(--editor-border); border-radius: 12px; background: var(--surface); color: var(--muted); }
.draft-on-page button { margin-top: 12px; color: var(--accent); }
/* Keep the new-comment editor in the document that owns keyboard focus. */
.app.composing .panel { top: auto; bottom: calc(16px + var(--viewport-bottom, 0px) + env(safe-area-inset-bottom, 0px)); height: auto; max-height: calc(var(--viewport-height, 100dvh) - 32px); width: 340px; }
.composing header, .composing .intro, .composing .scope-row, .composing footer, .composing .notes { display: none; }
.composing .content { padding: 0; }
.composing .editor { margin: 0; border: 0; }
@media(max-width:280px) { .native .logo { display: none; } .native header { padding: 4px 8px; gap: 4px; } .native .brand { font-size: 16px; } .native .icon-button { width: 28px; height: 28px; min-width: 28px; min-height: 28px; padding: 6px; } }

.settings { flex: 1; min-height: 0; overflow-y: auto; padding: 8px 20px 18px; }
.settings-heading { display: flex; align-items: center; gap: 16px; margin-bottom: 12px; }
.settings h1 { margin: 0; }
.settings h2 { margin: 0 0 10px; font-size: 13px; font-weight: 650; }
.settings p { margin-top: 14px; color: var(--muted); font-size: 12px; }
.settings-back { border: 0; background: none; color: var(--accent); padding: 0; font-size: 12px; }
.native .settings-back { min-height: 28px; }
.theme-options { display: flex; gap: 4px; padding: 4px; background: var(--badge); border: 1px solid var(--border); border-radius: 12px; }
.theme-option { flex: 1; min-height: 44px; border: 1px solid transparent; border-radius: 8px; background: transparent; color: var(--muted); font-weight: 600; -webkit-tap-highlight-color: transparent; }
.theme-option[aria-pressed="true"] { color: var(--accent); background: var(--surface); border-color: var(--accent-border); }
.theme-option:hover:not(:disabled) { background: var(--hover); }
.settings-status:empty, .preamble-status:empty { display: none; }
.preferences { margin-top: 24px; }
.preference-row { display: flex; align-items: center; gap: 12px; }
.preference-row > span { flex: 1; font-size: 12px; }
.confirm-delete-toggle { flex-shrink: 0; min-height: 44px; padding: 4px; border: 0; border-radius: 8px; background: transparent; color: var(--muted); }
.confirm-delete-toggle[aria-checked="true"] { color: var(--accent); }
.switch-track { display: block; position: relative; width: 32px; height: 20px; border-radius: 12px; background: var(--muted); }
.switch-track::after { content: ''; position: absolute; top: 3px; left: 3px; width: 14px; height: 14px; border-radius: 50%; background: white; }
.confirm-delete-toggle[aria-checked="true"] .switch-track { background: var(--primary); }
.confirm-delete-toggle[aria-checked="true"] .switch-track::after { left: 15px; }
.switch-value { min-width: 22px; font-size: 11px; }
.preferences-status:empty { display: none; }
.preamble-settings { margin-top: 24px; }
.preamble-settings label { display: block; margin-bottom: 4px; font-size: 13px; font-weight: 650; }
.preamble-settings textarea { min-height: 160px; max-height: 320px; font-size: 13px; line-height: 1.6; resize: vertical; }
.preamble-actions { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 14px; }
.preamble-actions button { flex: 1 1 120px; padding: 9px 10px; }
@media(max-width:600px), (pointer:coarse) { .preamble-settings textarea { font-size: 16px; } }
@media(max-width:360px) { .app:not(.native) .logo { display: none; } .settings { padding: 8px 14px 14px; } }

.preamble-settings #preamble-help { margin: 0 0 12px; }
`;

  // src/extension-runtime.ts
  function extensionStore() {
    const api2 = extensionApi();
    return {
      read: async (key) => (await api2.storage.local.get(key))[key],
      readAll: () => api2.storage.local.get(null),
      write: (key, value) => api2.storage.local.set({ [key]: value }),
      remove: (key) => api2.storage.local.remove(key),
      subscribe(listener) {
        const changed = (changes, area) => {
          if (area === "local") listener(changes);
        };
        api2.storage.onChanged.addListener(changed);
        return () => api2.storage.onChanged.removeListener(changed);
      }
    };
  }
  function extensionRuntime(onDispose) {
    const api2 = extensionApi();
    const native = location.href === api2.runtime.getURL("sidebar.html");
    let targetTab;
    let windowId;
    let connectionVersion = 0;
    async function pageCommand(type, extra = {}) {
      if (!targetTab) throw new Error("Click Briefmark in the toolbar to connect this page.");
      return api2.tabs.sendMessage(targetTab, { type, ...extra });
    }
    const presentation = {
      native,
      dockViaToolbar: "sidebar_action" in api2.runtime.getManifest(),
      async sync(state, remote) {
        if (native) {
          if (state.url) await pageCommand("BRIEFMARK_SET_VIEW", { state });
        } else if (remote) await api2.runtime.sendMessage({ type: "BRIEFMARK_VIEW_CHANGED", state }).catch(() => {
        });
      },
      async changeLayout(mode, state, mobile) {
        const request = api2.runtime.sendMessage({ type: "BRIEFMARK_LAYOUT", mode, state: state.url ? state : void 0, tabId: targetTab, windowId, mobile });
        if (native && mode !== "dock") void closeDock(windowId || 0).catch(() => {
        });
        const result = await request;
        if (!result?.ok) throw new Error(result?.error || "Could not change layout.");
      },
      locate: (note, parent) => pageCommand(parent ? "BRIEFMARK_PARENT" : "BRIEFMARK_LOCATE", { note }),
      hierarchy: (note) => pageCommand("BRIEFMARK_HIERARCHY", { note }),
      startCapture: () => pageCommand("BRIEFMARK_START_CAPTURE"),
      captureError: (error) => {
        void api2.runtime.sendMessage({ type: "BRIEFMARK_CAPTURE_ERROR", error }).catch(() => {
        });
      },
      connect(controller, signal) {
        const messageListener = (message, sender, respond) => {
          if (signal.aborted || sender.id !== api2.runtime.id) return;
          if (native) {
            if (message?.type === "BRIEFMARK_VIEW_CHANGED" && sender.tab?.id === targetTab) controller.applyState(message.state);
            if (message?.type === "BRIEFMARK_CAPTURE_ERROR" && sender.tab?.id === targetTab) controller.status(message.error, true);
            return;
          }
          if (sender.url && !sender.url.startsWith(api2.runtime.getURL(""))) return;
          if (message?.type === "BRIEFMARK_PRESENT") {
            controller.present(message.mode, !!message.canDock, message.state, message.notifySidebar);
            respond(true);
          } else if (message?.type === "BRIEFMARK_START_CAPTURE") {
            void controller.startCapture();
            respond(true);
          } else if (message?.type === "BRIEFMARK_GET_VIEW") respond(controller.viewState());
          else if (message?.type === "BRIEFMARK_SET_VIEW") {
            controller.applyState(message.state);
            respond(true);
          } else if (message?.type === "BRIEFMARK_SIDEBAR_CLOSED") {
            controller.sidebarClosed();
            respond(true);
          } else if (message?.type === "BRIEFMARK_HIERARCHY") respond(controller.hierarchy(message.note));
          else if (message?.type === "BRIEFMARK_LOCATE" || message?.type === "BRIEFMARK_PARENT") {
            respond(controller.locate(message.note, message.type === "BRIEFMARK_PARENT"));
          }
        };
        api2.runtime.onMessage.addListener(messageListener);
        signal.addEventListener("abort", () => api2.runtime.onMessage.removeListener(messageListener), { once: true });
        if (!native) return;
        const port = api2.runtime.connect({ name: "briefmark-sidebar" });
        port.onMessage.addListener((result) => {
          if (signal.aborted || result.version !== connectionVersion) return;
          if (!result.ok) {
            controller.connectionFailed(result.error);
            return;
          }
          controller.applyState(result.value);
        });
        async function connect() {
          const version = ++connectionVersion;
          try {
            const tabs = await api2.tabs.query({ active: true, windowId });
            if (signal.aborted || version !== connectionVersion) return;
            const tab = tabs[0];
            if (!tab?.id) throw new Error("No active tab");
            targetTab = tab.id;
            port.postMessage({ tabId: targetTab, version });
          } catch (error) {
            if (!signal.aborted && version === connectionVersion) controller.connectionFailed(error);
          }
        }
        const activated = (info) => {
          if (info.windowId === windowId) void connect();
        };
        const updated = (tabId, change) => {
          if (tabId === targetTab && change.status === "complete") void connect();
        };
        api2.tabs.onActivated.addListener(activated);
        api2.tabs.onUpdated.addListener(updated);
        signal.addEventListener("abort", () => {
          ++connectionVersion;
          api2.tabs.onActivated.removeListener(activated);
          api2.tabs.onUpdated.removeListener(updated);
          port.disconnect();
        }, { once: true });
        void api2.windows.getCurrent().then((window2) => {
          if (!signal.aborted) {
            windowId = window2.id;
            void connect();
          }
        }).catch((error) => {
          if (!signal.aborted) controller.connectionFailed(error);
        });
      }
    };
    return {
      store: extensionStore(),
      presentation,
      onDispose,
      settingsLabel: "Extension settings",
      storageError: "Could not save or load comments. Keep your draft and try again. If the extension was reloaded, refresh this page.",
      attachStyles(shadow) {
        const sheet = document.createElement("style");
        sheet.textContent = panel_default;
        shadow.prepend(sheet);
      },
      async capture() {
        const result = await api2.runtime.sendMessage({ type: "BRIEFMARK_CAPTURE_VISIBLE" });
        if (!result?.ok) throw new Error(result?.error || "Could not capture this page.");
        return result.value;
      }
    };
  }

  // src/extension-content.ts
  var global = globalThis;
  if (!global.__pagebrief) {
    global.__pagebrief = mount(extensionRuntime(() => {
      delete global.__pagebrief;
    }));
  }
})();
