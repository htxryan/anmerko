// src/platform.ts
function extensionApi() {
  const api3 = globalThis.browser ?? globalThis.chrome;
  if (!api3) throw new Error("Briefmark must run inside a browser extension.");
  return api3;
}

// src/activate.ts
async function activateTab(tabId, mode = "overlay", state, canDock = false, notifySidebar = true) {
  await extensionApi().scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  await extensionApi().tabs.sendMessage(tabId, { type: "BRIEFMARK_PRESENT", mode, state, canDock, notifySidebar });
}

// src/docking.ts
var api = () => extensionApi();
var supportsDocking = () => !/Android|iPhone|iPad|Mobile/i.test(navigator.userAgent) && !!(api().sidePanel?.open || api().sidebarAction?.open);
function openDock(windowId) {
  if (api().sidePanel?.open) return api().sidePanel.open({ windowId });
  if (api().sidebarAction?.open) return api().sidebarAction.open();
  return Promise.reject(new Error("Docking is unavailable on this browser."));
}

// src/sidebar-connection.ts
function bindSidebarConnection(port, operations, owners) {
  let current;
  let disconnected = false;
  const owns = (request) => owners.get(request.tabId) === request;
  const active = (request) => !disconnected && current === request && owns(request);
  const restore = async (request) => {
    if (!owners.has(request.tabId)) await operations.closed(request.tabId).catch(() => {
    });
  };
  const release = (request) => {
    if (owns(request)) owners.delete(request.tabId);
    void restore(request);
  };
  const respond = (request, result) => {
    if (!active(request)) return;
    try {
      port.postMessage({ version: request.version, ...result });
    } catch {
    }
  };
  port.onMessage.addListener((message) => {
    if (disconnected || !Number.isInteger(message.tabId) || !Number.isInteger(message.version)) return;
    if (current && current.tabId !== message.tabId) release(current);
    const request = { tabId: message.tabId, version: message.version };
    current = request;
    owners.set(request.tabId, request);
    void (async () => {
      try {
        await operations.activate(request.tabId);
        if (!active(request)) {
          await restore(request);
          return;
        }
        const value = await operations.view(request.tabId);
        respond(request, { ok: true, value });
      } catch (error) {
        respond(request, { ok: false, error: String(error) });
      }
    })();
  });
  port.onDisconnect.addListener(() => {
    disconnected = true;
    if (current) release(current);
  });
}

// src/background.ts
var api2 = extensionApi();
var sidebarUrl = api2.runtime.getURL("sidebar.html");
var sidebarOwners = /* @__PURE__ */ new Map();
var capturePending = false;
var lastCapture = 0;
api2.action.onClicked.addListener((tab) => {
  if (!tab.id) return;
  if (!tab.url || !/^https?:/.test(tab.url)) {
    void api2.tabs.create({ url: api2.runtime.getURL("unavailable.html") });
    return;
  }
  const opening = supportsDocking() ? openDock(tab.windowId).then(() => {
    if ("sidebar_action" in api2.runtime.getManifest()) return;
    return activateTab(tab.id, "remote", void 0, true);
  }) : activateTab(tab.id);
  void opening.catch(() => activateTab(tab.id)).catch(() => api2.tabs.create({ url: api2.runtime.getURL("unavailable.html") }));
});
api2.runtime.onMessage.addListener((message, sender, respond) => {
  if (sender.id !== api2.runtime.id) return;
  const fromSidebar = sender.url === sidebarUrl;
  const fromPage = !!sender.tab?.id && /^https?:/.test(sender.url || "");
  const reply = (operation) => {
    operation.then((value) => respond({ ok: true, value }), (error) => respond({ ok: false, error: String(error.message || error) }));
    return true;
  };
  if (message?.type === "BRIEFMARK_CAPTURE_VISIBLE" && fromPage && sender.frameId === 0) {
    return reply((async () => {
      if (capturePending || Date.now() - lastCapture < 600) throw new Error("Wait a moment before taking another screenshot.");
      capturePending = true;
      lastCapture = Date.now();
      const tabId = sender.tab.id;
      const windowId = sender.tab.windowId;
      let changed = false;
      const activated = (info) => {
        if (info.windowId === windowId && info.tabId !== tabId) changed = true;
      };
      const updated = (id, info) => {
        if (id === tabId && (info.status === "loading" || info.url)) changed = true;
      };
      api2.tabs.onActivated.addListener(activated);
      api2.tabs.onUpdated.addListener(updated);
      try {
        const before = await api2.tabs.get(tabId);
        if (!before.active || before.url !== sender.url || !/^https?:/.test(before.url || "")) throw new Error("Return to the original page and try again.");
        const dataUrl = await api2.tabs.captureVisibleTab(windowId, { format: "png" });
        const after = await api2.tabs.get(tabId);
        if (changed || !after.active || after.url !== before.url) throw new Error("The page changed during capture. Try again.");
        return dataUrl;
      } finally {
        api2.tabs.onActivated.removeListener(activated);
        api2.tabs.onUpdated.removeListener(updated);
        capturePending = false;
      }
    })());
  }
  if (message?.type === "OPEN_PAGEBRIEF" && sender.url === api2.runtime.getURL("popup.html") && Number.isInteger(message.tabId)) {
    return reply(activateTab(message.tabId, "overlay", void 0, supportsDocking()));
  }
  if (message?.type === "BRIEFMARK_LAYOUT" && (fromSidebar || fromPage)) {
    const tabId = fromSidebar ? message.tabId : sender.tab.id;
    const windowId = fromSidebar ? message.windowId : sender.tab.windowId;
    if (!Number.isInteger(tabId) || !Number.isInteger(windowId) || !["dock", "overlay", "minimized", "closed"].includes(message.mode)) return;
    if (message.mode === "dock" && (message.mobile || !supportsDocking())) {
      respond({ ok: false, error: "Docking is unavailable on mobile." });
      return;
    }
    const opening = message.mode === "dock" ? openDock(windowId) : Promise.resolve();
    return reply((async () => {
      await opening;
      try {
        await activateTab(tabId, message.mode === "dock" ? "remote" : message.mode, message.state, supportsDocking());
      } catch (error) {
        if (!fromSidebar || !["closed", "minimized"].includes(message.mode)) throw error;
      }
    })());
  }
});
api2.runtime.onConnect.addListener((port) => {
  if (port.name !== "briefmark-sidebar" || port.sender?.url !== sidebarUrl) return;
  bindSidebarConnection(port, {
    // The port sends the startup snapshot. Broadcasting here would apply it
    // twice and could replace the editor during the user's first click.
    activate: (tabId) => activateTab(tabId, "remote", void 0, true, false),
    view: (tabId) => api2.tabs.sendMessage(tabId, { type: "BRIEFMARK_GET_VIEW" }),
    closed: (tabId) => api2.tabs.sendMessage(tabId, { type: "BRIEFMARK_SIDEBAR_CLOSED" })
  }, sidebarOwners);
});
export {
  activateTab
};
