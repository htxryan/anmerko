# Briefmark 0.5.3 — Firefox review source

Requires Node.js 24 and npm. Run:

    npm ci
    npm run build:firefox

The resulting dist-firefox directory is the submitted extension. esbuild bundles TypeScript and embeds panel.css; it does not minify or obfuscate the code. All extension source and icons are included. No network requests, analytics, AI calls, or external runtime libraries are used by the extension.

This archive contains only files needed to rebuild the Firefox extension, not the brochure or test suite.
